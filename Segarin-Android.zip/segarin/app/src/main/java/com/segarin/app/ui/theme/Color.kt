package com.segarin.app.ui.theme

import androidx.compose.ui.graphics.Color

// Primary
val Rose500 = Color(0xFFF43F5E)
val Rose600 = Color(0xFFE11D48)
val Rose100 = Color(0xFFFFE4E6)

// Secondary
val Amber400 = Color(0xFFFBBF24)
val Orange500 = Color(0xFFF97316)

// Neutral
val Gray50 = Color(0xFFF9FAFB)
val Gray100 = Color(0xFFF3F4F6)
val Gray200 = Color(0xFFE5E7EB)
val Gray500 = Color(0xFF6B7280)
val Gray900 = Color(0xFF111827)

// Status
val Green500 = Color(0xFF22C55E)
val Blue500 = Color(0xFF3B82F6)
val Purple500 = Color(0xFFA855F7)
val Indigo500 = Color(0xFF6366F1)
val Yellow500 = Color(0xFFEAB308)
val Red500 = Color(0xFFEF4444)
val ColorWhite = Color(0xFFFFFFFF)
