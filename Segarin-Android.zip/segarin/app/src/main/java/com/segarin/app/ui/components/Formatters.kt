package com.segarin.app.ui.components

/** Formats a Long amount as "Rp XX.XXX" (no decimals, dot as thousands separator). */
fun formatRupiah(amount: Long): String {
    val formatted = amount.toString().reversed().chunked(3).joinToString(".").reversed()
    return "Rp $formatted"
}

/** Formats a price/amount that comes from the API as a String (e.g. "15000.00"). */
fun formatRupiah(amount: String?): String = formatRupiah(amount.toRupiahLong())

/**
 * Parses a decimal-cast string like "15000.00" (or a plain "15000") into a Long.
 * The backend serializes decimal columns as strings, so this conversion is
 * needed everywhere a price/amount from the API is used for display or math.
 */
fun String?.toRupiahLong(): Long = this?.toDoubleOrNull()?.toLong() ?: 0L
