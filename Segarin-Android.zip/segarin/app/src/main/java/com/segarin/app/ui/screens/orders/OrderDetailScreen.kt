package com.segarin.app.ui.screens.orders

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.segarin.app.ui.components.Base64Image
import com.segarin.app.ui.components.LoadingIndicator
import com.segarin.app.ui.components.formatRupiah
import com.segarin.app.ui.components.statusStyle
import com.segarin.app.ui.components.toRupiahLong
import com.segarin.app.ui.theme.Gray100
import com.segarin.app.ui.theme.Rose600
import com.segarin.app.viewmodel.OrderDetailUiState
import com.segarin.app.viewmodel.OrderViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OrderDetailScreen(orderId: Int, orderViewModel: OrderViewModel, navController: NavHostController) {
    val state by orderViewModel.orderDetailState.collectAsState()

    LaunchedEffect(orderId) { orderViewModel.loadOrderDetail(orderId) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Detail Pesanan") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Kembali")
                    }
                }
            )
        }
    ) { padding ->
        when (val s = state) {
            is OrderDetailUiState.Loading -> LoadingIndicator(modifier = Modifier.padding(padding))
            is OrderDetailUiState.Error -> Box(
                modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center
            ) { Text(s.message, color = MaterialTheme.colorScheme.error) }

            is OrderDetailUiState.Success -> {
                val order = s.order
                val style = statusStyle(order.status)
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp)
                ) {
                    Text(order.order_code, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(4.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(style.color.copy(alpha = 0.15f))
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(style.label, color = style.color, fontWeight = FontWeight.Medium)
                    }

                    Spacer(Modifier.height(16.dp))
                    Text("Informasi Pembayaran", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.titleMedium)
                    InfoRow("Metode", order.payment_method?.uppercase() ?: "-")
                    InfoRow("Total", formatRupiah(order.total_amount))
                    if (order.unique_amount != null) InfoRow("Total + Kode Unik", formatRupiah(order.unique_amount))
                    if (!order.resi_code.isNullOrBlank()) InfoRow("No. Resi", order.resi_code)

                    Spacer(Modifier.height(16.dp))
                    Text("Alamat Pengiriman", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.titleMedium)
                    Text(order.shipping_address ?: "-", style = MaterialTheme.typography.bodyMedium)

                    Spacer(Modifier.height(16.dp))
                    Text("Item Pesanan", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    order.items.orEmpty().forEach { item ->
                        val itemPrice = item.price.toRupiahLong()
                        Row(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                            Base64Image(base64 = item.product?.image, modifier = Modifier.size(48.dp).clip(RoundedCornerShape(8.dp)))
                            Spacer(Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(item.product?.name ?: "Produk", maxLines = 1)
                                Text("${item.quantity} x ${formatRupiah(itemPrice)}", style = MaterialTheme.typography.bodySmall)
                            }
                            Text(formatRupiah(itemPrice * item.quantity), fontWeight = FontWeight.Medium, color = Rose600)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodyMedium)
        Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
    }
}
