package com.segarin.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.segarin.app.data.model.CartItem
import com.segarin.app.data.model.Coupon
import com.segarin.app.data.model.Product
import com.segarin.app.data.repository.ApiResult
import com.segarin.app.data.repository.CartRepository
import com.segarin.app.ui.components.toRupiahLong
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class CartSummary(
    val items: List<CartItem> = emptyList(),
    val shippingCost: Long = 20000L,
    val coupon: Coupon? = null,
    val couponError: String? = null,
    val isApplyingCoupon: Boolean = false
) {
    val subtotal: Long get() = items.sumOf { it.subtotal }
    val discount: Long
        get() = coupon?.let {
            val value = it.value.toDoubleOrNull() ?: 0.0
            if (it.type == "percentage") (subtotal * value / 100.0).toLong() else value.toLong()
        } ?: 0L
    val total: Long get() = (subtotal + shippingCost - discount).coerceAtLeast(0L)
}

class CartViewModel(private val repository: CartRepository) : ViewModel() {

    private val _shippingCost = MutableStateFlow(20000L)
    private val _coupon = MutableStateFlow<Coupon?>(null)
    private val _couponError = MutableStateFlow<String?>(null)
    private val _isApplyingCoupon = MutableStateFlow(false)

    val cartSummary: StateFlow<CartSummary> = combine(
        repository.cartFlow, _shippingCost, _coupon, _couponError, _isApplyingCoupon
    ) { items, shipping, coupon, couponError, applying ->
        CartSummary(items, shipping, coupon, couponError, applying)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), CartSummary())

    fun setShippingCost(cost: Long) {
        _shippingCost.value = cost
    }

    fun addToCart(product: Product, quantity: Int = 1) {
        viewModelScope.launch { repository.addToCart(product, quantity) }
    }

    fun updateQuantity(productId: Int, quantity: Int) {
        viewModelScope.launch { repository.updateQuantity(productId, quantity) }
    }

    fun removeItem(productId: Int) {
        viewModelScope.launch { repository.removeItem(productId) }
    }

    fun clearCart() {
        viewModelScope.launch { repository.clearCart() }
    }

    fun applyCoupon(code: String) {
        if (code.isBlank()) return
        _isApplyingCoupon.value = true
        _couponError.value = null
        viewModelScope.launch {
            when (val result = repository.applyCoupon(code)) {
                is ApiResult.Success -> {
                    _coupon.value = result.data
                    _isApplyingCoupon.value = false
                }
                is ApiResult.Error -> {
                    _coupon.value = null
                    _couponError.value = result.message
                    _isApplyingCoupon.value = false
                }
            }
        }
    }

    fun removeCoupon() {
        _coupon.value = null
        _couponError.value = null
    }
}
