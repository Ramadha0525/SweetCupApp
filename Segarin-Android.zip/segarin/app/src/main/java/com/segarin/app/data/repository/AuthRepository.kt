package com.segarin.app.data.repository

import com.segarin.app.data.api.ApiService
import com.segarin.app.data.api.errorMessage
import com.segarin.app.data.local.TokenManager
import com.segarin.app.data.model.*

sealed class ApiResult<out T> {
    data class Success<T>(val data: T) : ApiResult<T>()
    data class Error(val message: String) : ApiResult<Nothing>()
}

class AuthRepository(
    private val api: ApiService,
    private val tokenManager: TokenManager
) {
    suspend fun login(email: String, password: String): ApiResult<User> {
        return try {
            val res = api.login(LoginRequest(email, password))
            val body = res.body()
            if (res.isSuccessful && body?.data != null) {
                tokenManager.saveSession(body.data.token, body.data.user.name, body.data.user.email)
                ApiResult.Success(body.data.user)
            } else {
                ApiResult.Error(res.errorMessage("Login gagal. Periksa email dan password."))
            }
        } catch (e: Exception) {
            ApiResult.Error(e.message ?: "Terjadi kesalahan jaringan.")
        }
    }

    suspend fun register(
        name: String, email: String, password: String,
        passwordConfirmation: String, phone: String, address: String
    ): ApiResult<User> {
        return try {
            val res = api.register(
                RegisterRequest(name, email, password, passwordConfirmation, phone, address)
            )
            val body = res.body()
            if (res.isSuccessful && body?.data != null) {
                tokenManager.saveSession(body.data.token, body.data.user.name, body.data.user.email)
                ApiResult.Success(body.data.user)
            } else {
                ApiResult.Error(res.errorMessage("Registrasi gagal. Periksa kembali data kamu."))
            }
        } catch (e: Exception) {
            ApiResult.Error(e.message ?: "Terjadi kesalahan jaringan.")
        }
    }

    suspend fun logout(): ApiResult<Unit> {
        return try {
            api.logout()
            tokenManager.clearSession()
            ApiResult.Success(Unit)
        } catch (e: Exception) {
            tokenManager.clearSession()
            ApiResult.Success(Unit)
        }
    }

    suspend fun isLoggedIn(): Boolean = tokenManager.isLoggedIn()

    suspend fun getProfile(): ApiResult<User> {
        return try {
            val res = api.getProfile()
            val body = res.body()
            if (res.isSuccessful && body?.data != null) ApiResult.Success(body.data)
            else ApiResult.Error(res.errorMessage("Gagal memuat profil."))
        } catch (e: Exception) {
            ApiResult.Error(e.message ?: "Terjadi kesalahan jaringan.")
        }
    }

    suspend fun updateProfile(request: UpdateProfileRequest): ApiResult<User> {
        return try {
            val res = api.updateProfile(request)
            val body = res.body()
            if (res.isSuccessful && body?.data != null) ApiResult.Success(body.data)
            else ApiResult.Error(res.errorMessage("Gagal memperbarui profil."))
        } catch (e: Exception) {
            ApiResult.Error(e.message ?: "Terjadi kesalahan jaringan.")
        }
    }
}
