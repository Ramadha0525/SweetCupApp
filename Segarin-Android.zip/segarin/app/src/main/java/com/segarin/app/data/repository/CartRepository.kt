package com.segarin.app.data.repository

import com.segarin.app.data.api.ApiService
import com.segarin.app.data.api.errorMessage
import com.segarin.app.data.local.CartStore
import com.segarin.app.data.model.*
import com.segarin.app.ui.components.toRupiahLong
import kotlinx.coroutines.flow.Flow

/**
 * Cart lives locally (DataStore) until checkout; coupons are validated
 * against the server. Combines local persistence + remote coupon check.
 */
class CartRepository(
    private val api: ApiService,
    private val cartStore: CartStore
) {
    val cartFlow: Flow<List<CartItem>> = cartStore.cartFlow

    suspend fun addToCart(product: Product, quantity: Int = 1) {
        cartStore.addItem(
            CartItem(
                id = product.id,
                name = product.name,
                price = product.price.toRupiahLong(),
                image = product.image,
                quantity = quantity
            )
        )
    }

    suspend fun updateQuantity(productId: Int, quantity: Int) = cartStore.updateQuantity(productId, quantity)

    suspend fun removeItem(productId: Int) = cartStore.removeItem(productId)

    suspend fun clearCart() = cartStore.clear()

    suspend fun applyCoupon(code: String): ApiResult<Coupon> {
        return try {
            val res = api.applyCoupon(CouponRequest(code))
            val body = res.body()
            if (res.isSuccessful && body?.data != null) ApiResult.Success(body.data)
            else ApiResult.Error(res.errorMessage("Kode kupon tidak valid."))
        } catch (e: Exception) {
            ApiResult.Error(e.message ?: "Terjadi kesalahan jaringan.")
        }
    }
}
