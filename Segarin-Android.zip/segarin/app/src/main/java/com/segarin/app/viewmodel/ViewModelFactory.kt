package com.segarin.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.segarin.app.di.AppModule

/**
 * Generic factory that wires each ViewModel to its repository from AppModule.
 * Avoids pulling in Hilt/Dagger for a project of this size.
 */
class ViewModelFactory(private val appModule: AppModule) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return when (modelClass) {
            AuthViewModel::class.java -> AuthViewModel(appModule.authRepository) as T
            ProductViewModel::class.java -> ProductViewModel(appModule.productRepository) as T
            CartViewModel::class.java -> CartViewModel(appModule.cartRepository) as T
            OrderViewModel::class.java -> OrderViewModel(appModule.orderRepository) as T
            WishlistViewModel::class.java -> WishlistViewModel(appModule.wishlistRepository) as T
            ProfileViewModel::class.java -> ProfileViewModel() as T
            else -> throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
        }
    }
}
