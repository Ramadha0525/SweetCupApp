package com.segarin.app.ui.screens.orders

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.segarin.app.ui.components.LoadingIndicator
import com.segarin.app.ui.components.OrderCard
import com.segarin.app.ui.navigation.Routes
import com.segarin.app.ui.theme.Rose500
import com.segarin.app.viewmodel.OrderViewModel

private val filters = listOf(
    null to "Semua",
    "pending" to "Menunggu",
    "paid" to "Lunas",
    "processing" to "Diproses",
    "shipped" to "Dikirim",
    "delivered" to "Selesai"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OrdersScreen(orderViewModel: OrderViewModel, navController: NavHostController) {
    val state by orderViewModel.ordersState.collectAsState()

    LaunchedEffect(Unit) { orderViewModel.loadOrders() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Riwayat Pesanan") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Kembali")
                    }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(16.dp)
            ) {
                items(filters) { (value, label) ->
                    FilterChip(
                        selected = state.statusFilter == value,
                        onClick = { orderViewModel.loadOrders(value) },
                        label = { Text(label) },
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Rose500.copy(alpha = 0.15f))
                    )
                }
            }

            when {
                state.isLoading -> LoadingIndicator(modifier = Modifier.weight(1f))
                state.error != null -> Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Text(state.error ?: "", color = MaterialTheme.colorScheme.error)
                }
                state.orders.isEmpty() -> Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Text("Belum ada pesanan.")
                }
                else -> LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(state.orders, key = { it.id }) { order ->
                        OrderCard(order = order, onClick = { navController.navigate(Routes.orderDetail(order.id)) })
                    }
                }
            }
        }
    }
}
