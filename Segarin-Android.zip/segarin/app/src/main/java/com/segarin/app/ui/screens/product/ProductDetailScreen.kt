package com.segarin.app.ui.screens.product

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.segarin.app.ui.components.Base64Image
import com.segarin.app.ui.components.LoadingIndicator
import com.segarin.app.ui.components.RatingBar
import com.segarin.app.ui.components.formatRupiah
import com.segarin.app.ui.theme.Amber400
import com.segarin.app.ui.theme.Rose500
import com.segarin.app.ui.theme.Rose600
import com.segarin.app.viewmodel.CartViewModel
import com.segarin.app.viewmodel.ProductDetailUiState
import com.segarin.app.viewmodel.ProductViewModel
import com.segarin.app.viewmodel.WishlistViewModel

@Composable
fun ProductDetailScreen(
    slug: String,
    productViewModel: ProductViewModel,
    cartViewModel: CartViewModel,
    wishlistViewModel: WishlistViewModel,
    navController: NavHostController
) {
    val detailState by productViewModel.detailState.collectAsState()
    var isWishlisted by remember { mutableStateOf(false) }
    var reviewRating by remember { mutableStateOf(0) }
    var reviewComment by remember { mutableStateOf("") }
    var submitError by remember { mutableStateOf<String?>(null) }
    var submitting by remember { mutableStateOf(false) }

    LaunchedEffect(slug) { productViewModel.loadProductDetail(slug) }

    Scaffold(
        bottomBar = {
            val state = detailState
            if (state is ProductDetailUiState.Success) {
                Surface(shadowElevation = 8.dp) {
                    Button(
                        onClick = { cartViewModel.addToCart(state.product) },
                        colors = ButtonDefaults.buttonColors(containerColor = Rose500),
                        modifier = Modifier.fillMaxWidth().padding(16.dp).height(48.dp)
                    ) {
                        Text("Tambah ke Keranjang")
                    }
                }
            }
        }
    ) { padding ->
        when (val state = detailState) {
            is ProductDetailUiState.Loading -> LoadingIndicator(modifier = Modifier.padding(padding))
            is ProductDetailUiState.Error -> Box(
                modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center
            ) { Text(state.message, color = MaterialTheme.colorScheme.error) }

            is ProductDetailUiState.Success -> {
                LaunchedEffect(state.product.id) { isWishlisted = state.product.is_wishlisted }
                val product = state.product

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                        .verticalScroll(rememberScrollState())
                ) {
                    Box(modifier = Modifier.fillMaxWidth().height(280.dp)) {
                        Base64Image(base64 = product.image, modifier = Modifier.fillMaxSize())

                        IconButton(onClick = { navController.popBackStack() }, modifier = Modifier.padding(8.dp)) {
                            Box(
                                modifier = Modifier.clip(CircleShape).background(Color.White.copy(alpha = 0.85f))
                            ) {
                                Icon(Icons.Filled.ArrowBack, contentDescription = "Kembali", modifier = Modifier.padding(6.dp))
                            }
                        }

                        IconButton(
                            onClick = {
                                wishlistViewModel.toggleWishlist(product.id, product) { status ->
                                    isWishlisted = status == "added"
                                }
                            },
                            modifier = Modifier.align(Alignment.TopEnd).padding(8.dp)
                        ) {
                            Box(modifier = Modifier.clip(CircleShape).background(Color.White.copy(alpha = 0.85f))) {
                                Icon(
                                    imageVector = if (isWishlisted) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                                    contentDescription = "Wishlist",
                                    tint = Rose500,
                                    modifier = Modifier.padding(6.dp)
                                )
                            }
                        }
                    }

                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(product.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(4.dp))
                        Text(formatRupiah(product.price), color = Rose600, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RatingBar(rating = product.averageRating)
                            Spacer(Modifier.width(6.dp))
                            Text("(${product.reviewsCount} ulasan)", style = MaterialTheme.typography.bodySmall)
                        }
                        Spacer(Modifier.height(12.dp))
                        Text(product.description ?: "Tidak ada deskripsi.", style = MaterialTheme.typography.bodyMedium)

                        Divider(modifier = Modifier.padding(vertical = 16.dp))

                        Text("Beri Ulasan", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(8.dp))
                        Row {
                            for (i in 1..5) {
                                IconButton(onClick = { reviewRating = i }, modifier = Modifier.size(32.dp)) {
                                    Icon(
                                        imageVector = if (i <= reviewRating) Icons.Filled.Star else Icons.Filled.StarBorder,
                                        contentDescription = null,
                                        tint = Amber400
                                    )
                                }
                            }
                        }
                        OutlinedTextField(
                            value = reviewComment,
                            onValueChange = { reviewComment = it },
                            placeholder = { Text("Tulis komentar (opsional)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        if (submitError != null) {
                            Text(submitError!!, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                        }
                        Spacer(Modifier.height(8.dp))
                        Button(
                            onClick = {
                                submitting = true
                                productViewModel.submitReview(product.id, reviewRating, reviewComment.ifBlank { null }) { success, message ->
                                    submitting = false
                                    if (success) {
                                        reviewRating = 0
                                        reviewComment = ""
                                        submitError = null
                                        productViewModel.loadProductDetail(slug)
                                    } else {
                                        submitError = message
                                    }
                                }
                            },
                            enabled = reviewRating > 0 && !submitting,
                            colors = ButtonDefaults.buttonColors(containerColor = Rose500)
                        ) {
                            Text(if (submitting) "Mengirim..." else "Kirim Ulasan")
                        }

                        Divider(modifier = Modifier.padding(vertical = 16.dp))

                        Text("Ulasan Pembeli", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(8.dp))
                        val reviews = product.reviews.orEmpty()
                        if (reviews.isEmpty()) {
                            Text("Belum ada ulasan.", style = MaterialTheme.typography.bodySmall)
                        } else {
                            reviews.forEach { review ->
                                Column(modifier = Modifier.padding(vertical = 6.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(review.user?.name ?: "Pengguna", fontWeight = FontWeight.Medium)
                                        Spacer(Modifier.width(8.dp))
                                        RatingBar(rating = review.rating.toDouble())
                                    }
                                    if (!review.comment.isNullOrBlank()) {
                                        Text(review.comment, style = MaterialTheme.typography.bodySmall)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
