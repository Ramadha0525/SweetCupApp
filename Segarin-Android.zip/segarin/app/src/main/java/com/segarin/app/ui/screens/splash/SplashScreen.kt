package com.segarin.app.ui.screens.splash

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.segarin.app.ui.navigation.Routes
import com.segarin.app.ui.theme.Amber400
import com.segarin.app.ui.theme.ColorWhite
import com.segarin.app.ui.theme.Rose500
import com.segarin.app.viewmodel.AuthViewModel
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(authViewModel: AuthViewModel, navController: NavHostController) {
    var visible by remember { mutableStateOf(false) }
    val alpha by animateFloatAsState(targetValue = if (visible) 1f else 0f, animationSpec = tween(800), label = "logoFade")

    LaunchedEffect(Unit) {
        visible = true
        delay(1200)
        authViewModel.checkSession { isLoggedIn ->
            val destination = if (isLoggedIn) Routes.HOME else Routes.LOGIN
            navController.navigate(destination) {
                popUpTo(Routes.SPLASH) { inclusive = true }
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Rose500, Amber400))),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .alpha(alpha)
                .clip(CircleShape)
                .background(ColorWhite)
                .size(96.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "🍦",
                style = MaterialTheme.typography.headlineLarge
            )
        }
    }
    Box(modifier = Modifier.fillMaxSize().alpha(alpha), contentAlignment = Alignment.BottomCenter) {
        Text(
            text = "Segarin",
            color = ColorWhite,
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.headlineMedium,
            modifier = Modifier.padding(bottom = 48.dp)
        )
    }
}
