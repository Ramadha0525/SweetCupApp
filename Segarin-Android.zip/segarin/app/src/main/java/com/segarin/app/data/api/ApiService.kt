package com.segarin.app.data.api

import com.segarin.app.data.model.*
import retrofit2.Response
import retrofit2.http.*

interface ApiService {

    // ---------- Auth ----------
    @POST("register")
    suspend fun register(@Body request: RegisterRequest): Response<ApiResponse<AuthData>>

    @POST("login")
    suspend fun login(@Body request: LoginRequest): Response<ApiResponse<AuthData>>

    @POST("logout")
    suspend fun logout(): Response<ApiResponse<Unit>>

    @GET("user")
    suspend fun getCurrentUser(): Response<ApiResponse<User>>

    @GET("profile")
    suspend fun getProfile(): Response<ApiResponse<User>>

    @PUT("profile")
    suspend fun updateProfile(@Body request: UpdateProfileRequest): Response<ApiResponse<User>>

    // ---------- Products / Categories ----------
    /** sort: null/"latest" for newest first (default), "price_low", or "price_high". */
    @GET("products")
    suspend fun getProducts(
        @Query("search") search: String? = null,
        @Query("category") category: Int? = null,
        @Query("sort") sort: String? = null,
        @Query("per_page") perPage: Int? = 12,
        @Query("page") page: Int? = null
    ): Response<ApiResponse<PaginatedData<Product>>>

    @GET("products/{slug}")
    suspend fun getProductDetail(@Path("slug") slug: String): Response<ApiResponse<Product>>

    @GET("categories")
    suspend fun getCategories(): Response<ApiResponse<List<Category>>>

    @GET("payment-settings")
    suspend fun getPaymentSettings(): Response<ApiResponse<PaymentSettings>>

    // ---------- Reviews ----------
    @POST("reviews")
    suspend fun submitReview(@Body request: ReviewRequest): Response<ApiResponse<Unit>>

    @DELETE("reviews/{id}")
    suspend fun deleteReview(@Path("id") id: Int): Response<ApiResponse<Unit>>

    // ---------- Wishlist ----------
    @GET("wishlist")
    suspend fun getWishlist(
        @Query("page") page: Int? = null
    ): Response<ApiResponse<PaginatedData<WishlistEntry>>>

    @POST("wishlist/toggle")
    suspend fun toggleWishlist(@Body request: WishlistToggleRequest): Response<ApiResponse<WishlistToggleResponse>>

    // ---------- Coupons ----------
    @POST("coupons/apply")
    suspend fun applyCoupon(@Body request: CouponRequest): Response<ApiResponse<Coupon>>

    // ---------- Checkout / Orders ----------
    @POST("checkout")
    suspend fun checkout(@Body request: CheckoutRequest): Response<ApiResponse<CheckoutResponse>>

    @POST("checkout/manual")
    suspend fun checkoutManual(@Body request: ManualCheckoutRequest): Response<ApiResponse<ManualCheckoutResponse>>

    @GET("orders")
    suspend fun getOrders(
        @Query("status") status: String? = null,
        @Query("page") page: Int? = null
    ): Response<ApiResponse<PaginatedData<Order>>>

    @GET("orders/{id}")
    suspend fun getOrderDetail(@Path("id") id: Int): Response<ApiResponse<Order>>
}
