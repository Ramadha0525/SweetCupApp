package com.segarin.app.data.repository

import com.segarin.app.data.api.ApiService
import com.segarin.app.data.api.errorMessage
import com.segarin.app.data.model.*

class OrderRepository(private val api: ApiService) {

    suspend fun checkout(request: CheckoutRequest): ApiResult<CheckoutResponse> {
        return try {
            val res = api.checkout(request)
            val body = res.body()
            if (res.isSuccessful && body?.data != null) ApiResult.Success(body.data)
            else ApiResult.Error(res.errorMessage("Checkout gagal."))
        } catch (e: Exception) {
            ApiResult.Error(e.message ?: "Terjadi kesalahan jaringan.")
        }
    }

    suspend fun checkoutManual(request: ManualCheckoutRequest): ApiResult<ManualCheckoutResponse> {
        return try {
            val res = api.checkoutManual(request)
            val body = res.body()
            if (res.isSuccessful && body?.data != null) ApiResult.Success(body.data)
            else ApiResult.Error(res.errorMessage("Checkout gagal."))
        } catch (e: Exception) {
            ApiResult.Error(e.message ?: "Terjadi kesalahan jaringan.")
        }
    }

    suspend fun getOrders(status: String? = null, page: Int? = null): ApiResult<PaginatedData<Order>> {
        return try {
            val res = api.getOrders(status, page)
            val body = res.body()
            if (res.isSuccessful && body?.data != null) ApiResult.Success(body.data)
            else ApiResult.Error(res.errorMessage("Gagal memuat pesanan."))
        } catch (e: Exception) {
            ApiResult.Error(e.message ?: "Terjadi kesalahan jaringan.")
        }
    }

    suspend fun getOrderDetail(id: Int): ApiResult<Order> {
        return try {
            val res = api.getOrderDetail(id)
            val body = res.body()
            if (res.isSuccessful && body?.data != null) ApiResult.Success(body.data)
            else ApiResult.Error(res.errorMessage("Pesanan tidak ditemukan."))
        } catch (e: Exception) {
            ApiResult.Error(e.message ?: "Terjadi kesalahan jaringan.")
        }
    }
}
