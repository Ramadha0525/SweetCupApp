package com.segarin.app.data.repository

import com.segarin.app.data.api.ApiService
import com.segarin.app.data.api.errorMessage
import com.segarin.app.data.model.*

class ProductRepository(private val api: ApiService) {

    suspend fun getProducts(
        search: String? = null,
        categoryId: Int? = null,
        sort: String? = null,
        page: Int? = null
    ): ApiResult<PaginatedData<Product>> {
        return try {
            val res = api.getProducts(search, categoryId, sort, 12, page)
            val body = res.body()
            if (res.isSuccessful && body?.data != null) ApiResult.Success(body.data)
            else ApiResult.Error(res.errorMessage("Gagal memuat produk."))
        } catch (e: Exception) {
            ApiResult.Error(e.message ?: "Terjadi kesalahan jaringan.")
        }
    }

    suspend fun getProductDetail(slug: String): ApiResult<Product> {
        return try {
            val res = api.getProductDetail(slug)
            val body = res.body()
            if (res.isSuccessful && body?.data != null) ApiResult.Success(body.data)
            else ApiResult.Error(res.errorMessage("Produk tidak ditemukan."))
        } catch (e: Exception) {
            ApiResult.Error(e.message ?: "Terjadi kesalahan jaringan.")
        }
    }

    suspend fun getCategories(): ApiResult<List<Category>> {
        return try {
            val res = api.getCategories()
            val body = res.body()
            if (res.isSuccessful && body?.data != null) ApiResult.Success(body.data)
            else ApiResult.Error(res.errorMessage("Gagal memuat kategori."))
        } catch (e: Exception) {
            ApiResult.Error(e.message ?: "Terjadi kesalahan jaringan.")
        }
    }

    suspend fun getPaymentSettings(): ApiResult<PaymentSettings> {
        return try {
            val res = api.getPaymentSettings()
            val body = res.body()
            if (res.isSuccessful && body?.data != null) ApiResult.Success(body.data)
            else ApiResult.Error(res.errorMessage("Gagal memuat pengaturan pembayaran."))
        } catch (e: Exception) {
            ApiResult.Error(e.message ?: "Terjadi kesalahan jaringan.")
        }
    }

    suspend fun submitReview(productId: Int, rating: Int, comment: String?): ApiResult<Unit> {
        return try {
            val res = api.submitReview(ReviewRequest(productId, rating, comment))
            if (res.isSuccessful) ApiResult.Success(Unit)
            else ApiResult.Error(res.errorMessage("Gagal mengirim review."))
        } catch (e: Exception) {
            ApiResult.Error(e.message ?: "Terjadi kesalahan jaringan.")
        }
    }

    suspend fun deleteReview(id: Int): ApiResult<Unit> {
        return try {
            val res = api.deleteReview(id)
            if (res.isSuccessful) ApiResult.Success(Unit)
            else ApiResult.Error(res.errorMessage("Gagal menghapus review."))
        } catch (e: Exception) {
            ApiResult.Error(e.message ?: "Terjadi kesalahan jaringan.")
        }
    }
}
