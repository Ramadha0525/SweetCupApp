package com.segarin.app

import android.app.Application

/**
 * Application class. Kept the historical name SweetCupApp per project spec,
 * even though the branded product name is "Segarin".
 */
class SweetCupApp : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}
