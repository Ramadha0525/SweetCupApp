package com.segarin.app.data.model

/**
 * NOTE ON TYPES: the Laravel backend casts `price` as `decimal:2`, which
 * Eloquent serializes to JSON as a STRING (e.g. "15000.00"), not a number.
 * Use `price.toRupiahLong()` (see ui/components/Formatters.kt) wherever you
 * need it as a Long for display or arithmetic.
 */
data class Product(
    val id: Int,
    val name: String,
    val slug: String,
    val description: String? = null,
    val price: String,
    val image: String? = null, // data URI string: "data:image/...;base64,...."
    val category: Category? = null,
    val reviews: List<Review>? = null, // only populated on the detail endpoint
    val is_wishlisted: Boolean = false // never sent by the API; set locally after cross-referencing /wishlist
) {
    /** Computed client-side since the API never appends average_rating/reviews_count. */
    val averageRating: Double
        get() = reviews?.takeIf { it.isNotEmpty() }?.map { it.rating }?.average() ?: 0.0

    val reviewsCount: Int
        get() = reviews?.size ?: 0
}
