package com.segarin.app.data.model

data class CartItem(
    val id: Int,
    val name: String,
    val price: Long,
    val image: String? = null,
    var quantity: Int = 1
) {
    val subtotal: Long get() = price * quantity
}
