package com.segarin.app.viewmodel

// Profile screen reuses AuthViewModel (currentUser, loadProfile, updateProfile, logout)
// so no separate ViewModel state is strictly required. This file is kept to match
// the requested project structure and can host profile-only UI state if needed later.

import androidx.lifecycle.ViewModel

class ProfileViewModel : ViewModel()
