package com.segarin.app.data.model

/**
 * Nested product info only comes through when the backend eager-loads
 * "items.product" (used on /orders and /orders/{id}). price is a String
 * because Eloquent's decimal:2 cast serializes as e.g. "15000.00".
 */
data class OrderItem(
    val id: Int? = null,
    val product_id: Int? = null,
    val product: Product? = null,
    val price: String,
    val quantity: Int
)

data class Order(
    val id: Int,
    val order_code: String,
    val status: String,
    val total_amount: String,
    val unique_amount: String? = null,
    val unique_code: Int? = null,
    val payment_method: String? = null,
    val shipping_address: String? = null,
    val resi_code: String? = null, // "no. resi" / tracking number — this is the real field name on the backend
    val manual_payment_status: String? = null,
    val created_at: String? = null,
    val items: List<OrderItem>? = null
)

data class CartCheckoutItem(
    val id: Int,
    val name: String,
    val price: Long,
    val quantity: Int
)

data class CheckoutRequest(
    val name: String,
    val phone: String,
    val shipping_address: String,
    val notes: String? = null,
    val coupon_code: String? = null,
    val cart: List<CartCheckoutItem>
)

/**
 * total_amount/discount here come back as plain PHP numbers (not through an
 * Eloquent decimal cast), so unlike Order/OrderItem these stay numeric.
 */
data class CheckoutResponse(
    val order_id: Int,
    val order_code: String,
    val snap_token: String? = null,
    val total_amount: Long,
    val discount: Long? = null
)

data class ManualCheckoutRequest(
    val name: String,
    val phone: String,
    val shipping_address: String,
    val notes: String? = null,
    val payment_method: String, // cod | ewallet | qris
    val cart: List<CartCheckoutItem>
)

data class ManualCheckoutResponse(
    val order_id: Int,
    val order_code: String,
    val payment_method: String,
    val total_amount: Long,
    val unique_code: Int? = null,
    val unique_amount: Long? = null
)

data class PaymentSettings(
    val shipping_cost: String,
    val manual_payment_enabled: String,
    val cod_enabled: String,
    val cod_instructions: String? = null,
    val ewallet_enabled: String,
    val ewallet_name: String? = null,
    val ewallet_number: String? = null,
    val ewallet_owner: String? = null,
    val ewallet_instructions: String? = null,
    val qris_enabled: String,
    val qris_image: String? = null,
    val qris_instructions: String? = null
)
