package com.segarin.app.data.model

data class ApiResponse<T>(
    val status: String,
    val message: String? = null,
    val data: T? = null,
    val errors: Map<String, List<String>>? = null
) {
    /** Returns the first validation error message if present, else [message]. */
    fun firstErrorOrMessage(): String? = errors?.values?.firstOrNull()?.firstOrNull() ?: message
}

/**
 * Mirrors Laravel's default LengthAwarePaginator JSON shape exactly
 * (flat fields, not nested under "links"/"meta" -- that nesting only
 * happens when a JsonResource collection is used, which this API doesn't use).
 */
data class PaginatedData<T>(
    val current_page: Int = 1,
    val data: List<T> = emptyList(),
    val first_page_url: String? = null,
    val from: Int? = null,
    val last_page: Int = 1,
    val last_page_url: String? = null,
    val next_page_url: String? = null,
    val path: String? = null,
    val per_page: Int = 12,
    val prev_page_url: String? = null,
    val to: Int? = null,
    val total: Int = 0
)
