package com.segarin.app.data.api

import com.google.gson.Gson
import com.segarin.app.data.model.ApiResponse
import retrofit2.Response

private val gson = Gson()

/**
 * Retrofit's `response.body()` is ALWAYS null for non-2xx responses (4xx/5xx) --
 * the actual JSON (with the real "message"/"errors" from Laravel, e.g. a 422
 * validation error) only lives in `response.errorBody()`, which Retrofit does
 * NOT auto-parse. Every repository needs this to surface real backend messages
 * (like "Email atau password salah") instead of a generic fallback string.
 */
fun <T> Response<ApiResponse<T>>.errorMessage(fallback: String): String {
    if (!isSuccessful) {
        val raw = try {
            errorBody()?.string()
        } catch (e: Exception) {
            null
        }
        if (!raw.isNullOrBlank()) {
            return try {
                val parsed = gson.fromJson(raw, ApiResponse::class.java)
                parsed?.firstErrorOrMessage() ?: fallback
            } catch (e: Exception) {
                fallback
            }
        }
    }
    return body()?.firstErrorOrMessage() ?: fallback
}
