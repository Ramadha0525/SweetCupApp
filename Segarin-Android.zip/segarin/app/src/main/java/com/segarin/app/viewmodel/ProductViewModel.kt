package com.segarin.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.segarin.app.data.model.Category
import com.segarin.app.data.model.Product
import com.segarin.app.data.repository.ApiResult
import com.segarin.app.data.repository.ProductRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class ProductListState(
    val products: List<Product> = emptyList(),
    val categories: List<Category> = emptyList(),
    val selectedCategoryId: Int? = null,
    val searchQuery: String = "",
    val sort: String? = null,
    val isLoading: Boolean = false,
    val isRefreshing: Boolean = false,
    val currentPage: Int = 1,
    val lastPage: Int = 1,
    val error: String? = null
)

sealed class ProductDetailUiState {
    object Loading : ProductDetailUiState()
    data class Success(val product: Product) : ProductDetailUiState()
    data class Error(val message: String) : ProductDetailUiState()
}

class ProductViewModel(private val repository: ProductRepository) : ViewModel() {

    private val _listState = MutableStateFlow(ProductListState())
    val listState: StateFlow<ProductListState> = _listState.asStateFlow()

    private val _detailState = MutableStateFlow<ProductDetailUiState>(ProductDetailUiState.Loading)
    val detailState: StateFlow<ProductDetailUiState> = _detailState.asStateFlow()

    init {
        loadCategories()
        loadProducts(reset = true)
    }

    fun loadCategories() {
        viewModelScope.launch {
            when (val result = repository.getCategories()) {
                is ApiResult.Success -> _listState.value = _listState.value.copy(categories = result.data)
                is ApiResult.Error -> { /* keep silent; categories aren't critical to show error */ }
            }
        }
    }

    fun loadProducts(reset: Boolean = false) {
        val state = _listState.value
        val page = if (reset) 1 else state.currentPage
        _listState.value = state.copy(isLoading = reset, error = null)

        viewModelScope.launch {
            when (val result = repository.getProducts(
                search = state.searchQuery.ifBlank { null },
                categoryId = state.selectedCategoryId,
                sort = state.sort,
                page = page
            )) {
                is ApiResult.Success -> {
                    val existing = if (reset) emptyList() else _listState.value.products
                    _listState.value = _listState.value.copy(
                        products = existing + result.data.data,
                        currentPage = result.data.current_page,
                        lastPage = result.data.last_page,
                        isLoading = false,
                        isRefreshing = false
                    )
                }
                is ApiResult.Error -> _listState.value = _listState.value.copy(
                    isLoading = false, isRefreshing = false, error = result.message
                )
            }
        }
    }

    fun refresh() {
        _listState.value = _listState.value.copy(isRefreshing = true)
        loadProducts(reset = true)
    }

    fun loadNextPage() {
        val state = _listState.value
        if (state.isLoading || state.currentPage >= state.lastPage) return
        _listState.value = state.copy(currentPage = state.currentPage + 1)
        loadProducts(reset = false)
    }

    fun onSearchChange(query: String) {
        _listState.value = _listState.value.copy(searchQuery = query)
        loadProducts(reset = true)
    }

    fun onCategorySelect(categoryId: Int?) {
        _listState.value = _listState.value.copy(selectedCategoryId = categoryId)
        loadProducts(reset = true)
    }

    fun onSortChange(sort: String?) {
        _listState.value = _listState.value.copy(sort = sort)
        loadProducts(reset = true)
    }

    fun loadProductDetail(slug: String) {
        _detailState.value = ProductDetailUiState.Loading
        viewModelScope.launch {
            when (val result = repository.getProductDetail(slug)) {
                is ApiResult.Success -> _detailState.value = ProductDetailUiState.Success(result.data)
                is ApiResult.Error -> _detailState.value = ProductDetailUiState.Error(result.message)
            }
        }
    }

    fun submitReview(productId: Int, rating: Int, comment: String?, onResult: (Boolean, String?) -> Unit) {
        viewModelScope.launch {
            when (val result = repository.submitReview(productId, rating, comment)) {
                is ApiResult.Success -> onResult(true, null)
                is ApiResult.Error -> onResult(false, result.message)
            }
        }
    }
}
