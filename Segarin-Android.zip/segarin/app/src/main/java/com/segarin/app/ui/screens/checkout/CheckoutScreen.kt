package com.segarin.app.ui.screens.checkout

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.segarin.app.data.model.CartCheckoutItem
import com.segarin.app.data.model.ManualCheckoutRequest
import com.segarin.app.ui.components.formatRupiah
import com.segarin.app.ui.navigation.Routes
import com.segarin.app.ui.theme.Gray100
import com.segarin.app.ui.theme.Rose500
import com.segarin.app.ui.theme.Rose600
import com.segarin.app.viewmodel.AuthViewModel
import com.segarin.app.viewmodel.CartViewModel
import com.segarin.app.viewmodel.CheckoutUiState
import com.segarin.app.viewmodel.OrderViewModel

private enum class PaymentMethod(val label: String, val apiValue: String) {
    MIDTRANS("Midtrans (Kartu, Transfer, GoPay, OVO)", "midtrans"),
    COD("Bayar di Tempat (COD)", "cod"),
    EWALLET("E-Wallet", "ewallet"),
    QRIS("QRIS", "qris")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CheckoutScreen(
    cartViewModel: CartViewModel,
    orderViewModel: OrderViewModel,
    authViewModel: AuthViewModel,
    navController: NavHostController
) {
    val summary by cartViewModel.cartSummary.collectAsState()
    val currentUser by authViewModel.currentUser.collectAsState()
    val checkoutState by orderViewModel.checkoutState.collectAsState()

    var name by remember { mutableStateOf(currentUser?.name ?: "") }
    var phone by remember { mutableStateOf(currentUser?.phone ?: "") }
    var address by remember { mutableStateOf(currentUser?.address ?: "") }
    var notes by remember { mutableStateOf("") }
    var selectedMethod by remember { mutableStateOf(PaymentMethod.COD) }

    LaunchedEffect(Unit) { authViewModel.loadProfile() }
    LaunchedEffect(currentUser) {
        currentUser?.let {
            if (name.isBlank()) name = it.name
            if (phone.isBlank()) phone = it.phone ?: ""
            if (address.isBlank()) address = it.address ?: ""
        }
    }

    LaunchedEffect(checkoutState) {
        when (val state = checkoutState) {
            is CheckoutUiState.ManualSuccess -> {
                cartViewModel.clearCart()
                navController.navigate(Routes.paymentResult(state.response.order_id)) {
                    popUpTo(Routes.HOME)
                }
                orderViewModel.resetCheckoutState()
            }
            is CheckoutUiState.MidtransSuccess -> {
                cartViewModel.clearCart()
                navController.navigate(Routes.paymentResult(state.response.order_id)) {
                    popUpTo(Routes.HOME)
                }
                orderViewModel.resetCheckoutState()
            }
            else -> {}
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Checkout") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Kembali")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Nama") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Telepon") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(value = address, onValueChange = { address = it }, label = { Text("Alamat Pengiriman") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Catatan (opsional)") }, modifier = Modifier.fillMaxWidth())

            Spacer(Modifier.height(20.dp))
            Text("Metode Pembayaran", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))

            PaymentMethod.values().forEach { method ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .border(1.dp, if (selectedMethod == method) Rose500 else Gray100, RoundedCornerShape(10.dp))
                        .selectable(selected = selectedMethod == method, onClick = { selectedMethod = method })
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(selected = selectedMethod == method, onClick = { selectedMethod = method })
                    Spacer(Modifier.width(8.dp))
                    Text(method.label, style = MaterialTheme.typography.bodyMedium)
                }
                Spacer(Modifier.height(8.dp))
            }

            Spacer(Modifier.height(16.dp))
            Text("Ringkasan Pesanan", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            SummaryLine("Subtotal", formatRupiah(summary.subtotal))
            SummaryLine("Ongkir", formatRupiah(summary.shippingCost))
            if (summary.discount > 0) SummaryLine("Diskon", "- ${formatRupiah(summary.discount)}")
            Divider(modifier = Modifier.padding(vertical = 6.dp))
            SummaryLine("Total", formatRupiah(summary.total), bold = true)

            if (checkoutState is CheckoutUiState.Error) {
                Spacer(Modifier.height(8.dp))
                Text((checkoutState as CheckoutUiState.Error).message, color = MaterialTheme.colorScheme.error)
            }

            Spacer(Modifier.height(20.dp))
            Button(
                onClick = {
                    val cartItems = summary.items.map { CartCheckoutItem(it.id, it.name, it.price, it.quantity) }
                    if (selectedMethod == PaymentMethod.MIDTRANS) {
                        orderViewModel.checkoutMidtrans(
                            com.segarin.app.data.model.CheckoutRequest(
                                name = name, phone = phone, shipping_address = address,
                                notes = notes.ifBlank { null }, coupon_code = summary.coupon?.code, cart = cartItems
                            )
                        )
                    } else {
                        orderViewModel.checkoutManual(
                            ManualCheckoutRequest(
                                name = name, phone = phone, shipping_address = address,
                                notes = notes.ifBlank { null }, payment_method = selectedMethod.apiValue, cart = cartItems
                            )
                        )
                    }
                },
                enabled = name.isNotBlank() && phone.isNotBlank() && address.isNotBlank() && checkoutState !is CheckoutUiState.Loading,
                colors = ButtonDefaults.buttonColors(containerColor = Rose500),
                modifier = Modifier.fillMaxWidth().height(48.dp)
            ) {
                if (checkoutState is CheckoutUiState.Loading) {
                    CircularProgressIndicator(color = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(20.dp))
                } else {
                    Text(if (selectedMethod == PaymentMethod.MIDTRANS) "Bayar Sekarang" else "Buat Pesanan")
                }
            }
        }
    }
}

@Composable
private fun SummaryLine(label: String, value: String, bold: Boolean = false) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal)
        Text(value, fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal, color = if (bold) Rose600 else MaterialTheme.colorScheme.onSurface)
    }
}
