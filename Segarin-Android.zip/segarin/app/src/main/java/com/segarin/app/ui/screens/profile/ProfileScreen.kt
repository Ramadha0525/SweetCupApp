package com.segarin.app.ui.screens.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.ListAlt
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.segarin.app.data.model.UpdateProfileRequest
import com.segarin.app.ui.navigation.Routes
import com.segarin.app.ui.theme.ColorWhite
import com.segarin.app.ui.theme.Rose100
import com.segarin.app.ui.theme.Rose500
import com.segarin.app.viewmodel.AuthViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(authViewModel: AuthViewModel, navController: NavHostController) {
    val currentUser by authViewModel.currentUser.collectAsState()

    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var newPassword by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var saveMessage by remember { mutableStateOf<String?>(null) }
    var saveError by remember { mutableStateOf<String?>(null) }
    var saving by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { authViewModel.loadProfile() }
    LaunchedEffect(currentUser) {
        currentUser?.let {
            name = it.name
            phone = it.phone ?: ""
            address = it.address ?: ""
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Profil") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Kembali")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier.size(72.dp).clip(CircleShape).background(Rose100),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = currentUser?.name?.take(1)?.uppercase() ?: "?",
                    style = MaterialTheme.typography.headlineMedium,
                    color = Rose500,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(Modifier.height(8.dp))
            Text(currentUser?.name ?: "-", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(currentUser?.email ?: "-", style = MaterialTheme.typography.bodyMedium)

            Spacer(Modifier.height(20.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                QuickLink(icon = Icons.Filled.ListAlt, label = "Pesanan Saya") { navController.navigate(Routes.ORDERS) }
                QuickLink(icon = Icons.Filled.FavoriteBorder, label = "Wishlist") { navController.navigate(Routes.WISHLIST) }
            }

            Spacer(Modifier.height(20.dp))
            Divider()
            Spacer(Modifier.height(16.dp))

            Text("Edit Profil", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Nama") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Telepon") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(value = address, onValueChange = { address = it }, label = { Text("Alamat") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = newPassword, onValueChange = { newPassword = it },
                label = { Text("Password Baru (opsional)") }, singleLine = true,
                visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = confirmPassword, onValueChange = { confirmPassword = it },
                label = { Text("Konfirmasi Password Baru") }, singleLine = true,
                visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth()
            )

            if (saveError != null) {
                Spacer(Modifier.height(8.dp))
                Text(saveError ?: "", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }
            if (saveMessage != null) {
                Spacer(Modifier.height(8.dp))
                Text(saveMessage ?: "", color = Rose500, style = MaterialTheme.typography.bodySmall)
            }

            Spacer(Modifier.height(16.dp))
            Button(
                onClick = {
                    if (newPassword.isNotBlank() && newPassword != confirmPassword) {
                        saveError = "Password baru dan konfirmasi tidak sama."
                        return@Button
                    }
                    saving = true
                    saveError = null
                    saveMessage = null
                    authViewModel.updateProfile(
                        UpdateProfileRequest(
                            name = name, phone = phone, address = address,
                            password = newPassword.ifBlank { null },
                            password_confirmation = if (newPassword.isNotBlank()) confirmPassword else null
                        )
                    ) { success, message ->
                        saving = false
                        if (success) {
                            saveMessage = "Profil berhasil diperbarui."
                            newPassword = ""
                            confirmPassword = ""
                        } else {
                            saveError = message
                        }
                    }
                },
                enabled = !saving,
                colors = ButtonDefaults.buttonColors(containerColor = Rose500),
                modifier = Modifier.fillMaxWidth().height(48.dp)
            ) {
                Text(if (saving) "Menyimpan..." else "Simpan Perubahan")
            }

            Spacer(Modifier.height(24.dp))
            OutlinedButton(
                onClick = {
                    authViewModel.logout {
                        navController.navigate(Routes.LOGIN) {
                            popUpTo(0) { inclusive = true }
                        }
                    }
                },
                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Filled.Logout, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text("Logout")
            }
        }
    }
}

@Composable
private fun QuickLink(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Box(
            modifier = Modifier.size(52.dp).clip(CircleShape).background(Rose100),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = label, tint = Rose500)
        }
        Spacer(Modifier.height(4.dp))
        Text(label, style = MaterialTheme.typography.bodySmall)
    }
}
