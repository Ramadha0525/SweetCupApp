package com.segarin.app.ui.screens.payment

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.segarin.app.di.AppModule
import com.segarin.app.ui.components.Base64Image
import com.segarin.app.ui.components.LoadingIndicator
import com.segarin.app.ui.components.formatRupiah
import com.segarin.app.ui.navigation.Routes
import com.segarin.app.ui.theme.Gray100
import com.segarin.app.ui.theme.Rose500
import com.segarin.app.ui.theme.Rose600
import com.segarin.app.viewmodel.OrderDetailUiState
import com.segarin.app.viewmodel.OrderViewModel
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import com.segarin.app.data.model.PaymentSettings
import com.segarin.app.data.repository.ApiResult
import com.segarin.app.viewmodel.ViewModelFactory

/**
 * Shown right after checkout. For COD/E-Wallet/QRIS it displays payment
 * instructions and the "Menunggu Konfirmasi" status. For Midtrans, in a
 * full implementation this is where the Snap SDK would be launched; here
 * we show the order confirmation while that integration is wired up.
 */
@Composable
fun PaymentResultScreen(orderId: Int, navController: NavHostController) {
    val context = LocalContext.current
    val appModule = remember(context) { AppModule.getInstance(context) }
    val factory = ViewModelFactory(appModule)
    val orderViewModel: OrderViewModel = viewModel(factory = factory)

    val detailState by orderViewModel.orderDetailState.collectAsState()
    var paymentSettings by remember { mutableStateOf<PaymentSettings?>(null) }

    LaunchedEffect(orderId) { orderViewModel.loadOrderDetail(orderId) }
    LaunchedEffect(Unit) {
        when (val result = appModule.productRepository.getPaymentSettings()) {
            is ApiResult.Success -> paymentSettings = result.data
            is ApiResult.Error -> { /* instructions are a nice-to-have; fail silently */ }
        }
    }

    Scaffold(topBar = { TopAppBar(title = { Text("Status Pembayaran") }) }) { padding ->
        when (val state = detailState) {
            is OrderDetailUiState.Loading -> LoadingIndicator(modifier = Modifier.padding(padding))
            is OrderDetailUiState.Error -> Box(
                modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center
            ) { Text(state.message, color = MaterialTheme.colorScheme.error) }

            is OrderDetailUiState.Success -> {
                val order = state.order
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp)
                ) {
                    Text("Kode Pesanan: ${order.order_code}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(4.dp))
                    Text("Menunggu Konfirmasi", color = Rose600, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(16.dp))

                    val totalToPay = order.unique_amount ?: order.total_amount
                    Text("Total yang harus dibayar", style = MaterialTheme.typography.bodyMedium)
                    Text(formatRupiah(totalToPay), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.headlineMedium, color = Rose600)
                    if (order.unique_code != null) {
                        Text("(termasuk kode unik ${order.unique_code})", style = MaterialTheme.typography.bodySmall)
                    }

                    Spacer(Modifier.height(20.dp))
                    when (order.payment_method) {
                        "cod" -> Text(
                            paymentSettings?.cod_instructions?.ifBlank { null }
                                ?: "Silakan siapkan pembayaran tunai sebesar total di atas saat pesanan tiba di alamat kamu.",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        "ewallet" -> Column {
                            Text(
                                paymentSettings?.ewallet_instructions?.ifBlank { null }
                                    ?: "Silakan transfer sesuai nominal di atas ke rekening berikut, lalu unggah bukti transfer jika diperlukan.",
                                style = MaterialTheme.typography.bodyMedium
                            )
                            paymentSettings?.let { settings ->
                                Spacer(Modifier.height(12.dp))
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(Gray100)
                                        .padding(12.dp)
                                ) {
                                    Text(settings.ewallet_name ?: "E-Wallet", fontWeight = FontWeight.SemiBold)
                                    Text(settings.ewallet_number ?: "-", style = MaterialTheme.typography.titleMedium)
                                    Text("a.n. ${settings.ewallet_owner ?: "-"}", style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                        "qris" -> Column {
                            Text(
                                paymentSettings?.qris_instructions?.ifBlank { null }
                                    ?: "Scan kode QRIS berikut dan bayar sesuai nominal total di atas (termasuk kode unik).",
                                style = MaterialTheme.typography.bodyMedium
                            )
                            if (!paymentSettings?.qris_image.isNullOrBlank()) {
                                Spacer(Modifier.height(12.dp))
                                Base64Image(
                                    base64 = paymentSettings?.qris_image,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(240.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                )
                            }
                        }
                        else -> Text(
                            "Selesaikan pembayaran melalui metode yang kamu pilih (kartu kredit, transfer bank, GoPay, atau OVO).",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }

                    Spacer(Modifier.height(24.dp))
                    Button(
                        onClick = {
                            navController.navigate(Routes.orderDetail(orderId)) {
                                popUpTo(Routes.HOME)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Rose500),
                        modifier = Modifier.fillMaxWidth().height(48.dp)
                    ) { Text("Lihat Detail Pesanan") }

                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(
                        onClick = {
                            navController.navigate(Routes.HOME) { popUpTo(Routes.HOME) { inclusive = true } }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Kembali ke Beranda") }
                }
            }
        }
    }
}
