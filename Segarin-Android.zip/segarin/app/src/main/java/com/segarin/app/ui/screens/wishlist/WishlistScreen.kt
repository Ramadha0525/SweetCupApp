package com.segarin.app.ui.screens.wishlist

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.segarin.app.ui.components.LoadingIndicator
import com.segarin.app.ui.components.ProductCard
import com.segarin.app.ui.navigation.Routes
import com.segarin.app.viewmodel.CartViewModel
import com.segarin.app.viewmodel.WishlistViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WishlistScreen(
    wishlistViewModel: WishlistViewModel,
    cartViewModel: CartViewModel,
    navController: NavHostController
) {
    val state by wishlistViewModel.state.collectAsState()

    LaunchedEffect(Unit) { wishlistViewModel.loadWishlist() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Wishlist") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Kembali")
                    }
                }
            )
        }
    ) { padding ->
        when {
            state.isLoading -> LoadingIndicator(modifier = Modifier.padding(padding))
            state.error != null -> Box(
                modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center
            ) { Text(state.error ?: "", color = MaterialTheme.colorScheme.error) }
            state.products.isEmpty() -> Box(
                modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center
            ) { Text("Belum ada produk di wishlist kamu.") }
            else -> LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.padding(padding).fillMaxSize()
            ) {
                items(state.products, key = { it.id }) { product ->
                    ProductCard(
                        product = product.copy(is_wishlisted = true),
                        onClick = { navController.navigate(Routes.productDetail(product.slug)) },
                        onAddToCart = { cartViewModel.addToCart(product) },
                        onToggleWishlist = { wishlistViewModel.toggleWishlist(product.id) }
                    )
                }
            }
        }
    }
}
