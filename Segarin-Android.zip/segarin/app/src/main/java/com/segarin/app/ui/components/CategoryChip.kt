package com.segarin.app.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.segarin.app.ui.theme.Gray100
import com.segarin.app.ui.theme.Gray900
import com.segarin.app.ui.theme.Rose500
import com.segarin.app.ui.theme.ColorWhite

@Composable
fun CategoryChip(
    label: String,
    icon: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(if (isSelected) Rose500 else ColorWhite)
            .then(
                if (!isSelected) Modifier.border(BorderStroke(1.dp, Gray100), RoundedCornerShape(14.dp))
                else Modifier
            )
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 10.dp)
    ) {
        Text(text = icon, fontSize = MaterialTheme.typography.titleLarge.fontSize)
        Spacer(Modifier.height(4.dp))
        Text(
            text = label,
            color = if (isSelected) ColorWhite else Gray900,
            fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
            style = MaterialTheme.typography.bodySmall
        )
    }
}
