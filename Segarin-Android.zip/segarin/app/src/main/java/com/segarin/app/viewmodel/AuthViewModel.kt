package com.segarin.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.segarin.app.data.model.UpdateProfileRequest
import com.segarin.app.data.model.User
import com.segarin.app.data.repository.ApiResult
import com.segarin.app.data.repository.AuthRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed class AuthUiState {
    object Idle : AuthUiState()
    object Loading : AuthUiState()
    data class Success(val user: User) : AuthUiState()
    data class Error(val message: String) : AuthUiState()
}

class AuthViewModel(private val repository: AuthRepository) : ViewModel() {

    private val _uiState = MutableStateFlow<AuthUiState>(AuthUiState.Idle)
    val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

    private val _currentUser = MutableStateFlow<User?>(null)
    val currentUser: StateFlow<User?> = _currentUser.asStateFlow()

    fun login(email: String, password: String) {
        _uiState.value = AuthUiState.Loading
        viewModelScope.launch {
            when (val result = repository.login(email, password)) {
                is ApiResult.Success -> {
                    _currentUser.value = result.data
                    _uiState.value = AuthUiState.Success(result.data)
                }
                is ApiResult.Error -> _uiState.value = AuthUiState.Error(result.message)
            }
        }
    }

    fun register(
        name: String, email: String, password: String,
        passwordConfirmation: String, phone: String, address: String
    ) {
        _uiState.value = AuthUiState.Loading
        viewModelScope.launch {
            when (val result = repository.register(name, email, password, passwordConfirmation, phone, address)) {
                is ApiResult.Success -> {
                    _currentUser.value = result.data
                    _uiState.value = AuthUiState.Success(result.data)
                }
                is ApiResult.Error -> _uiState.value = AuthUiState.Error(result.message)
            }
        }
    }

    fun logout(onComplete: () -> Unit) {
        viewModelScope.launch {
            repository.logout()
            _currentUser.value = null
            _uiState.value = AuthUiState.Idle
            onComplete()
        }
    }

    fun checkSession(onResult: (Boolean) -> Unit) {
        viewModelScope.launch {
            onResult(repository.isLoggedIn())
        }
    }

    fun loadProfile() {
        viewModelScope.launch {
            when (val result = repository.getProfile()) {
                is ApiResult.Success -> _currentUser.value = result.data
                is ApiResult.Error -> _uiState.value = AuthUiState.Error(result.message)
            }
        }
    }

    fun updateProfile(request: UpdateProfileRequest, onResult: (Boolean, String?) -> Unit) {
        viewModelScope.launch {
            when (val result = repository.updateProfile(request)) {
                is ApiResult.Success -> {
                    _currentUser.value = result.data
                    onResult(true, null)
                }
                is ApiResult.Error -> onResult(false, result.message)
            }
        }
    }

    fun resetState() {
        _uiState.value = AuthUiState.Idle
    }
}
