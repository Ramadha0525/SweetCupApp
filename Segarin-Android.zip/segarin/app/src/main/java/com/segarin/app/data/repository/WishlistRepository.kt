package com.segarin.app.data.repository

import com.segarin.app.data.api.ApiService
import com.segarin.app.data.api.errorMessage
import com.segarin.app.data.model.*

class WishlistRepository(private val api: ApiService) {

    suspend fun getWishlist(page: Int? = null): ApiResult<PaginatedData<WishlistEntry>> {
        return try {
            val res = api.getWishlist(page)
            val body = res.body()
            if (res.isSuccessful && body?.data != null) ApiResult.Success(body.data)
            else ApiResult.Error(res.errorMessage("Gagal memuat wishlist."))
        } catch (e: Exception) {
            ApiResult.Error(e.message ?: "Terjadi kesalahan jaringan.")
        }
    }

    /** Returns "added" or "removed" on success. */
    suspend fun toggle(productId: Int): ApiResult<String> {
        return try {
            val res = api.toggleWishlist(WishlistToggleRequest(productId))
            val body = res.body()
            if (res.isSuccessful && body?.data != null) ApiResult.Success(body.data.status)
            else ApiResult.Error(res.errorMessage("Gagal memperbarui wishlist."))
        } catch (e: Exception) {
            ApiResult.Error(e.message ?: "Terjadi kesalahan jaringan.")
        }
    }
}
