package com.segarin.app.data.model

data class Review(
    val id: Int,
    val user: User? = null, // nested relation ("reviews.user"), not a flat user_name string
    val rating: Int,
    val comment: String? = null,
    val created_at: String? = null
)

data class ReviewRequest(
    val product_id: Int,
    val rating: Int,
    val comment: String? = null
)
