package com.segarin.app.data.local

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.segarin.app.data.model.CartItem
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.cartDataStore by preferencesDataStore(name = "segarin_cart")

/**
 * Persists the local cart (offline-first) as a JSON blob via DataStore.
 */
class CartStore(private val context: Context) {

    private val CART_KEY = stringPreferencesKey("cart_items")
    private val gson = Gson()

    val cartFlow: Flow<List<CartItem>> = context.cartDataStore.data.map { prefs ->
        val json = prefs[CART_KEY] ?: return@map emptyList()
        val type = object : TypeToken<List<CartItem>>() {}.type
        try {
            gson.fromJson<List<CartItem>>(json, type) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    private suspend fun currentItems(): MutableList<CartItem> =
        cartFlow.first().toMutableList()

    suspend fun addItem(product: CartItem) {
        val items = currentItems()
        val existing = items.find { it.id == product.id }
        if (existing != null) {
            existing.quantity += product.quantity
        } else {
            items.add(product)
        }
        save(items)
    }

    suspend fun updateQuantity(productId: Int, quantity: Int) {
        val items = currentItems()
        items.find { it.id == productId }?.let { it.quantity = quantity.coerceAtLeast(1) }
        save(items)
    }

    suspend fun removeItem(productId: Int) {
        val items = currentItems()
        items.removeAll { it.id == productId }
        save(items)
    }

    suspend fun clear() {
        save(emptyList())
    }

    private suspend fun save(items: List<CartItem>) {
        context.cartDataStore.edit { prefs ->
            prefs[CART_KEY] = gson.toJson(items)
        }
    }
}
