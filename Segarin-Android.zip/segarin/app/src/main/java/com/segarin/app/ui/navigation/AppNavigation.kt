package com.segarin.app.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.segarin.app.di.AppModule
import com.segarin.app.ui.screens.auth.LoginScreen
import com.segarin.app.ui.screens.auth.RegisterScreen
import com.segarin.app.ui.screens.cart.CartScreen
import com.segarin.app.ui.screens.checkout.CheckoutScreen
import com.segarin.app.ui.screens.home.HomeScreen
import com.segarin.app.ui.screens.orders.OrderDetailScreen
import com.segarin.app.ui.screens.orders.OrdersScreen
import com.segarin.app.ui.screens.payment.PaymentResultScreen
import com.segarin.app.ui.screens.product.ProductDetailScreen
import com.segarin.app.ui.screens.profile.ProfileScreen
import com.segarin.app.ui.screens.splash.SplashScreen
import com.segarin.app.ui.screens.wishlist.WishlistScreen
import com.segarin.app.viewmodel.*

/** Central route definitions for the app. */
object Routes {
    const val SPLASH = "splash"
    const val LOGIN = "login"
    const val REGISTER = "register"
    const val HOME = "home"
    const val PRODUCT_DETAIL = "product/{slug}"
    const val CART = "cart"
    const val CHECKOUT = "checkout"
    const val PAYMENT_RESULT = "payment_result/{orderId}"
    const val ORDERS = "orders"
    const val ORDER_DETAIL = "order/{orderId}"
    const val WISHLIST = "wishlist"
    const val PROFILE = "profile"

    fun productDetail(slug: String) = "product/$slug"
    fun paymentResult(orderId: Int) = "payment_result/$orderId"
    fun orderDetail(orderId: Int) = "order/$orderId"
}

@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    val context = LocalContext.current
    val appModule = remember(context) { AppModule.getInstance(context) }
    val factory = ViewModelFactory(appModule)

    val authViewModel: AuthViewModel = viewModel(factory = factory)
    val productViewModel: ProductViewModel = viewModel(factory = factory)
    val cartViewModel: CartViewModel = viewModel(factory = factory)
    val orderViewModel: OrderViewModel = viewModel(factory = factory)
    val wishlistViewModel: WishlistViewModel = viewModel(factory = factory)

    NavHost(navController = navController, startDestination = Routes.SPLASH) {

        composable(Routes.SPLASH) {
            SplashScreen(authViewModel = authViewModel, navController = navController)
        }

        composable(Routes.LOGIN) {
            LoginScreen(authViewModel = authViewModel, navController = navController)
        }

        composable(Routes.REGISTER) {
            RegisterScreen(authViewModel = authViewModel, navController = navController)
        }

        composable(Routes.HOME) {
            HomeScreen(
                productViewModel = productViewModel,
                cartViewModel = cartViewModel,
                wishlistViewModel = wishlistViewModel,
                navController = navController
            )
        }

        composable(
            route = Routes.PRODUCT_DETAIL,
            arguments = listOf(navArgument("slug") { type = NavType.StringType })
        ) { backStackEntry ->
            val slug = backStackEntry.arguments?.getString("slug") ?: ""
            ProductDetailScreen(
                slug = slug,
                productViewModel = productViewModel,
                cartViewModel = cartViewModel,
                wishlistViewModel = wishlistViewModel,
                navController = navController
            )
        }

        composable(Routes.CART) {
            CartScreen(cartViewModel = cartViewModel, navController = navController)
        }

        composable(Routes.CHECKOUT) {
            CheckoutScreen(
                cartViewModel = cartViewModel,
                orderViewModel = orderViewModel,
                authViewModel = authViewModel,
                navController = navController
            )
        }

        composable(
            route = Routes.PAYMENT_RESULT,
            arguments = listOf(navArgument("orderId") { type = NavType.IntType })
        ) { backStackEntry ->
            val orderId = backStackEntry.arguments?.getInt("orderId") ?: 0
            PaymentResultScreen(orderId = orderId, navController = navController)
        }

        composable(Routes.ORDERS) {
            OrdersScreen(orderViewModel = orderViewModel, navController = navController)
        }

        composable(
            route = Routes.ORDER_DETAIL,
            arguments = listOf(navArgument("orderId") { type = NavType.IntType })
        ) { backStackEntry ->
            val orderId = backStackEntry.arguments?.getInt("orderId") ?: 0
            OrderDetailScreen(orderId = orderId, orderViewModel = orderViewModel, navController = navController)
        }

        composable(Routes.WISHLIST) {
            WishlistScreen(
                wishlistViewModel = wishlistViewModel,
                cartViewModel = cartViewModel,
                navController = navController
            )
        }

        composable(Routes.PROFILE) {
            ProfileScreen(authViewModel = authViewModel, navController = navController)
        }
    }
}
