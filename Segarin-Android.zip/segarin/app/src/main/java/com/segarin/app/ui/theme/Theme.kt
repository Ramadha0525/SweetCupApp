package com.segarin.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val LightColors = lightColorScheme(
    primary = Rose500,
    onPrimary = ColorWhite,
    primaryContainer = Rose100,
    secondary = Amber400,
    background = ColorWhite,
    surface = ColorWhite,
    onSurface = Gray900,
    error = Red500,
)

private val DarkColors = darkColorScheme(
    primary = Rose500,
    secondary = Amber400,
    background = Gray900,
    surface = Gray900,
)

@Composable
fun SegarinTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme) DarkColors else LightColors
    MaterialTheme(
        colorScheme = colors,
        typography = SegarinTypography,
        content = content
    )
}
