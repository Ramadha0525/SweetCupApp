package com.segarin.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.segarin.app.data.model.Product
import com.segarin.app.data.repository.ApiResult
import com.segarin.app.data.repository.WishlistRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class WishlistState(
    val products: List<Product> = emptyList(),
    val isLoading: Boolean = false,
    val error: String? = null
)

class WishlistViewModel(private val repository: WishlistRepository) : ViewModel() {

    private val _state = MutableStateFlow(WishlistState())
    val state: StateFlow<WishlistState> = _state.asStateFlow()

    /** Set of product IDs currently wishlisted, derived from the last successful load.
     *  Cross-referenced by HomeScreen/ProductDetailScreen since the products/{slug} and
     *  products list endpoints never send is_wishlisted themselves. */
    val wishlistedIds: StateFlow<Set<Int>> = _state
        .map { s -> s.products.map { it.id }.toSet() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptySet())

    fun loadWishlist() {
        _state.value = _state.value.copy(isLoading = true, error = null)
        viewModelScope.launch {
            when (val result = repository.getWishlist()) {
                is ApiResult.Success -> _state.value = _state.value.copy(
                    products = result.data.data.map { entry -> entry.product.copy(is_wishlisted = true) },
                    isLoading = false
                )
                is ApiResult.Error -> _state.value = _state.value.copy(
                    isLoading = false, error = result.message
                )
            }
        }
    }

    fun toggleWishlist(productId: Int, product: Product? = null, onResult: ((String) -> Unit)? = null) {
        viewModelScope.launch {
            when (val result = repository.toggle(productId)) {
                is ApiResult.Success -> {
                    if (result.data == "removed") {
                        _state.value = _state.value.copy(
                            products = _state.value.products.filterNot { it.id == productId }
                        )
                    } else if (result.data == "added" && product != null && _state.value.products.none { it.id == productId }) {
                        _state.value = _state.value.copy(
                            products = _state.value.products + product.copy(is_wishlisted = true)
                        )
                    }
                    onResult?.invoke(result.data)
                }
                is ApiResult.Error -> { /* surfaced via snackbar by caller if needed */ }
            }
        }
    }
}
