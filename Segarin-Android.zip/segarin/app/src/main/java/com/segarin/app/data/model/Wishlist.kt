package com.segarin.app.data.model

data class WishlistToggleRequest(val product_id: Int)

data class WishlistToggleResponse(val status: String) // "added" | "removed"

/**
 * GET /wishlist returns a paginated list of Wishlist ROWS (id, user_id,
 * product_id, product), not a paginated list of Product directly.
 */
data class WishlistEntry(
    val id: Int,
    val product_id: Int,
    val product: Product
)
