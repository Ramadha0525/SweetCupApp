package com.segarin.app.ui.screens.home

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.segarin.app.data.model.Category
import com.segarin.app.ui.components.CategoryChip
import com.segarin.app.ui.components.LoadingIndicator
import com.segarin.app.ui.components.ProductCard
import com.segarin.app.ui.components.WhatsAppFab
import com.segarin.app.ui.navigation.Routes
import com.segarin.app.ui.theme.Gray200
import com.segarin.app.ui.theme.Rose500
import com.segarin.app.viewmodel.CartViewModel
import com.segarin.app.viewmodel.ProductViewModel
import com.segarin.app.viewmodel.WishlistViewModel

private val defaultCategories = listOf(
    Category(0, "Semua", "✨", "semua"),
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    productViewModel: ProductViewModel,
    cartViewModel: CartViewModel,
    wishlistViewModel: WishlistViewModel,
    navController: NavHostController
) {
    val listState by productViewModel.listState.collectAsState()
    val wishlistedIds by wishlistViewModel.wishlistedIds.collectAsState()
    var sortMenuExpanded by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { wishlistViewModel.loadWishlist() }

    Scaffold(
        floatingActionButton = { WhatsAppFab() },
        bottomBar = { HomeBottomBar(navController) }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {

            // Search bar
            OutlinedTextField(
                value = listState.searchQuery,
                onValueChange = { productViewModel.onSearchChange(it) },
                placeholder = { Text("Cari es krim, jajanan, minuman...") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                singleLine = true,
                shape = RoundedCornerShape(50),
                colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = Gray200),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
            )

            // Category chips
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(horizontal = 16.dp),
                modifier = Modifier.padding(bottom = 8.dp)
            ) {
                items(defaultCategories + listState.categories) { category ->
                    CategoryChip(
                        label = category.name,
                        icon = category.icon,
                        isSelected = listState.selectedCategoryId == (if (category.id == 0) null else category.id),
                        onClick = {
                            productViewModel.onCategorySelect(if (category.id == 0) null else category.id)
                        }
                    )
                }
            }

            // Sort control
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.End
            ) {
                Box {
                    TextButton(onClick = { sortMenuExpanded = true }) {
                        Text(sortLabel(listState.sort))
                    }
                    DropdownMenu(expanded = sortMenuExpanded, onDismissRequest = { sortMenuExpanded = false }) {
                        DropdownMenuItem(text = { Text("Terbaru") }, onClick = {
                            productViewModel.onSortChange(null); sortMenuExpanded = false
                        })
                        DropdownMenuItem(text = { Text("Harga Terendah") }, onClick = {
                            productViewModel.onSortChange("price_low"); sortMenuExpanded = false
                        })
                        DropdownMenuItem(text = { Text("Harga Tertinggi") }, onClick = {
                            productViewModel.onSortChange("price_high"); sortMenuExpanded = false
                        })
                    }
                }
            }

            when {
                listState.isLoading && listState.products.isEmpty() -> LoadingIndicator(modifier = Modifier.weight(1f))
                listState.error != null && listState.products.isEmpty() -> Box(
                    modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center
                ) {
                    Text(listState.error ?: "Terjadi kesalahan", color = MaterialTheme.colorScheme.error)
                }
                else -> LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    contentPadding = PaddingValues(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(listState.products) { product ->
                        ProductCard(
                            product = product.copy(is_wishlisted = product.id in wishlistedIds),
                            onClick = { navController.navigate(Routes.productDetail(product.slug)) },
                            onAddToCart = { cartViewModel.addToCart(product) },
                            onToggleWishlist = { wishlistViewModel.toggleWishlist(product.id, product) }
                        )
                    }
                    if (listState.currentPage < listState.lastPage) {
                        item {
                            LaunchedEffect(Unit) { productViewModel.loadNextPage() }
                        }
                    }
                }
            }
        }
    }
}

private fun sortLabel(sort: String?): String = when (sort) {
    "price_low" -> "Harga Terendah"
    "price_high" -> "Harga Tertinggi"
    else -> "Terbaru"
}

@Composable
private fun HomeBottomBar(navController: NavHostController) {
    NavigationBar {
        NavigationBarItem(
            selected = true,
            onClick = { },
            icon = { Icon(Icons.Filled.Search, contentDescription = "Home") },
            label = { Text("Home") }
        )
        NavigationBarItem(
            selected = false,
            onClick = { navController.navigate(Routes.WISHLIST) },
            icon = { Icon(Icons.Filled.FavoriteBorder, contentDescription = "Wishlist") },
            label = { Text("Wishlist") }
        )
        NavigationBarItem(
            selected = false,
            onClick = { navController.navigate(Routes.CART) },
            icon = { Icon(Icons.Filled.ShoppingCart, contentDescription = "Keranjang") },
            label = { Text("Keranjang") }
        )
        NavigationBarItem(
            selected = false,
            onClick = { navController.navigate(Routes.ORDERS) },
            icon = { Icon(Icons.Filled.Person, contentDescription = "Pesanan") },
            label = { Text("Pesanan") }
        )
        NavigationBarItem(
            selected = false,
            onClick = { navController.navigate(Routes.PROFILE) },
            icon = { Icon(Icons.Filled.Person, contentDescription = "Profil") },
            label = { Text("Profil") }
        )
    }
}
