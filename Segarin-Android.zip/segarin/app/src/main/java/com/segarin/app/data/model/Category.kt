package com.segarin.app.data.model

data class Category(
    val id: Int,
    val name: String,
    val icon: String,
    val slug: String,
    val products_count: Int = 0
)
