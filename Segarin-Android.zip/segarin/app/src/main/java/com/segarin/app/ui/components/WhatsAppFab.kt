package com.segarin.app.ui.components

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.segarin.app.ui.theme.Green500

/** Floating WhatsApp contact button shown on the Home screen. */
@Composable
fun WhatsAppFab(phoneNumber: String = "6281234567890", modifier: Modifier = Modifier) {
    val context = LocalContext.current
    FloatingActionButton(
        onClick = {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$phoneNumber"))
            context.startActivity(intent)
        },
        containerColor = Green500,
        modifier = modifier.size(56.dp)
    ) {
        Icon(imageVector = Icons.Filled.Chat, contentDescription = "WhatsApp")
    }
}
