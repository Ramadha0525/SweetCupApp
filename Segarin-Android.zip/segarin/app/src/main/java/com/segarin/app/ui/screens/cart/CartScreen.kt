package com.segarin.app.ui.screens.cart

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.segarin.app.data.model.CartItem
import com.segarin.app.data.repository.ApiResult
import com.segarin.app.di.AppModule
import com.segarin.app.ui.components.Base64Image
import com.segarin.app.ui.components.formatRupiah
import com.segarin.app.ui.components.toRupiahLong
import com.segarin.app.ui.navigation.Routes
import com.segarin.app.ui.theme.Gray100
import com.segarin.app.ui.theme.Rose500
import com.segarin.app.ui.theme.Rose600
import com.segarin.app.viewmodel.CartViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CartScreen(cartViewModel: CartViewModel, navController: NavHostController) {
    val summary by cartViewModel.cartSummary.collectAsState()
    var couponCode by remember { mutableStateOf("") }
    val context = LocalContext.current
    val appModule = remember(context) { AppModule.getInstance(context) }

    // The shipping cost is configurable server-side (Setting::get('shipping_cost')),
    // so fetch it once instead of relying on the 20.000 client-side default.
    LaunchedEffect(Unit) {
        when (val result = appModule.productRepository.getPaymentSettings()) {
            is ApiResult.Success -> cartViewModel.setShippingCost(result.data.shipping_cost.toRupiahLong())
            is ApiResult.Error -> { /* keep the default shipping cost */ }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Keranjang") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Kembali")
                    }
                }
            )
        }
    ) { padding ->
        if (summary.items.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text("Keranjang kamu masih kosong.")
            }
            return@Scaffold
        }

        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            LazyColumn(modifier = Modifier.weight(1f).padding(horizontal = 16.dp)) {
                items(summary.items, key = { it.id }) { item ->
                    CartItemRow(
                        item = item,
                        onIncrease = { cartViewModel.updateQuantity(item.id, item.quantity + 1) },
                        onDecrease = { cartViewModel.updateQuantity(item.id, (item.quantity - 1).coerceAtLeast(1)) },
                        onRemove = { cartViewModel.removeItem(item.id) }
                    )
                    Divider()
                }
            }

            Column(modifier = Modifier.padding(16.dp)) {
                // Coupon input
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = couponCode,
                        onValueChange = { couponCode = it },
                        placeholder = { Text("Kode kupon") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(Modifier.width(8.dp))
                    Button(
                        onClick = { cartViewModel.applyCoupon(couponCode.trim()) },
                        colors = ButtonDefaults.buttonColors(containerColor = Rose500),
                        enabled = !summary.isApplyingCoupon
                    ) { Text("Terapkan") }
                }
                if (summary.couponError != null) {
                    Text(summary.couponError ?: "", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
                if (summary.coupon != null) {
                    Text("Kupon '${summary.coupon?.code}' diterapkan", color = Rose600, style = MaterialTheme.typography.bodySmall)
                }

                Spacer(Modifier.height(12.dp))
                SummaryRow("Subtotal", formatRupiah(summary.subtotal))
                SummaryRow("Ongkir", formatRupiah(summary.shippingCost))
                if (summary.discount > 0) SummaryRow("Diskon", "- ${formatRupiah(summary.discount)}")
                Divider(modifier = Modifier.padding(vertical = 6.dp))
                SummaryRow("Total", formatRupiah(summary.total), bold = true)

                Spacer(Modifier.height(12.dp))
                Button(
                    onClick = { navController.navigate(Routes.CHECKOUT) },
                    colors = ButtonDefaults.buttonColors(containerColor = Rose500),
                    modifier = Modifier.fillMaxWidth().height(48.dp)
                ) {
                    Text("Lanjut ke Checkout")
                }
            }
        }
    }
}

@Composable
private fun SummaryRow(label: String, value: String, bold: Boolean = false) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal)
        Text(value, fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal, color = if (bold) Rose600 else MaterialTheme.colorScheme.onSurface)
    }
}

@Composable
private fun CartItemRow(
    item: CartItem,
    onIncrease: () -> Unit,
    onDecrease: () -> Unit,
    onRemove: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Base64Image(
            base64 = item.image,
            modifier = Modifier.size(64.dp).clip(RoundedCornerShape(8.dp))
        )
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(item.name, fontWeight = FontWeight.Medium, maxLines = 1)
            Text(formatRupiah(item.price), color = Rose600)
            Spacer(Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onDecrease, modifier = Modifier.size(28.dp).clip(CircleShape).background(Gray100)) {
                    Icon(Icons.Filled.Remove, contentDescription = "Kurangi", modifier = Modifier.size(16.dp))
                }
                Text("${item.quantity}", modifier = Modifier.padding(horizontal = 12.dp))
                IconButton(onClick = onIncrease, modifier = Modifier.size(28.dp).clip(CircleShape).background(Gray100)) {
                    Icon(Icons.Filled.Add, contentDescription = "Tambah", modifier = Modifier.size(16.dp))
                }
            }
        }
        IconButton(onClick = onRemove) {
            Icon(Icons.Filled.Delete, contentDescription = "Hapus", tint = MaterialTheme.colorScheme.error)
        }
    }
}
