package com.segarin.app.data.model

/** value comes back as a String (e.g. "20.00") because of Eloquent's decimal:2 cast. */
data class Coupon(
    val code: String,
    val type: String, // "percentage" or "fixed"
    val value: String
)

data class CouponRequest(val code: String)
