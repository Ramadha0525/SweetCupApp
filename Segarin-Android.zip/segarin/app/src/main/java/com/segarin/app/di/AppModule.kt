package com.segarin.app.di

import android.content.Context
import com.segarin.app.data.api.ApiService
import com.segarin.app.data.api.RetrofitClient
import com.segarin.app.data.local.CartStore
import com.segarin.app.data.local.TokenManager
import com.segarin.app.data.repository.*

/**
 * Simple manual dependency container (no Hilt/Dagger to keep the
 * project lightweight and easy to build). Singletons are created lazily
 * and scoped to the Application context.
 */
class AppModule(context: Context) {

    val tokenManager: TokenManager = TokenManager(context.applicationContext)
    val cartStore: CartStore = CartStore(context.applicationContext)

    private val apiService: ApiService = RetrofitClient.getApiService(tokenManager)

    val authRepository: AuthRepository = AuthRepository(apiService, tokenManager)
    val productRepository: ProductRepository = ProductRepository(apiService)
    val wishlistRepository: WishlistRepository = WishlistRepository(apiService)
    val cartRepository: CartRepository = CartRepository(apiService, cartStore)
    val orderRepository: OrderRepository = OrderRepository(apiService)

    companion object {
        @Volatile
        private var INSTANCE: AppModule? = null

        fun getInstance(context: Context): AppModule {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: AppModule(context).also { INSTANCE = it }
            }
        }
    }
}
