package com.segarin.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.segarin.app.data.model.Order
import com.segarin.app.ui.theme.*

data class StatusStyle(val label: String, val color: Color)

fun statusStyle(status: String): StatusStyle = when (status) {
    "pending" -> StatusStyle("Menunggu Pembayaran", Yellow500)
    "paid" -> StatusStyle("Lunas", Blue500)
    "processing" -> StatusStyle("Diproses", Purple500)
    "shipped" -> StatusStyle("Dikirim", Indigo500)
    "delivered" -> StatusStyle("Diterima", Green500)
    "cancelled" -> StatusStyle("Dibatalkan", Red500)
    else -> StatusStyle(status, Gray500)
}

@Composable
fun OrderCard(order: Order, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val style = statusStyle(order.status)
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color.White)
            .border(1.dp, Gray100, RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(order.order_code, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(style.color.copy(alpha = 0.15f))
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Text(style.label, color = style.color, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
            }
        }
        Spacer(Modifier.height(6.dp))
        val imgs = order.items?.take(3).orEmpty()
        if (imgs.isNotEmpty()) {
            Row {
                imgs.forEach { item ->
                    Base64Image(
                        base64 = item.product?.image,
                        modifier = Modifier
                            .size(48.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .padding(end = 4.dp)
                    )
                }
                val extra = (order.items?.size ?: 0) - imgs.size
                if (extra > 0) {
                    Box(
                        modifier = Modifier.size(48.dp).clip(RoundedCornerShape(8.dp)).background(Gray100),
                        contentAlignment = androidx.compose.ui.Alignment.Center
                    ) {
                        Text("+$extra lagi", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                order.created_at ?: "",
                color = Gray500,
                style = MaterialTheme.typography.bodySmall
            )
            Text(
                formatRupiah(order.total_amount),
                fontWeight = FontWeight.Bold,
                color = Rose600,
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}
