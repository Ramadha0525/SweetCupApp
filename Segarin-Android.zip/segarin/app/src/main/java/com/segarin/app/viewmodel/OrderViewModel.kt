package com.segarin.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.segarin.app.data.model.*
import com.segarin.app.data.repository.ApiResult
import com.segarin.app.data.repository.OrderRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed class CheckoutUiState {
    object Idle : CheckoutUiState()
    object Loading : CheckoutUiState()
    data class ManualSuccess(val response: ManualCheckoutResponse) : CheckoutUiState()
    data class MidtransSuccess(val response: CheckoutResponse) : CheckoutUiState()
    data class Error(val message: String) : CheckoutUiState()
}

data class OrdersListState(
    val orders: List<Order> = emptyList(),
    val statusFilter: String? = null,
    val isLoading: Boolean = false,
    val error: String? = null
)

sealed class OrderDetailUiState {
    object Loading : OrderDetailUiState()
    data class Success(val order: Order) : OrderDetailUiState()
    data class Error(val message: String) : OrderDetailUiState()
}

class OrderViewModel(private val repository: OrderRepository) : ViewModel() {

    private val _checkoutState = MutableStateFlow<CheckoutUiState>(CheckoutUiState.Idle)
    val checkoutState: StateFlow<CheckoutUiState> = _checkoutState.asStateFlow()

    private val _ordersState = MutableStateFlow(OrdersListState())
    val ordersState: StateFlow<OrdersListState> = _ordersState.asStateFlow()

    private val _orderDetailState = MutableStateFlow<OrderDetailUiState>(OrderDetailUiState.Loading)
    val orderDetailState: StateFlow<OrderDetailUiState> = _orderDetailState.asStateFlow()

    fun checkoutMidtrans(request: CheckoutRequest) {
        _checkoutState.value = CheckoutUiState.Loading
        viewModelScope.launch {
            when (val result = repository.checkout(request)) {
                is ApiResult.Success -> _checkoutState.value = CheckoutUiState.MidtransSuccess(result.data)
                is ApiResult.Error -> _checkoutState.value = CheckoutUiState.Error(result.message)
            }
        }
    }

    fun checkoutManual(request: ManualCheckoutRequest) {
        _checkoutState.value = CheckoutUiState.Loading
        viewModelScope.launch {
            when (val result = repository.checkoutManual(request)) {
                is ApiResult.Success -> _checkoutState.value = CheckoutUiState.ManualSuccess(result.data)
                is ApiResult.Error -> _checkoutState.value = CheckoutUiState.Error(result.message)
            }
        }
    }

    fun resetCheckoutState() {
        _checkoutState.value = CheckoutUiState.Idle
    }

    fun loadOrders(status: String? = null) {
        _ordersState.value = _ordersState.value.copy(isLoading = true, statusFilter = status, error = null)
        viewModelScope.launch {
            when (val result = repository.getOrders(status)) {
                is ApiResult.Success -> _ordersState.value = _ordersState.value.copy(
                    orders = result.data.data, isLoading = false
                )
                is ApiResult.Error -> _ordersState.value = _ordersState.value.copy(
                    isLoading = false, error = result.message
                )
            }
        }
    }

    fun loadOrderDetail(id: Int) {
        _orderDetailState.value = OrderDetailUiState.Loading
        viewModelScope.launch {
            when (val result = repository.getOrderDetail(id)) {
                is ApiResult.Success -> _orderDetailState.value = OrderDetailUiState.Success(result.data)
                is ApiResult.Error -> _orderDetailState.value = OrderDetailUiState.Error(result.message)
            }
        }
    }
}
