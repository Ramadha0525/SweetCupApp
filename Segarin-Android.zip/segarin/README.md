# Segarin — Android App (Kotlin + Jetpack Compose)

Aplikasi ordering es krim cup, jajanan, dan minuman. Native Android, tanpa WebView.

## Cara membuka & menjalankan

1. Buka **Android Studio** (versi Koala/2024.1 ke atas direkomendasikan).
2. `File > Open` lalu pilih folder `segarin` ini.
3. Tunggu Gradle sync selesai (Android Studio akan otomatis membuatkan `gradle-wrapper` jika belum ada — pastikan koneksi internet aktif untuk mengunduh dependency pertama kali).
4. Jalankan di emulator atau device fisik (Run ▶).

## Struktur proyek

Mengikuti arsitektur MVVM sesuai spesifikasi:
- `data/model` — data class (User, Product, Order, dll)
- `data/api` — Retrofit `ApiService`, `AuthInterceptor`, `RetrofitClient`
- `data/repository` — jembatan antara API dan ViewModel, membungkus hasil dengan `ApiResult`
- `data/local` — `TokenManager` (DataStore, token & sesi) dan `CartStore` (DataStore, cart offline-first)
- `viewmodel` — satu ViewModel per domain (Auth, Product, Cart, Order, Wishlist)
- `ui/screens` — satu folder per layar sesuai spesifikasi
- `ui/components` — komponen reusable (ProductCard, CategoryChip, OrderCard, RatingBar, Base64Image, dll)
- `di/AppModule.kt` — dependency container manual (tanpa Hilt, supaya ringan)

## Koreksi setelah audit source code Laravel asli

Project ini awalnya dibuat dari `API_DOCUMENTATION.md`, tapi setelah membaca langsung controller & model Laravel-nya, ditemukan beberapa perbedaan nyata yang sudah diperbaiki di kode:

1. **Harga & jumlah uang dikirim sebagai STRING**, bukan angka — karena kolom `price`/`total_amount`/`unique_amount`/`value` di-cast `decimal:2` oleh Eloquent, contoh: `"price": "15000.00"`. Semua model (`Product`, `Order`, `OrderItem`, `Coupon`) sudah pakai tipe `String` untuk field ini, dengan helper `String?.toRupiahLong()` di `Formatters.kt` untuk konversi ke `Long`. (Pengecualian: response langsung dari `/checkout` dan `/checkout/manual` tetap angka biasa karena itu variabel PHP mentah, bukan atribut Eloquent.)
2. **Pagination Laravel itu flat**, bukan nested `links`/`meta` seperti dugaan awal — `PaginatedData<T>` sekarang punya `current_page`, `last_page`, `total`, dll langsung di level atas.
3. **`GET /wishlist` mengembalikan baris Wishlist**, bukan Product langsung — tiap item punya `product_id` dan `product` (nested). Ditangani lewat model baru `WishlistEntry`.
4. **`average_rating` dan `reviews_count` tidak pernah dikirim API** (accessor-nya tidak di-`$appends`) — dihitung sendiri di client dari array `reviews` (hanya tersedia di endpoint detail produk, bukan di list).
5. **`is_wishlisted` juga tidak dikirim API** — Home screen sekarang fetch `/wishlist` sekali lalu cross-reference ID produk secara lokal supaya ikon hati akurat.
6. Nilai **`sort` yang valid adalah `price_low` / `price_high`** (bukan `price_asc`/`price_desc` seperti di dokumentasi awal).
7. Field tracking pengiriman namanya **`resi_code`**, bukan `tracking_number`.
8. `OrderItem` dari `/orders` berisi `product` (objek Product lengkap), bukan `name`/`image` langsung.
9. `Review` dari endpoint detail produk berisi `user` (objek nested), bukan `user_name` string.
10. Field **`notes` di checkout tidak benar-benar tersimpan** — kolom itu tidak ada di tabel `orders` maupun `$fillable` Order model, jadi nilainya di-drop diam-diam oleh Laravel. UI catatan tetap ada, tapi kalau kamu mau catatan benar-benar tersimpan, perlu ditambahkan migration `notes` + fillable di sisi backend.
11. `PaymentSettings` ditambah `cod_instructions`, `ewallet_instructions`, `qris_instructions` yang ternyata ada di `PaymentController@settings`.
12. Retrofit's `response.body()` selalu `null` untuk status non-2xx (400/422/dst) — pesan error asli dari Laravel (termasuk validasi per-field) ada di `errorBody()`. Ditangani lewat `ApiErrorUtils.errorMessage()` supaya pesan error yang tampil ke user itu asli dari server, bukan cuma fallback generik.

## Hal-hal yang perlu kamu lengkapi sendiri

1. **Midtrans Snap SDK** — kerangka checkout untuk Midtrans sudah ada (`CheckoutScreen` memanggil `checkoutMidtrans`, dan `PaymentResultScreen` menampilkan konfirmasi), tapi integrasi Snap SDK sesungguhnya (`implementation("com.midtrans:uikit:...")` + `MidtransSDK.init(...)`) belum ditambahkan karena butuh Client Key dari dashboard Midtrans kamu. Tambahkan dependency-nya di `app/build.gradle.kts` lalu panggil Snap dengan `snap_token` yang sudah dikembalikan API di `CheckoutUiState.MidtransSuccess`.
2. **Upload bukti transfer** (E-Wallet/QRIS) — endpoint-nya sebenarnya sudah ada di backend (`POST /payments/upload-proof`, lihat `UserCheckoutController@uploadProof`), tapi didaftarkan di `routes/web.php` dengan autentikasi sesi/cookie (bukan di `routes/api.php` dengan middleware `api.auth` berbasis Bearer token). Supaya bisa dipakai dari app Android, endpoint ini perlu dipindah/didaftarkan ulang di `routes/api.php` dalam group `api.auth`. Setelah itu tinggal tambahkan `Uri` picker + multipart request di `PaymentResultScreen`.
3. **App icon** — saat ini pakai vector sederhana warna rose. Ganti `drawable/ic_launcher_foreground.xml` dengan logo asli kalau sudah ada.
4. **google-services / signing config** — belum ditambahkan karena tidak disebutkan di spesifikasi (tidak pakai Firebase).

## Catatan implementasi

- Semua gambar produk didekode dari base64 lewat komponen `Base64Image` (tidak pakai Coil untuk base64 karena Coil butuh URL/file; base64 didekode manual dengan `BitmapFactory`).
- Cart disimpan lokal di DataStore (`CartStore`), baru dikirim ke server saat checkout — sesuai catatan "offline-first" di spesifikasi.
- Kode unik pembayaran (`unique_code`, `unique_amount`) diambil langsung dari response API, bukan dihitung di client, supaya konsisten dengan server.
- Format mata uang: `Rp XX.XXX` tanpa desimal (lihat `ui/components/Formatters.kt`).
