<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('orders', function (Blueprint $table) {
            $table->string('payment_method')->nullable()->after('snap_token');
            $table->integer('unique_code')->nullable()->after('payment_method');
            $table->decimal('unique_amount', 15, 2)->nullable()->after('unique_code');
            $table->text('payment_proof')->nullable()->after('unique_amount');
            $table->enum('manual_payment_status', ['pending_confirmation', 'confirmed', 'rejected'])->nullable()->after('payment_proof');
            $table->text('manual_payment_note')->nullable()->after('manual_payment_status');
        });
    }

    public function down(): void
    {
        Schema::table('orders', function (Blueprint $table) {
            $table->dropColumn([
                'payment_method',
                'unique_code',
                'unique_amount',
                'payment_proof',
                'manual_payment_status',
                'manual_payment_note',
            ]);
        });
    }
};
