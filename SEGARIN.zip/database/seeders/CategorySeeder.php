<?php

namespace Database\Seeders;

use App\Models\Category;
use Illuminate\Database\Seeder;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;

class CategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $categories = [
            [
                'name' => 'Es Krim Cup',
                'description' => 'Es krim cup berbagai rasa lembut dan nikmat dengan topping melimpah',
            ],
            [
                'name' => 'Es Tradisional & Cendol',
                'description' => 'Es serut tradisional, cendol, doger, dan es campur legendaris',
            ],
            [
                'name' => 'Jajanan Siap Antar',
                'description' => 'Camilan gurih dan manis hangat yang siap menemani hari Anda',
            ],
            [
                'name' => 'Minuman Segar',
                'description' => 'Minuman segar pelepas dahaga dari teh murni hingga thai tea premium',
            ]
        ];

        foreach ($categories as $category) {
            Category::create($category);
        }
    }
}