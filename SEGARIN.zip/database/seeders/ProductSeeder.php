<?php

namespace Database\Seeders;

use Exception;
use App\Models\Product;
use App\Models\Category;
use Illuminate\Support\Str;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Http;

class ProductSeeder extends Seeder
{
    private function downloadAndConvertToBase64($imageUrl)
    {
        try {
            $response = Http::timeout(10)->get($imageUrl);
            if ($response->successful()) {
                $imageData = $response->body();
                $base64 = base64_encode($imageData);
                return "data:image/png;base64," . $base64;
            }
        } catch (Exception $e) {
            \Log::error("Error downloading image from {$imageUrl}: " . $e->getMessage());
        }
        return null;
    }

    public function run(): void
    {
        // Product Data
        $allProducts = [
            'Es Krim Cup' => [
                [
                    'name' => 'Es Krim Vanilla Cup Premium',
                    'price' => '12000.00',
                    'stock' => 100,
                    'description' => 'Es krim cup rasa vanilla lembut premium dengan topping saus cokelat dan taburan kacang.',
                    'image_url' => 'https://dummyimage.com/600x600/fecdd3/be123c.png&text=Es+Krim+Vanilla'
                ],
                [
                    'name' => 'Es Krim Cokelat Choco Chips',
                    'price' => '12000.00',
                    'stock' => 100,
                    'description' => 'Es krim cokelat pekat nan manis dengan taburan choco chips melimpah yang renyah.',
                    'image_url' => 'https://dummyimage.com/600x600/fecdd3/be123c.png&text=Es+Krim+Cokelat'
                ],
                [
                    'name' => 'Es Krim Durian Kupang',
                    'price' => '15000.00',
                    'stock' => 50,
                    'description' => 'Es krim durian murni dengan daging buah durian asli di dalamnya, aroma mantap.',
                    'image_url' => 'https://dummyimage.com/600x600/fecdd3/be123c.png&text=Es+Krim+Durian'
                ],
                [
                    'name' => 'Es Krim Matcha Latte Cup',
                    'price' => '15000.00',
                    'stock' => 75,
                    'description' => 'Es krim matcha khas Jepang dengan rasa teh hijau premium yang seimbang antara manis dan sedikit pahit.',
                    'image_url' => 'https://dummyimage.com/600x600/fecdd3/be123c.png&text=Es+Krim+Matcha'
                ],
            ],
            'Es Tradisional & Cendol' => [
                [
                    'name' => 'Es Cendol Nangka Cup',
                    'price' => '10000.00',
                    'stock' => 120,
                    'description' => 'Es cendol kenyal pandan dengan santan gurih, saus gula aren legit, dan potongan nangka wangi.',
                    'image_url' => 'https://dummyimage.com/600x600/bbf7d0/15803d.png&text=Es+Cendol+Nangka'
                ],
                [
                    'name' => 'Es Doger Tape Ketan',
                    'price' => '12000.00',
                    'stock' => 80,
                    'description' => 'Es doger legendaris dengan serutan es kelapa, lengkap dengan topping tape ketan hitam, pacar cina, dan roti tawar.',
                    'image_url' => 'https://dummyimage.com/600x600/bbf7d0/15803d.png&text=Es+Doger+Ketan'
                ],
                [
                    'name' => 'Es Teler Cup Spesial',
                    'price' => '15000.00',
                    'stock' => 90,
                    'description' => 'Es teler berisi alpukat mentega potong, daging kelapa muda, nangka wangi, susu kental manis, dan sirup spesial.',
                    'image_url' => 'https://dummyimage.com/600x600/bbf7d0/15803d.png&text=Es+Teler+Cup'
                ],
                [
                    'name' => 'Es Campur Serut Jelly',
                    'price' => '12000.00',
                    'stock' => 110,
                    'description' => 'Es serut dengan sirup cocopandan merah, berisi aneka buah jelly kenyal, kolang-kaling, dan susu kental manis.',
                    'image_url' => 'https://dummyimage.com/600x600/bbf7d0/15803d.png&text=Es+Campur+Serut'
                ],
            ],
            'Jajanan Siap Antar' => [
                [
                    'name' => 'Cireng Rujak Pedas (Isi 10)',
                    'price' => '15000.00',
                    'stock' => 150,
                    'description' => 'Cireng renyah di luar kenyal di dalam, disajikan hangat dengan bumbu rujak pedas manis asam yang segar.',
                    'image_url' => 'https://dummyimage.com/600x600/fed7aa/c2410c.png&text=Cireng+Rujak'
                ],
                [
                    'name' => 'Cilok Goang Kuah Pedas',
                    'price' => '12000.00',
                    'stock' => 100,
                    'description' => 'Cilok kenyal berisi daging sapi cincang, disiram kuah goang pedas daun jeruk kencur yang segar dan menghangatkan.',
                    'image_url' => 'https://dummyimage.com/600x600/fed7aa/c2410c.png&text=Cilok+Goang'
                ],
                [
                    'name' => 'Dimsum Ayam Jamur (Isi 5)',
                    'price' => '18000.00',
                    'stock' => 80,
                    'description' => 'Dimsum kukus lembut dengan isian daging ayam premium dan jamur kuping, disajikan dengan saus dimsum asam manis pedas.',
                    'image_url' => 'https://dummyimage.com/600x600/fed7aa/c2410c.png&text=Dimsum+Ayam'
                ],
                [
                    'name' => 'Batagor Bandung Kuah Kacang',
                    'price' => '15000.00',
                    'stock' => 60,
                    'description' => 'Bakso tahu goreng renyah disiram dengan saus kacang gurih kental khas Bandung, kecap manis, dan perasan jeruk limau.',
                    'image_url' => 'https://dummyimage.com/600x600/fed7aa/c2410c.png&text=Batagor+Bandung'
                ],
                [
                    'name' => 'Risol Mayo Lumer (Isi 3)',
                    'price' => '12000.00',
                    'stock' => 120,
                    'description' => 'Risol renyah dengan isian potongan telur rebus, daging asap, dan saus mayones spesial gurih lumer di mulut.',
                    'image_url' => 'https://dummyimage.com/600x600/fed7aa/c2410c.png&text=Risol+Mayo'
                ],
            ],
            'Minuman Segar' => [
                [
                    'name' => 'Es Teh Manis Jumbo',
                    'price' => '5000.00',
                    'stock' => 300,
                    'description' => 'Es teh manis segar ukuran jumbo dari seduhan teh melati pilihan yang harum.',
                    'image_url' => 'https://dummyimage.com/600x600/bfdbfe/1d4ed8.png&text=Es+Teh+Manis'
                ],
                [
                    'name' => 'Es Jeruk Peras Murni',
                    'price' => '8000.00',
                    'stock' => 150,
                    'description' => 'Perasan jeruk peras manis segar alami tanpa tambahan pemanis buatan, disajikan dingin.',
                    'image_url' => 'https://dummyimage.com/600x600/bfdbfe/1d4ed8.png&text=Es+Jeruk+Peras'
                ],
                [
                    'name' => 'Thai Tea Signature Cup',
                    'price' => '10000.00',
                    'stock' => 200,
                    'description' => 'Teh hitam khas Thailand diseduh wangi dicampur dengan susu kental manis dan susu evaporasi gurih.',
                    'image_url' => 'https://dummyimage.com/600x600/bfdbfe/1d4ed8.png&text=Thai+Tea+Cup'
                ],
                [
                    'name' => 'Es Susu Kurma Segar',
                    'price' => '12000.00',
                    'stock' => 100,
                    'description' => 'Minuman sehat perpaduan susu segar berkualitas dan buah kurma premium pilihan yang dihaluskan.',
                    'image_url' => 'https://dummyimage.com/600x600/bfdbfe/1d4ed8.png&text=Es+Susu+Kurma'
                ],
            ],
        ];

        // Create products
        foreach ($allProducts as $categoryName => $products) {
            $category = Category::where('name', $categoryName)->first();

            if (!$category) {
                continue;
            }

            foreach ($products as $productData) {
                try {
                    $base64Image = $this->downloadAndConvertToBase64($productData['image_url']);
                    
                    Product::create([
                        'category_id' => $category->id,
                        'name' => $productData['name'],
                        'slug' => Str::slug($productData['name']),
                        'price' => $productData['price'],
                        'stock' => $productData['stock'],
                        'description' => $productData['description'],
                        'is_active' => true,
                        'image' => $base64Image ?? 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=' // fallback transparent pixel
                    ]);

                    $this->command->info("Created product: {$productData['name']}");

                } catch (Exception $e) {
                    $this->command->error("Error creating product {$productData['name']}: " . $e->getMessage());
                }
            }
        }
    }
}
