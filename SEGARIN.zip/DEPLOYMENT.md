# Panduan Deployment SweetCup E-Commerce

## Persiapan Hosting

### 1. Upload File
- Upload semua file ke public_html atau folder yang sesuai
- Pastikan folder `storage` dan `bootstrap/cache` writable

### 2. Setup Database
- Buat database baru di cPanel/hosting
- Import file `e_commerce_mid.sql`
- Update `.env` dengan kredensial database

### 3. Konfigurasi .env
```
APP_NAME="SweetCup Delivery"
APP_ENV=production
APP_KEY=base64:generate_dengan_php_artisan_key_generate
APP_DEBUG=false
APP_URL=https://domain-anda.com

DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=nama_database
DB_USERNAME=username_database
DB_PASSWORD=password_database
```

### 4. Jalankan Perintah
```bash
php artisan key:generate
php artisan config:cache
php artisan route:cache
php artisan view:cache
php artisan migrate --force
```

### 5. Setting Folder Permission
```
chmod -R 775 storage
chmod -R 775 bootstrap/cache
```

## Fitur yang Tersedia

### Frontend (User)
- Landing page dengan produk, kategori, pencarian
- Keranjang belanja
- Checkout dengan multiple payment method
- Riwayat pesanan
- Wishlist
- Profil user

### Backend (Admin)
- Dashboard
- Kelola Kategori (dengan icon emoji)
- Kelola Produk
- Kelola Pesanan
- Kelola Kupon Diskon
- Kelola User
- Pengaturan Web (toko, tema warna, footer)
- Pengaturan Pembayaran Manual (COD, E-Wallet, QRIS)
- Pengaturan Midtrans
- Gateway WhatsApp

### API untuk Mobile
- Register, Login, Logout
- Produk, Kategori
- Checkout (Midtrans & Manual)
- Pesanan
- Review
- Wishlist
- Kupon

## Akun Default

### Admin
- Email: admin@sweetcup.com
- Password: password

### User
- Email: user@sweetcup.com
- Password: password

## Tips

1. **Midtrans**: Daftar di midtrans.com, dapatkan API keys, masukkan di Settings → Konfigurasi Midtrans
2. **WhatsApp**: Daftar di fonnte.com untuk kirim notifikasi via WhatsApp
3. **Tema Warna**: Bisa diubah di Settings → Pengaturan Web → Tema Warna
4. **Kode Unik**: Untuk pembayaran E-Wallet dan QRIS, kode unik otomatis ditambahkan (contoh: Rp 35.627)

## Troubleshooting

1. **Error 500**: Cek log di storage/logs/laravel.log
2. **Database Error**: Pastikan .env sudah benar dan database sudah di-import
3. **Permission Error**: Set folder permission ke 775
4. **CSS/JS tidak muncul**: Jalankan `php artisan storage:link`
