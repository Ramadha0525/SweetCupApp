<?php

use App\Models\Setting;

/*
 * Midtrans configuration.
 * Values are read from the database (settings table) managed via admin panel.
 * Falls back to .env values if database is unavailable (e.g. during migration).
 */
function midtransSetting(string $key, $fallback = null)
{
    try {
        return Setting::get($key, $fallback);
    } catch (\Throwable $e) {
        return $fallback;
    }
}

$isProduction = midtransSetting('midtrans_is_production', env('MIDTRANS_IS_PRODUCTION', false));
$isProduction = filter_var($isProduction, FILTER_VALIDATE_BOOLEAN);

return [
    'merchant_id'  => midtransSetting('midtrans_merchant_id', env('MIDTRANS_MERCHANT_ID')),
    'client_key'   => midtransSetting('midtrans_client_key',  env('MIDTRANS_CLIENT_KEY')),
    'server_key'   => midtransSetting('midtrans_server_key',  env('MIDTRANS_SERVER_KEY')),
    'is_production' => $isProduction,
    'is_sanitized'  => true,
    'enable_3ds'    => true,
    'payment_url'   => $isProduction
        ? 'https://app.midtrans.com/snap/snap.js'
        : 'https://app.sandbox.midtrans.com/snap/snap.js',
];