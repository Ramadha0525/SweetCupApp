@extends('layouts.layout-admin')

@section('title', 'Metode Pembayaran Manual')

@section('header_title', 'Metode Pembayaran Manual')
@section('header_subtitle', 'Konfigurasi pembayaran COD, E-Wallet, dan QRIS')

@section('content')
    <div class="max-w-3xl mx-auto space-y-6">

        @if (session('success'))
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                {{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif

        @if (session('error'))
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                {{ session('error') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif

        <form action="{{ route('admin.settings.manual-payment.store') }}" method="POST" enctype="multipart/form-data" class="space-y-6">
            @csrf

            {{-- Shipping Cost --}}
            <div class="bg-white rounded-2xl p-6 shadow-sm">
                <div class="flex items-center gap-3 mb-4">
                    <div class="w-10 h-10 rounded-lg bg-orange-100 flex items-center justify-center">
                        <svg class="w-5 h-5 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4"/>
                        </svg>
                    </div>
                    <div>
                        <h3 class="text-lg font-semibold text-gray-900">Ongkos Kirim</h3>
                        <p class="text-sm text-gray-500">Atur biaya pengiriman untuk semua pesanan</p>
                    </div>
                </div>
                <div>
                    <label for="shipping_cost" class="block text-sm font-medium text-gray-700 mb-1">Biaya Ongkir (Rp)</label>
                    <input type="number" name="shipping_cost" id="shipping_cost"
                        value="{{ $settings['shipping_cost'] }}"
                        min="0"
                        class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-rose-200 focus:border-rose-500 transition">
                    <p class="text-xs text-gray-500 mt-1">Masukkan nominal tanpa titik atau koma (contoh: 20000)</p>
                </div>
            </div>

            {{-- Global Toggle --}}
            <div class="bg-white rounded-2xl p-6 shadow-sm">
                <div class="flex items-center justify-between">
                    <div>
                        <h3 class="text-lg font-semibold text-gray-900">Aktifkan Pembayaran Manual</h3>
                        <p class="text-sm text-gray-500 mt-1">Aktifkan atau nonaktifkan semua metode pembayaran manual</p>
                    </div>
                    <label class="relative inline-flex items-center cursor-pointer">
                        <input type="checkbox" name="manual_payment_enabled" value="1"
                            class="sr-only peer"
                            {{ $settings['manual_payment_enabled'] == '1' ? 'checked' : '' }}>
                        <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-rose-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-rose-500"></div>
                    </label>
                </div>
            </div>

            {{-- COD Settings --}}
            <div class="bg-white rounded-2xl p-6 shadow-sm">
                <div class="flex items-center justify-between mb-4">
                    <div class="flex items-center gap-3">
                        <div class="w-10 h-10 rounded-lg bg-green-100 flex items-center justify-center">
                            <svg class="w-5 h-5 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z"/>
                            </svg>
                        </div>
                        <div>
                            <h3 class="text-lg font-semibold text-gray-900">Bayar di Tempat (COD)</h3>
                            <p class="text-sm text-gray-500">Pembayaran tunai saat pesanan tiba</p>
                        </div>
                    </div>
                    <label class="relative inline-flex items-center cursor-pointer">
                        <input type="checkbox" name="cod_enabled" value="1"
                            class="sr-only peer"
                            {{ $settings['cod_enabled'] == '1' ? 'checked' : '' }}>
                        <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-rose-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-rose-500"></div>
                    </label>
                </div>
                <div>
                    <label for="cod_instructions" class="block text-sm font-medium text-gray-700 mb-1">Instruksi COD</label>
                    <textarea name="cod_instructions" rows="3"
                        class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-rose-200 focus:border-rose-500 transition"
                        placeholder="Instruksi untuk pembayaran COD...">{{ $settings['cod_instructions'] }}</textarea>
                </div>
            </div>

            {{-- E-Wallet Settings --}}
            <div class="bg-white rounded-2xl p-6 shadow-sm">
                <div class="flex items-center justify-between mb-4">
                    <div class="flex items-center gap-3">
                        <div class="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
                            <svg class="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z"/>
                            </svg>
                        </div>
                        <div>
                            <h3 class="text-lg font-semibold text-gray-900">E-Wallet</h3>
                            <p class="text-sm text-gray-500">Transfer manual ke E-Wallet</p>
                        </div>
                    </div>
                    <label class="relative inline-flex items-center cursor-pointer">
                        <input type="checkbox" name="ewallet_enabled" value="1"
                            class="sr-only peer"
                            {{ $settings['ewallet_enabled'] == '1' ? 'checked' : '' }}>
                        <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-rose-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-rose-500"></div>
                    </label>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label for="ewallet_name" class="block text-sm font-medium text-gray-700 mb-1">Nama E-Wallet</label>
                        <input type="text" name="ewallet_name" id="ewallet_name"
                            value="{{ $settings['ewallet_name'] }}"
                            placeholder="Contoh: GoPay, OVO, DANA"
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-rose-200 focus:border-rose-500 transition">
                    </div>
                    <div>
                        <label for="ewallet_number" class="block text-sm font-medium text-gray-700 mb-1">Nomor E-Wallet</label>
                        <input type="text" name="ewallet_number" id="ewallet_number"
                            value="{{ $settings['ewallet_number'] }}"
                            placeholder="08xxxxxxxxxx"
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-rose-200 focus:border-rose-500 transition">
                    </div>
                </div>
                <div class="mt-4">
                    <label for="ewallet_owner" class="block text-sm font-medium text-gray-700 mb-1">Atas Nama</label>
                    <input type="text" name="ewallet_owner" id="ewallet_owner"
                        value="{{ $settings['ewallet_owner'] }}"
                        placeholder="Nama pemilik rekening/E-Wallet"
                        class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-rose-200 focus:border-rose-500 transition">
                </div>
                <div class="mt-4">
                    <label for="ewallet_instructions" class="block text-sm font-medium text-gray-700 mb-1">Instruksi E-Wallet</label>
                    <textarea name="ewallet_instructions" rows="3"
                        class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-rose-200 focus:border-rose-500 transition"
                        placeholder="Instruksi untuk pembayaran E-Wallet...">{{ $settings['ewallet_instructions'] }}</textarea>
                </div>
            </div>

            {{-- QRIS Settings --}}
            <div class="bg-white rounded-2xl p-6 shadow-sm">
                <div class="flex items-center justify-between mb-4">
                    <div class="flex items-center gap-3">
                        <div class="w-10 h-10 rounded-lg bg-purple-100 flex items-center justify-center">
                            <svg class="w-5 h-5 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v1m6 11h2m-6 0h-2v4m0-11v3m0 0h.01M12 12h4.01M16 20h4M4 12h4m12 0h.01M5 8h2a1 1 0 001-1V5a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1zm12 0h2a1 1 0 001-1V5a1 1 0 00-1-1h-2a1 1 0 00-1 1v2a1 1 0 001 1zM5 20h2a1 1 0 001-1v-2a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1z"/>
                            </svg>
                        </div>
                        <div>
                            <h3 class="text-lg font-semibold text-gray-900">QRIS</h3>
                            <p class="text-sm text-gray-500">Pembayaran via scan QR Code</p>
                        </div>
                    </div>
                    <label class="relative inline-flex items-center cursor-pointer">
                        <input type="checkbox" name="qris_enabled" value="1"
                            class="sr-only peer"
                            {{ $settings['qris_enabled'] == '1' ? 'checked' : '' }}>
                        <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-rose-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-rose-500"></div>
                    </label>
                </div>

                <div>
                    <label for="qris_image" class="block text-sm font-medium text-gray-700 mb-1">Foto Kode QRIS</label>
                    @if ($settings['qris_image'])
                        <div class="mb-3">
                            <img src="{{ $settings['qris_image'] }}" alt="QRIS Code" class="w-48 h-48 object-contain border rounded-lg">
                        </div>
                    @endif
                    <input type="file" name="qris_image" id="qris_image" accept="image/*"
                        class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-rose-200 focus:border-rose-500 transition">
                    <p class="text-xs text-gray-500 mt-1">Format: JPG, PNG, GIF. Maks 2MB.</p>
                </div>
                <div class="mt-4">
                    <label for="qris_instructions" class="block text-sm font-medium text-gray-700 mb-1">Instruksi QRIS</label>
                    <textarea name="qris_instructions" rows="3"
                        class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-rose-200 focus:border-rose-500 transition"
                        placeholder="Instruksi untuk pembayaran QRIS...">{{ $settings['qris_instructions'] }}</textarea>
                </div>
            </div>

            {{-- Submit --}}
            <div class="bg-white rounded-2xl p-6 shadow-sm">
                <div class="flex justify-end">
                    <button type="submit"
                        class="px-6 py-2.5 bg-rose-500 hover:bg-rose-600 text-white font-medium rounded-lg transition shadow-sm">
                        Simpan Konfigurasi
                    </button>
                </div>
            </div>
        </form>
    </div>
@endsection
