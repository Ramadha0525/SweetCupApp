@extends('layouts.layout-admin')

@section('title', 'Kupon')

@section('header_title', 'Kupon')
@section('header_subtitle', 'Kelola kupon diskon')

@section('content')
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h4 class="mb-1 fw-bold">Daftar Kupon</h4>
                <p class="text-muted small mb-0">Total: {{ $coupons->total() }} kupon</p>
            </div>
            <button type="button" class="btn btn-rose" data-bs-toggle="modal" data-bs-target="#addCouponModal">
                <i class="bi bi-plus-lg me-1"></i> Tambah Kupon
            </button>
        </div>

        <div class="card border-0 shadow-sm">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="bg-light">
                            <tr>
                                <th class="ps-3">Kode</th>
                                <th>Tipe</th>
                                <th class="text-end">Nilai</th>
                                <th class="text-end">Min. Belanja</th>
                                <th class="text-center">Terpakai</th>
                                <th class="text-center">Status</th>
                                <th class="text-center pe-3" style="width: 100px;">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($coupons as $coupon)
                                <tr>
                                    <td class="ps-3">
                                        <span class="badge bg-rose-100 text-rose-700 font-monospace">{{ $coupon->code }}</span>
                                    </td>
                                    <td>
                                        <span class="badge {{ $coupon->type === 'percentage' ? 'bg-blue-100 text-blue-700' : 'bg-green-100 text-green-700' }}">
                                            {{ $coupon->type === 'percentage' ? 'Persen' : 'Nominal' }}
                                        </span>
                                    </td>
                                    <td class="text-end fw-medium">
                                        {{ $coupon->type === 'percentage' ? $coupon->value . '%' : 'Rp ' . number_format($coupon->value, 0, ',', '.') }}
                                    </td>
                                    <td class="text-end">
                                        Rp {{ number_format($coupon->min_purchase, 0, ',', '.') }}
                                    </td>
                                    <td class="text-center">
                                        {{ $coupon->used_count }}/{{ $coupon->usage_limit ?? '∞' }}
                                    </td>
                                    <td class="text-center">
                                        @if($coupon->isValid())
                                            <span class="badge bg-success-subtle text-success">Aktif</span>
                                        @else
                                            <span class="badge bg-danger-subtle text-danger">Nonaktif</span>
                                        @endif
                                    </td>
                                    <td class="text-center pe-3">
                                        <div class="btn-group btn-group-sm">
                                            <button type="button" class="btn btn-outline-primary" data-bs-toggle="modal"
                                                data-bs-target="#editCouponModal{{ $coupon->id }}">
                                                <i class="bi bi-pencil"></i>
                                            </button>
                                            <form action="{{ route('admin.coupons.destroy', $coupon) }}" method="POST" class="d-inline delete-form">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" class="btn btn-outline-danger">
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="7" class="text-center py-5">
                                        <div class="mb-3">
                                            <i class="bi bi-ticket-perforated display-4 text-muted"></i>
                                        </div>
                                        <h5 class="text-muted">Belum ada kupon</h5>
                                    </td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="mt-4 d-flex justify-content-center">
            {{ $coupons->links() }}
        </div>

        <!-- Add Coupon Modal -->
        <div class="modal fade" id="addCouponModal" tabindex="-1">
            <div class="modal-dialog">
                <div class="modal-content border-0 shadow">
                    <form action="{{ route('admin.coupons.store') }}" method="POST">
                        @csrf
                        <div class="modal-header border-0 pb-0">
                            <h5 class="modal-title fw-bold">
                                <i class="bi bi-plus-circle text-rose me-2"></i>Tambah Kupon
                            </h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="row g-3">
                                <div class="col-12">
                                    <label class="form-label fw-medium">Kode Kupon <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" name="code" required placeholder="Contoh: DISKON20" style="text-transform: uppercase;">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-medium">Tipe <span class="text-danger">*</span></label>
                                    <select class="form-select" name="type" required>
                                        <option value="percentage">Persen (%)</option>
                                        <option value="fixed">Nominal (Rp)</option>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-medium">Nilai <span class="text-danger">*</span></label>
                                    <input type="number" class="form-control" name="value" required min="0">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-medium">Min. Belanja</label>
                                    <input type="number" class="form-control" name="min_purchase" value="0" min="0">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-medium">Maks. Diskon</label>
                                    <input type="number" class="form-control" name="max_discount" min="0">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-medium">Batas Penggunaan</label>
                                    <input type="number" class="form-control" name="usage_limit" min="1">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-medium">Berlaku Hingga</label>
                                    <input type="datetime-local" class="form-control" name="expires_at">
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer border-0 pt-0">
                            <button type="button" class="btn btn-light" data-bs-dismiss="modal">Batal</button>
                            <button type="submit" class="btn btn-rose">
                                <i class="bi bi-check-lg me-1"></i>Simpan
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Edit Coupon Modals -->
        @foreach($coupons as $coupon)
            <div class="modal fade" id="editCouponModal{{ $coupon->id }}" tabindex="-1">
                <div class="modal-dialog">
                    <div class="modal-content border-0 shadow">
                        <form action="{{ route('admin.coupons.update', $coupon) }}" method="POST">
                            @csrf
                            @method('PUT')
                            <div class="modal-header border-0 pb-0">
                                <h5 class="modal-title fw-bold">
                                    <i class="bi bi-pencil text-primary me-2"></i>Edit Kupon
                                </h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                            <div class="modal-body">
                                <div class="row g-3">
                                    <div class="col-12">
                                        <label class="form-label fw-medium">Kode Kupon <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" name="code" value="{{ $coupon->code }}" required style="text-transform: uppercase;">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label fw-medium">Tipe <span class="text-danger">*</span></label>
                                        <select class="form-select" name="type" required>
                                            <option value="percentage" {{ $coupon->type === 'percentage' ? 'selected' : '' }}>Persen (%)</option>
                                            <option value="fixed" {{ $coupon->type === 'fixed' ? 'selected' : '' }}>Nominal (Rp)</option>
                                        </select>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label fw-medium">Nilai <span class="text-danger">*</span></label>
                                        <input type="number" class="form-control" name="value" value="{{ $coupon->value }}" required min="0">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label fw-medium">Min. Belanja</label>
                                        <input type="number" class="form-control" name="min_purchase" value="{{ $coupon->min_purchase }}" min="0">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label fw-medium">Maks. Diskon</label>
                                        <input type="number" class="form-control" name="max_discount" value="{{ $coupon->max_discount }}" min="0">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label fw-medium">Batas Penggunaan</label>
                                        <input type="number" class="form-control" name="usage_limit" value="{{ $coupon->usage_limit }}" min="1">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label fw-medium">Berlaku Hingga</label>
                                        <input type="datetime-local" class="form-control" name="expires_at" value="{{ $coupon->expires_at ? $coupon->expires_at->format('Y-m-d\TH:i') : '' }}">
                                    </div>
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" class="form-check-input" name="is_active" value="1" {{ $coupon->is_active ? 'checked' : '' }}>
                                            <label class="form-check-label">Aktif</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer border-0 pt-0">
                                <button type="button" class="btn btn-light" data-bs-dismiss="modal">Batal</button>
                                <button type="submit" class="btn btn-rose">
                                    <i class="bi bi-check-lg me-1"></i>Update
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        @endforeach
    </div>
@endsection

@push('styles')
    <style>
        .btn-rose {
            background-color: #f43f5e;
            border-color: #f43f5e;
            color: white;
        }
        .btn-rose:hover {
            background-color: #e11d48;
            border-color: #e11d48;
            color: white;
        }
        .bg-success-subtle {
            background-color: #d1e7dd !important;
        }
        .bg-danger-subtle {
            background-color: #f8d7da !important;
        }
    </style>
@endpush

@push('scripts')
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        @if (session('success'))
            Swal.fire({
                icon: 'success',
                title: 'Berhasil!',
                text: "{{ session('success') }}",
                showConfirmButton: false,
                timer: 2000,
                toast: true,
                position: 'top-end'
            });
        @endif

        document.querySelectorAll('.delete-form').forEach(form => {
            form.addEventListener('submit', function(e) {
                e.preventDefault();
                Swal.fire({
                    title: 'Hapus kupon?',
                    text: "Kupon yang dihapus tidak dapat dikembalikan!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#f43f5e',
                    cancelButtonColor: '#6c757d',
                    confirmButtonText: 'Ya, hapus!',
                    cancelButtonText: 'Batal'
                }).then((result) => {
                    if (result.isConfirmed) {
                        this.submit();
                    }
                });
            });
        });
    </script>
@endpush
