@extends('layouts.layout-admin')

@section('title', 'Pengaturan Web')

@section('header_title', 'Pengaturan Web')
@section('header_subtitle', 'Kelola tampilan dan konten website')

@section('content')
    <div class="max-w-4xl mx-auto space-y-6">

        @if (session('success'))
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                {{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif

        @if (session('error'))
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                {{ session('error') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif

        <form action="{{ route('admin.settings.web.store') }}" method="POST" class="space-y-6">
            @csrf

            {{-- Store Info --}}
            <div class="bg-white rounded-2xl p-6 shadow-sm">
                <div class="flex items-center gap-3 mb-4">
                    <div class="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
                        <svg class="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/>
                        </svg>
                    </div>
                    <div>
                        <h3 class="text-lg font-semibold text-gray-900">Informasi Toko</h3>
                        <p class="text-sm text-gray-500">Atur nama dan info toko Anda</p>
                    </div>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Nama Toko</label>
                        <input type="text" name="store_name" value="{{ $settings['store_name'] }}"
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-rose-200 focus:border-rose-500">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Email</label>
                        <input type="email" name="store_email" value="{{ $settings['store_email'] }}"
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-rose-200 focus:border-rose-500">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Telepon</label>
                        <input type="text" name="store_phone" value="{{ $settings['store_phone'] }}"
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-rose-200 focus:border-rose-500">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Nomor WhatsApp</label>
                        <input type="text" name="whatsapp_number" value="{{ $settings['whatsapp_number'] }}"
                            placeholder="628123456789"
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-rose-200 focus:border-rose-500">
                    </div>
                    <div class="md:col-span-2">
                        <label class="block text-sm font-medium text-gray-700 mb-1">Alamat</label>
                        <input type="text" name="store_address" value="{{ $settings['store_address'] }}"
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-rose-200 focus:border-rose-500">
                    </div>
                    <div class="md:col-span-2">
                        <label class="block text-sm font-medium text-gray-700 mb-1">Deskripsi Toko</label>
                        <textarea name="store_description" rows="2"
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-rose-200 focus:border-rose-500">{{ $settings['store_description'] }}</textarea>
                    </div>
                </div>
            </div>

            {{-- Theme Colors --}}
            <div class="bg-white rounded-2xl p-6 shadow-sm">
                <div class="flex items-center gap-3 mb-4">
                    <div class="w-10 h-10 rounded-lg bg-purple-100 flex items-center justify-center">
                        <svg class="w-5 h-5 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01"/>
                        </svg>
                    </div>
                    <div>
                        <h3 class="text-lg font-semibold text-gray-900">Tema Warna</h3>
                        <p class="text-sm text-gray-500">Atur warna tema website</p>
                    </div>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Warna Primer</label>
                        <div class="flex items-center gap-2">
                            <input type="color" name="theme_primary" value="{{ $settings['theme_primary'] }}"
                                class="w-12 h-10 rounded-lg cursor-pointer border-0">
                            <input type="text" value="{{ $settings['theme_primary'] }}" readonly
                                class="flex-1 px-3 py-2 border border-gray-300 rounded-lg text-sm font-mono">
                        </div>
                        <p class="text-xs text-gray-500 mt-1">Untuk tombol, link, dan aksen utama</p>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Warna Sekunder</label>
                        <div class="flex items-center gap-2">
                            <input type="color" name="theme_secondary" value="{{ $settings['theme_secondary'] }}"
                                class="w-12 h-10 rounded-lg cursor-pointer border-0">
                            <input type="text" value="{{ $settings['theme_secondary'] }}" readonly
                                class="flex-1 px-3 py-2 border border-gray-300 rounded-lg text-sm font-mono">
                        </div>
                        <p class="text-xs text-gray-500 mt-1">Untuk gradasi dan aksen tambahan</p>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Warna Gelap</label>
                        <div class="flex items-center gap-2">
                            <input type="color" name="theme_dark" value="{{ $settings['theme_dark'] }}"
                                class="w-12 h-10 rounded-lg cursor-pointer border-0">
                            <input type="text" value="{{ $settings['theme_dark'] }}" readonly
                                class="flex-1 px-3 py-2 border border-gray-300 rounded-lg text-sm font-mono">
                        </div>
                        <p class="text-xs text-gray-500 mt-1">Untuk teks dan elemen gelap</p>
                    </div>
                </div>

                {{-- Preview --}}
                <div class="mt-4 p-4 bg-gray-50 rounded-xl">
                    <p class="text-sm font-medium text-gray-700 mb-3">Preview:</p>
                    <div class="flex flex-wrap gap-3">
                        <div id="previewBtn" class="px-4 py-2 rounded-lg text-white text-sm font-medium">Tombol Primer</div>
                        <div id="previewSecondary" class="px-4 py-2 rounded-lg text-white text-sm font-medium">Sekunder</div>
                        <div id="previewDark" class="px-4 py-2 rounded-lg text-white text-sm font-medium">Gelap</div>
                    </div>
                </div>
            </div>

            {{-- Social Media --}}
            <div class="bg-white rounded-2xl p-6 shadow-sm">
                <div class="flex items-center gap-3 mb-4">
                    <div class="w-10 h-10 rounded-lg bg-green-100 flex items-center justify-center">
                        <svg class="w-5 h-5 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"/>
                        </svg>
                    </div>
                    <div>
                        <h3 class="text-lg font-semibold text-gray-900">Media Sosial</h3>
                        <p class="text-sm text-gray-500">Atur link media sosial Anda</p>
                    </div>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Instagram</label>
                        <input type="url" name="instagram_url" value="{{ $settings['instagram_url'] }}"
                            placeholder="https://instagram.com/..."
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-rose-200 focus:border-rose-500">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Facebook</label>
                        <input type="url" name="facebook_url" value="{{ $settings['facebook_url'] }}"
                            placeholder="https://facebook.com/..."
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-rose-200 focus:border-rose-500">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">TikTok</label>
                        <input type="url" name="tiktok_url" value="{{ $settings['tiktok_url'] }}"
                            placeholder="https://tiktok.com/..."
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-rose-200 focus:border-rose-500">
                    </div>
                </div>
            </div>

            {{-- Footer --}}
            <div class="bg-white rounded-2xl p-6 shadow-sm">
                <div class="flex items-center gap-3 mb-4">
                    <div class="w-10 h-10 rounded-lg bg-orange-100 flex items-center justify-center">
                        <svg class="w-5 h-5 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/>
                        </svg>
                    </div>
                    <div>
                        <h3 class="text-lg font-semibold text-gray-900">Footer</h3>
                        <p class="text-sm text-gray-500">Atur teks footer website</p>
                    </div>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Teks Footer</label>
                    <input type="text" name="footer_text" value="{{ $settings['footer_text'] }}"
                        class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-rose-200 focus:border-rose-500">
                    <p class="text-xs text-gray-500 mt-1">Teks yang ditampilkan di bagian bawah website</p>
                </div>
            </div>

            {{-- Submit --}}
            <div class="bg-white rounded-2xl p-6 shadow-sm">
                <div class="flex justify-end">
                    <button type="submit"
                        class="px-6 py-2.5 bg-rose-500 hover:bg-rose-600 text-white font-medium rounded-lg transition shadow-sm">
                        Simpan Pengaturan
                    </button>
                </div>
            </div>
        </form>
    </div>
@endsection

@push('scripts')
<script>
    function updatePreview() {
        const primary = document.querySelector('input[name="theme_primary"]').value;
        const secondary = document.querySelector('input[name="theme_secondary"]').value;
        const dark = document.querySelector('input[name="theme_dark"]').value;

        document.getElementById('previewBtn').style.backgroundColor = primary;
        document.getElementById('previewSecondary').style.backgroundColor = secondary;
        document.getElementById('previewDark').style.backgroundColor = dark;
    }

    document.querySelectorAll('input[type="color"]').forEach(input => {
        input.addEventListener('input', updatePreview);
        // Update text input next to color picker
        input.addEventListener('input', function() {
            this.nextElementSibling.value = this.value;
        });
    });

    // Initial preview
    updatePreview();
</script>
@endpush
