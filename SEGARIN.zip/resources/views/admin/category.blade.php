@extends('layouts.layout-admin')

@section('title', 'Kategori')

@section('header_title', 'Kategori')
@section('header_subtitle', 'Kelola kategori produk')

@section('content')
    <div class="container-fluid">
        <!-- Header Section -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h4 class="mb-1 fw-bold">Daftar Kategori</h4>
                <p class="text-muted small mb-0">Total: {{ $categories->total() }} kategori</p>
            </div>
            <button type="button" class="btn btn-rose" data-bs-toggle="modal" data-bs-target="#addCategoryModal">
                <i class="bi bi-plus-lg me-1"></i> Tambah Kategori
            </button>
        </div>

        <!-- Search -->
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-body py-3">
                <form action="{{ route('admin.categories.index') }}" method="GET" class="d-flex gap-2">
                    <div class="input-group">
                        <span class="input-group-text bg-white border-end-0"><i class="bi bi-search text-muted"></i></span>
                        <input type="text" name="search" class="form-control border-start-0 ps-0"
                            placeholder="Cari kategori..." value="{{ request('search') }}">
                    </div>
                    <button type="submit" class="btn btn-rose px-4">Cari</button>
                    @if(request('search'))
                        <a href="{{ route('admin.categories.index') }}" class="btn btn-outline-secondary">
                            <i class="bi bi-x-lg"></i>
                        </a>
                    @endif
                </form>
            </div>
        </div>

        <!-- Categories Grid -->
        <div class="row g-3">
            @forelse($categories as $category)
                <div class="col-12 col-sm-6 col-lg-4 col-xl-3">
                    <div class="card border-0 shadow-sm h-100 hover-card">
                            <div class="card-body">
                            <div class="d-flex align-items-start justify-content-between mb-3">
                                <div class="flex-shrink-0">
                                    <div class="category-icon rounded-3 d-flex align-items-center justify-content-center"
                                        style="width: 48px; height: 48px; background: linear-gradient(135deg, #fce7f3, #fbcfe8);">
                                        <span class="fs-5">{{ $category->icon ?? '🍽️' }}</span>
                                    </div>
                                </div>
                                <div class="dropdown">
                                    <button class="btn btn-link text-muted p-0" data-bs-toggle="dropdown">
                                        <i class="bi bi-three-dots-vertical"></i>
                                    </button>
                                    <ul class="dropdown-menu dropdown-menu-end">
                                        <li>
                                            <button class="dropdown-item" data-bs-toggle="modal"
                                                data-bs-target="#editCategoryModal{{ $category->id }}">
                                                <i class="bi bi-pencil me-2"></i>Edit
                                            </button>
                                        </li>
                                        <li>
                                            <form action="{{ route('admin.categories.destroy', $category) }}" method="POST"
                                                class="delete-form">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" class="dropdown-item text-danger">
                                                    <i class="bi bi-trash me-2"></i>Hapus
                                                </button>
                                            </form>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <h6 class="card-title fw-bold mb-1">{{ $category->name }}</h6>
                            <p class="text-muted small mb-3 text-truncate">{{ $category->description ?? '-' }}</p>
                            <div class="d-flex align-items-center justify-content-between">
                                <span class="badge bg-light text-dark">
                                    <i class="bi bi-box-seam me-1"></i>{{ $category->products_count }} Produk
                                </span>
                                <small class="text-muted">{{ $category->created_at->diffForHumans() }}</small>
                            </div>
                        </div>
                    </div>
                </div>
            @empty
                <div class="col-12">
                    <div class="card border-0 shadow-sm">
                        <div class="card-body text-center py-5">
                            <div class="mb-3">
                                <i class="bi bi-folder2-open display-4 text-muted"></i>
                            </div>
                            <h5 class="text-muted">Belum ada kategori</h5>
                            <p class="text-muted small">Klik tombol "Tambah Kategori" untuk menambahkan kategori baru</p>
                        </div>
                    </div>
                </div>
            @endforelse
        </div>

        <!-- Pagination -->
        <div class="mt-4 d-flex justify-content-center">
            {{ $categories->withQueryString()->links() }}
        </div>

        <!-- Add Category Modal -->
        <div class="modal fade" id="addCategoryModal" tabindex="-1">
            <div class="modal-dialog">
                <div class="modal-content border-0 shadow">
                    <form action="{{ route('admin.categories.store') }}" method="POST" class="category-form">
                        @csrf
                        <div class="modal-header border-0 pb-0">
                            <h5 class="modal-title fw-bold">
                                <i class="bi bi-plus-circle text-rose me-2"></i>Tambah Kategori
                            </h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="mb-3">
                                <label for="name" class="form-label fw-medium">Nama Kategori <span class="text-danger">*</span></label>
                                <input type="text" class="form-control @error('name') is-invalid @enderror"
                                    name="name" required value="{{ old('name') }}" placeholder="Masukkan nama kategori">
                                @error('name')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            <div class="mb-3">
                                <label for="icon" class="form-label fw-medium">Icon Emoji</label>
                                <div class="input-group">
                                    <input type="text" class="form-control @error('icon') is-invalid @enderror"
                                        name="icon" value="{{ old('icon') }}" placeholder="Contoh: 🍦" id="iconInput">
                                    <span class="input-group-text bg-light" id="iconPreview" style="font-size: 1.5rem; min-width: 50px; cursor: pointer;" title="Klik untuk lihat preview">🍽️</span>
                                </div>
                                @error('icon')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                                <div class="form-text">Pilih emoji yang sesuai dengan kategori. Beberapa contoh:
                                    <span class="emoji-picker" data-emoji="🍦">🍦</span>
                                    <span class="emoji-picker" data-emoji="🍧">🍧</span>
                                    <span class="emoji-picker" data-emoji="🍩">🍩</span>
                                    <span class="emoji-picker" data-emoji="🧋">🧋</span>
                                    <span class="emoji-picker" data-emoji="🍽️">🍽️</span>
                                    <span class="emoji-picker" data-emoji="🥤">🥤</span>
                                    <span class="emoji-picker" data-emoji="🍰">🍰</span>
                                    <span class="emoji-picker" data-emoji="☕">☕</span>
                                </div>
                            </div>
                            <div class="mb-0">
                                <label for="description" class="form-label fw-medium">Deskripsi</label>
                                <textarea class="form-control @error('description') is-invalid @enderror"
                                    name="description" rows="3" placeholder="Deskripsi singkat kategori...">{{ old('description') }}</textarea>
                                @error('description')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>
                        <div class="modal-footer border-0 pt-0">
                            <button type="button" class="btn btn-light" data-bs-dismiss="modal">Batal</button>
                            <button type="submit" class="btn btn-rose">
                                <i class="bi bi-check-lg me-1"></i>Simpan
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Edit Category Modals -->
        @foreach ($categories as $category)
            <div class="modal fade" id="editCategoryModal{{ $category->id }}" tabindex="-1">
                <div class="modal-dialog">
                    <div class="modal-content border-0 shadow">
                        <form action="{{ route('admin.categories.update', $category) }}" method="POST" class="category-form">
                            @csrf
                            @method('PUT')
                            <div class="modal-header border-0 pb-0">
                                <h5 class="modal-title fw-bold">
                                    <i class="bi bi-pencil text-primary me-2"></i>Edit Kategori
                                </h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                            <div class="modal-body">
                                <div class="mb-3">
                                    <label for="name" class="form-label fw-medium">Nama Kategori <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control @error('name') is-invalid @enderror"
                                        name="name" required value="{{ old('name', $category->name) }}">
                                    @error('name')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                <div class="mb-3">
                                    <label for="icon" class="form-label fw-medium">Icon Emoji</label>
                                    <div class="input-group">
                                        <input type="text" class="form-control @error('icon') is-invalid @enderror"
                                            name="icon" value="{{ old('icon', $category->icon) }}" placeholder="Contoh: 🍦" id="iconInput{{ $category->id }}">
                                        <span class="input-group-text bg-light" id="iconPreview{{ $category->id }}" style="font-size: 1.5rem; min-width: 50px; cursor: pointer;">{{ $category->icon ?? '🍽️' }}</span>
                                    </div>
                                    @error('icon')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                    <div class="form-text">Pilih emoji yang sesuai dengan kategori.</div>
                                </div>
                                <div class="mb-0">
                                    <label for="description" class="form-label fw-medium">Deskripsi</label>
                                    <textarea class="form-control @error('description') is-invalid @enderror"
                                        name="description" rows="3">{{ old('description', $category->description) }}</textarea>
                                    @error('description')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                            <div class="modal-footer border-0 pt-0">
                                <button type="button" class="btn btn-light" data-bs-dismiss="modal">Batal</button>
                                <button type="submit" class="btn btn-rose">
                                    <i class="bi bi-check-lg me-1"></i>Update
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        @endforeach
    </div>
@endsection

@push('styles')
    <style>
        .btn-rose {
            background-color: #f43f5e;
            border-color: #f43f5e;
            color: white;
        }
        .btn-rose:hover {
            background-color: #e11d48;
            border-color: #e11d48;
            color: white;
        }
        .hover-card {
            transition: all 0.2s ease;
        }
        .hover-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.1) !important;
        }
        .emoji-picker {
            cursor: pointer;
            font-size: 1.25rem;
            padding: 2px 4px;
            border-radius: 4px;
            transition: background-color 0.2s;
        }
        .emoji-picker:hover {
            background-color: #fce7f3;
        }
    </style>
@endpush

@push('scripts')
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        @if ($errors->any())
            var modalId = '{{ old('_modal_id', '#addCategoryModal') }}';
            var modal = new bootstrap.Modal(document.querySelector(modalId));
            modal.show();
        @endif

        @if (session('success'))
            Swal.fire({
                icon: 'success',
                title: 'Berhasil!',
                text: "{{ session('success') }}",
                showConfirmButton: false,
                timer: 2000,
                toast: true,
                position: 'top-end'
            });
        @endif

        @if (session('error'))
            Swal.fire({
                icon: 'error',
                title: 'Gagal!',
                text: "{{ session('error') }}",
                showConfirmButton: true
            });
        @endif

        document.querySelectorAll('.category-form').forEach(form => {
            form.addEventListener('submit', function(event) {
                event.preventDefault();
                Swal.fire({
                    title: 'Menyimpan...',
                    allowOutsideClick: false,
                    showConfirmButton: false,
                    willOpen: () => Swal.showLoading()
                });
                this.submit();
            });
        });

        document.querySelectorAll('.delete-form').forEach(form => {
            form.addEventListener('submit', function(e) {
                e.preventDefault();
                Swal.fire({
                    title: 'Hapus kategori?',
                    text: "Kategori yang dihapus tidak dapat dikembalikan!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#f43f5e',
                    cancelButtonColor: '#6c757d',
                    confirmButtonText: 'Ya, hapus!',
                    cancelButtonText: 'Batal'
                }).then((result) => {
                    if (result.isConfirmed) {
                        Swal.fire({ title: 'Menghapus...', allowOutsideClick: false, showConfirmButton: false, willOpen: () => Swal.showLoading() });
                        this.submit();
                    }
                });
            });
        });

        // Emoji picker functionality
        document.querySelectorAll('.emoji-picker').forEach(picker => {
            picker.addEventListener('click', function() {
                const emoji = this.dataset.emoji;
                const input = document.getElementById('iconInput');
                const preview = document.getElementById('iconPreview');
                if (input) input.value = emoji;
                if (preview) preview.textContent = emoji;
            });
        });

        // Update preview when input changes
        document.querySelectorAll('[id^="iconInput"]').forEach(input => {
            input.addEventListener('input', function() {
                const id = this.id.replace('iconInput', '');
                const preview = document.getElementById('iconPreview' + id) || document.getElementById('iconPreview');
                if (preview) preview.textContent = this.value || '🍽️';
            });
        });

        // Click preview to pick emoji
        document.querySelectorAll('[id^="iconPreview"]').forEach(preview => {
            preview.addEventListener('click', function() {
                const inputId = this.id.replace('iconPreview', 'iconInput');
                const input = document.getElementById(inputId) || document.getElementById('iconInput');
                if (input) input.focus();
            });
        });
    </script>
@endpush
