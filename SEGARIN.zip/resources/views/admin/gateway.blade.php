@extends('layouts.layout-admin')

@section('title', 'Gateway WhatsApp')

@section('header_title', 'Pengaturan Gateway WhatsApp')
@section('header_subtitle', 'Konfigurasi Fonnte untuk notifikasi pesanan otomatis')

@section('content')
    <div class="max-w-3xl mx-auto bg-white rounded-2xl p-6 shadow-sm">
        @if (session('success'))
            <div class="alert alert-success alert-dismissible fade show mb-6" role="alert">
                {{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif

        <form action="{{ route('admin.settings.gateway.store') }}" method="POST" class="space-y-6">
            @csrf

            <!-- Fonnte API Token -->
            <div>
                <label for="whatsapp_fonnte_token" class="block text-sm font-medium text-gray-700 mb-1">
                    Token API Fonnte
                </label>
                <input type="text" name="whatsapp_fonnte_token" id="whatsapp_fonnte_token" 
                    value="{{ old('whatsapp_fonnte_token', $fonnteToken) }}"
                    placeholder="Masukkan Token Fonnte Anda..."
                    class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-rose-200 focus:border-rose-500 transition">
                <p class="mt-1 text-xs text-gray-500">
                    Dapatkan token API Anda dari dashboard <a href="https://fonnte.com" target="_blank" class="text-rose-500 hover:underline">Fonnte</a>.
                </p>
            </div>

            <!-- Admin WhatsApp Number -->
            <div>
                <label for="whatsapp_admin_number" class="block text-sm font-medium text-gray-700 mb-1">
                    Nomor WhatsApp Admin
                </label>
                <input type="text" name="whatsapp_admin_number" id="whatsapp_admin_number" 
                    value="{{ old('whatsapp_admin_number', $adminPhone) }}"
                    placeholder="Contoh: 08123456789 atau 628123456789"
                    class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-rose-200 focus:border-rose-500 transition">
                <p class="mt-1 text-xs text-gray-500">
                    Nomor WhatsApp admin yang akan menerima notifikasi setiap ada checkout pesanan baru.
                </p>
            </div>

            <!-- Notification Settings -->
            <div class="border-t border-gray-100 pt-6">
                <h3 class="text-base font-semibold text-gray-900 mb-4">Pengaturan Notifikasi Otomatis</h3>
                
                <div class="space-y-4">
                    <!-- Notify Admin on Checkout -->
                    <div class="flex items-start">
                        <div class="flex items-center h-5">
                            <input type="checkbox" name="whatsapp_notify_checkout" id="whatsapp_notify_checkout" 
                                value="1" {{ $notifyCheckout == '1' ? 'checked' : '' }}
                                class="h-4 w-4 text-rose-500 focus:ring-rose-500 border-gray-300 rounded">
                        </div>
                        <div class="ml-3 text-sm">
                            <label for="whatsapp_notify_checkout" class="font-medium text-gray-700">Notifikasi Checkout Baru ke Admin</label>
                            <p class="text-gray-500">Kirim WhatsApp otomatis ke Admin saat pembeli menyelesaikan proses checkout.</p>
                        </div>
                    </div>

                    <!-- Notify Customer on Status Change -->
                    <div class="flex items-start">
                        <div class="flex items-center h-5">
                            <input type="checkbox" name="whatsapp_notify_status_update" id="whatsapp_notify_status_update" 
                                value="1" {{ $notifyStatus == '1' ? 'checked' : '' }}
                                class="h-4 w-4 text-rose-500 focus:ring-rose-500 border-gray-300 rounded">
                        </div>
                        <div class="ml-3 text-sm">
                            <label for="whatsapp_notify_status_update" class="font-medium text-gray-700">Notifikasi Perubahan Status ke Customer</label>
                            <p class="text-gray-500">Kirim WhatsApp otomatis ke nomor HP customer ketika admin memproses, mengirim, atau menyelesaikan pesanan.</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Submit Button -->
            <div class="border-t border-gray-100 pt-6 flex justify-end">
                <button type="submit" 
                    class="px-6 py-2.5 bg-rose-500 hover:bg-rose-600 text-white font-medium rounded-lg transition shadow-sm">
                    Simpan Pengaturan
                </button>
            </div>
        </form>
    </div>
@endsection
