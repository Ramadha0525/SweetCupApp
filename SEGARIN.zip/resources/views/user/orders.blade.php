@extends('layouts.layouts-landing')

@section('title', 'Riwayat Pesanan')

@section('content')
    <div class="py-8">
        <div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between mb-6">
                <h1 class="text-2xl font-bold text-gray-900">Riwayat Pesanan</h1>
                <a href="/" class="text-rose-600 hover:text-rose-700 flex items-center gap-2 font-medium text-sm">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/>
                    </svg>
                    Lanjut Belanja
                </a>
            </div>

            <!-- Status Filter -->
            <div class="flex gap-2 overflow-x-auto pb-2 mb-6 scrollbar-hide">
                <a href="{{ route('user.orders') }}"
                    class="flex-shrink-0 px-4 py-2 rounded-full text-sm font-medium transition {{ !request('status') ? 'bg-rose-500 text-white' : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50' }}">
                    Semua
                </a>
                @foreach(['pending' => 'Menunggu', 'paid' => 'Lunas', 'processing' => 'Diproses', 'shipped' => 'Dikirim', 'delivered' => 'Selesai'] as $key => $label)
                    <a href="{{ route('user.orders', ['status' => $key]) }}"
                        class="flex-shrink-0 px-4 py-2 rounded-full text-sm font-medium transition {{ request('status') == $key ? 'bg-rose-500 text-white' : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50' }}">
                        {{ $label }}
                    </a>
                @endforeach
            </div>

            <!-- Orders List -->
            <div class="space-y-4">
                @forelse($orders as $order)
                    <div class="bg-white rounded-xl shadow-sm overflow-hidden hover:shadow-md transition">
                        <div class="p-4 sm:p-5">
                            <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
                                <div>
                                    <p class="text-sm text-gray-500">Kode Pesanan</p>
                                    <p class="font-semibold text-gray-900">{{ $order->order_code }}</p>
                                </div>
                                @php
                                    $statusLabel = [
                                        'pending' => 'Menunggu Pembayaran',
                                        'paid' => 'Lunas',
                                        'processing' => 'Diproses',
                                        'shipped' => 'Dikirim',
                                        'delivered' => 'Diterima',
                                        'cancelled' => 'Dibatalkan',
                                    ][$order->status] ?? ucfirst($order->status);
                                    $statusColor = [
                                        'pending' => 'bg-yellow-100 text-yellow-800',
                                        'paid' => 'bg-blue-100 text-blue-800',
                                        'processing' => 'bg-purple-100 text-purple-800',
                                        'shipped' => 'bg-indigo-100 text-indigo-800',
                                        'delivered' => 'bg-green-100 text-green-800',
                                        'cancelled' => 'bg-red-100 text-red-800',
                                    ][$order->status] ?? 'bg-gray-100 text-gray-800';
                                @endphp
                                <span class="inline-flex px-3 py-1 rounded-full text-xs font-medium {{ $statusColor }}">
                                    {{ $statusLabel }}
                                </span>
                            </div>

                            <div class="flex items-center gap-3 overflow-x-auto pb-2">
                                @foreach($order->items->take(3) as $item)
                                    <div class="flex-shrink-0 w-12 h-12 rounded-lg overflow-hidden bg-gray-100">
                                        <img src="{{ $item->product->getPrimaryImage() }}" alt="{{ $item->product->name }}"
                                            class="w-full h-full object-cover">
                                    </div>
                                @endforeach
                                @if($order->items->count() > 3)
                                    <span class="text-sm text-gray-500">+{{ $order->items->count() - 3 }} lagi</span>
                                @endif
                            </div>

                            <div class="flex items-center justify-between mt-4 pt-3 border-t border-gray-100">
                                <div>
                                    <p class="text-xs text-gray-500">{{ $order->created_at->format('d M Y, H:i') }}</p>
                                    @if($order->unique_amount)
                                        <p class="text-sm font-medium text-gray-900">Rp {{ number_format($order->unique_amount, 0, ',', '.') }}</p>
                                    @else
                                        <p class="text-sm font-medium text-gray-900">Rp {{ number_format($order->total_amount, 0, ',', '.') }}</p>
                                    @endif
                                </div>
                                <a href="{{ route('user.orders.show', $order) }}"
                                    class="text-rose-600 hover:text-rose-700 text-sm font-medium">
                                    Lihat Detail →
                                </a>
                            </div>
                        </div>
                    </div>
                @empty
                    <div class="bg-white rounded-xl shadow-sm p-8 text-center">
                        <svg class="w-16 h-16 mx-auto text-gray-300 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/>
                        </svg>
                        <h3 class="text-lg font-medium text-gray-900 mb-1">Belum ada pesanan</h3>
                        <p class="text-gray-500 mb-4">Mulai belanja untuk membuat pesanan pertama Anda</p>
                        <a href="/" class="inline-flex px-6 py-2 bg-rose-500 text-white rounded-lg hover:bg-rose-600 transition">
                            Mulai Belanja
                        </a>
                    </div>
                @endforelse
            </div>

            <!-- Pagination -->
            <div class="mt-6">
                {{ $orders->links() }}
            </div>
        </div>
    </div>
@endsection
