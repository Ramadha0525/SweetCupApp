@extends('layouts.layouts-landing')

@section('title', 'Detail Pesanan ' . $order->order_code)

@section('content')
    <div class="py-8">
        <div class="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
            <a href="{{ route('user.orders') }}" class="text-rose-600 hover:text-rose-700 flex items-center gap-2 font-medium text-sm mb-6">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/>
                </svg>
                Kembali ke Riwayat
            </a>

            <div class="bg-white rounded-xl shadow-sm overflow-hidden">
                <!-- Header -->
                <div class="p-5 border-b border-gray-100">
                    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                        <div>
                            <h1 class="text-xl font-bold text-gray-900">Pesanan {{ $order->order_code }}</h1>
                            <p class="text-sm text-gray-500 mt-1">{{ $order->created_at->format('d M Y, H:i') }}</p>
                        </div>
                        @php
                            $statusLabel = [
                                'pending' => 'Menunggu Pembayaran',
                                'paid' => 'Lunas',
                                'processing' => 'Diproses',
                                'shipped' => 'Dikirim',
                                'delivered' => 'Diterima',
                                'cancelled' => 'Dibatalkan',
                            ][$order->status] ?? ucfirst($order->status);
                            $statusColor = [
                                'pending' => 'bg-yellow-100 text-yellow-800',
                                'paid' => 'bg-blue-100 text-blue-800',
                                'processing' => 'bg-purple-100 text-purple-800',
                                'shipped' => 'bg-indigo-100 text-indigo-800',
                                'delivered' => 'bg-green-100 text-green-800',
                                'cancelled' => 'bg-red-100 text-red-800',
                            ][$order->status] ?? 'bg-gray-100 text-gray-800';
                        @endphp
                        <span class="inline-flex px-4 py-2 rounded-full text-sm font-medium {{ $statusColor }}">
                            {{ $statusLabel }}
                        </span>
                    </div>
                </div>

                <!-- Items -->
                <div class="p-5">
                    <h3 class="font-semibold text-gray-900 mb-4">Item Pesanan</h3>
                    <div class="space-y-3">
                        @foreach($order->items as $item)
                            <div class="flex items-center gap-4 p-3 bg-gray-50 rounded-lg">
                                <div class="w-14 h-14 rounded-lg overflow-hidden bg-white flex-shrink-0">
                                    <img src="{{ $item->product->getPrimaryImage() }}" alt="{{ $item->product->name }}"
                                        class="w-full h-full object-cover">
                                </div>
                                <div class="flex-1 min-w-0">
                                    <p class="font-medium text-gray-900 truncate">{{ $item->product->name }}</p>
                                    <p class="text-sm text-gray-500">{{ $item->quantity }} x Rp {{ number_format($item->price, 0, ',', '.') }}</p>
                                </div>
                                <p class="font-medium text-gray-900">Rp {{ number_format($item->price * $item->quantity, 0, ',', '.') }}</p>
                            </div>
                        @endforeach
                    </div>

                    <!-- Summary -->
                    <div class="mt-6 pt-4 border-t border-gray-100 space-y-2">
                        <div class="flex justify-between text-sm">
                            <span class="text-gray-500">Subtotal</span>
                            <span class="text-gray-900">Rp {{ number_format($order->total_amount - 20000, 0, ',', '.') }}</span>
                        </div>
                        <div class="flex justify-between text-sm">
                            <span class="text-gray-500">Ongkir</span>
                            <span class="text-gray-900">Rp 20.000</span>
                        </div>
                        @if($order->unique_code)
                            <div class="flex justify-between text-sm">
                                <span class="text-gray-500">Kode Unik</span>
                                <span class="text-gray-900">+{{ $order->unique_code }}</span>
                            </div>
                        @endif
                        <div class="flex justify-between font-semibold text-lg pt-2 border-t border-gray-100">
                            <span class="text-gray-900">Total</span>
                            <span class="text-rose-600">Rp {{ number_format($order->unique_amount ?? $order->total_amount, 0, ',', '.') }}</span>
                        </div>
                    </div>

                    <!-- Payment Info -->
                    @if($order->payment_method)
                        <div class="mt-6 p-4 bg-blue-50 rounded-lg">
                            <h4 class="font-medium text-blue-900 mb-2">Metode Pembayaran</h4>
                            <p class="text-sm text-blue-800">{{ $order->payment_method_label }}</p>
                            @if($order->manual_payment_status)
                                @php
                                    $manualStatus = [
                                        'pending_confirmation' => 'Menunggu Konfirmasi',
                                        'confirmed' => 'Dikonfirmasi',
                                        'rejected' => 'Ditolak',
                                    ][$order->manual_payment_status] ?? $order->manual_payment_status;
                                @endphp
                                <p class="text-sm text-blue-800 mt-1">Status: <strong>{{ $manualStatus }}</strong></p>
                            @endif
                        </div>
                    @endif

                    <!-- Shipping Address -->
                    <div class="mt-6 p-4 bg-gray-50 rounded-lg">
                        <h4 class="font-medium text-gray-900 mb-2">Alamat Pengiriman</h4>
                        <p class="text-sm text-gray-600">{{ $order->shipping_address }}</p>
                    </div>

                    @if($order->resi_code)
                        <div class="mt-4 p-4 bg-green-50 rounded-lg">
                            <h4 class="font-medium text-green-900 mb-2">Nomor Resi</h4>
                            <p class="text-sm text-green-800 font-mono">{{ $order->resi_code }}</p>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
@endsection
