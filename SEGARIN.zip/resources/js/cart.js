class ShoppingCart {
    constructor() {
        this.items = this.getCartFromStorage();
        this.SHIPPING_COST = 20000;
        this.loadShippingCost();
        this.init();
    }

    async loadShippingCost() {
        try {
            const response = await fetch('/api/payment-settings');
            const settings = await response.json();
            if (settings.shipping_cost) {
                this.SHIPPING_COST = parseInt(settings.shipping_cost);
                if (window.location.pathname.includes('cart')) {
                    this.updateCartUI();
                }
            }
        } catch (error) {
            console.error('Error loading shipping cost:', error);
        }
    }
    init() {
        if (window.location.pathname.includes('cart')) {
            this.updateCartUI();
        }
        this.updateCartCount();
        this.attachEventListeners();
        this.handlePayButtonClick();
    }
    getCartFromStorage() {
        try {
            return JSON.parse(localStorage.getItem('shopping_cart')) || [];
        } catch (error) {
            console.error('Error getting cart from local storage', error);
            return [];
        }
    }
    saveCartToStoreStorage() {
        try {
            localStorage.setItem('shopping_cart', JSON.stringify(this.items));
            this.updateCartCount();
        } catch (error) {
            console.error('Error saving cart to local storage', error);
            this.showNotification('Gagal menyimpan keranjang belanja');
        }
    }

    updateCartCount() {
        const cartCount = document.getElementById('cart-count');
        if (!cartCount) return;

        const totalItems = this.items.reduce((sum, item) => sum + item.quantity, 0);
        cartCount.textContent = totalItems;
        cartCount.style.display = totalItems > 0 ? 'flex' : 'none';
    }

    addItem(product) {
        if (!product?.id) return;
        try {
            const existingItem = this.items.find(item => item.id === parseInt(product.id));
            if (existingItem) {
                existingItem.quantity += 1;
            } else {
                this.items.push({
                    id: parseInt(product.id),
                    name: product.name,
                    price: parseFloat(product.price),
                    image: product.image,
                    category: product.category_name,
                    quantity: 1
                });
            }
            this.saveCartToStoreStorage();
            this.updateCartCount();
            this.updateCartUI();
            this.showNotification(`${product.name} dimasukkan ke keranjang`);
        } catch (error) {
            console.error(error);
            this.showNotification('Gagal memasukkan produk ke keranjang', 'error');
        }
    }

    removeItem(productId) {
        try {
            this.items = this.items.filter(item => item.id !== parseInt(productId));
            this.saveCartToStoreStorage();
            this.updateCartCount();
            this.updateCartUI();
            this.showNotification('Produk dihapus dari keranjang');
        } catch (error) {
            console.error(error);
            this.showNotification('Gagal menghapus produk', 'error');
        }
    }

    updateQuantity(productId, changeAmount) {
        try {
            const item = this.items.find(item => item.id === parseInt(productId));
            if (!item) return;

            const newQuantity = item.quantity + changeAmount;
            if (newQuantity < 1) {
                this.removeItem(productId);
                return;
            }
            item.quantity = newQuantity;
            this.saveCartToStoreStorage();
            this.updateCartCount();
            this.updateCartUI();
        } catch (error) {
            console.error(error);
            this.showNotification('Gagal memperbarui jumlah produk', 'error');
        }
    }

    formatPrice(price) {
        return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0, maximumFractionDigits: 0 }).format(price);
    }

    async applyCoupon(code) {
        try {
            const response = await fetch('/coupons/apply', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                },
                body: JSON.stringify({ code: code })
            });

            const data = await response.json();

            if (data.status === 'success') {
                const coupon = data.coupon;
                const subtotal = this.calculateSubTotal();
                let discount = 0;

                if (coupon.type === 'percentage') {
                    discount = subtotal * (coupon.value / 100);
                } else {
                    discount = coupon.value;
                }

                this.couponDiscount = discount;
                this.couponCode = coupon.code;

                const discountRow = document.getElementById('discountRow');
                const couponInfo = document.getElementById('couponInfo');
                const couponCodeDisplay = document.getElementById('couponCodeDisplay');
                const couponDiscount = document.getElementById('couponDiscount');

                if (discountRow) discountRow.classList.remove('hidden');
                if (couponInfo) couponInfo.classList.remove('hidden');
                if (couponCodeDisplay) couponCodeDisplay.textContent = coupon.code;
                if (couponDiscount) couponDiscount.textContent = this.formatPrice(discount);

                const discountElement = document.querySelector('[data-summary="discount"]');
                if (discountElement) discountElement.textContent = '- ' + this.formatPrice(discount);

                this.updateOrderSummary(subtotal, this.SHIPPING_COST);
                this.showNotification('Kupon berhasil diterapkan!');

                return true;
            } else {
                this.showNotification(data.message || 'Kupon tidak valid', 'error');
                return false;
            }
        } catch (error) {
            this.showNotification('Gagal menerapkan kupon', 'error');
            return false;
        }
    }
    calculateSubTotal() {
        return this.items.reduce((total, item) => total + (parseFloat(item.price) * item.quantity), 0);
    }

    showNotification(message, type = 'success') {
        const notification = document.createElement('div');
        notification.classList.add(
            'fixed',
            'bottom-4',
            'right-4',
            'px-6',
            'py-3',
            'rounded-lg',
            'shadow-lg',
            'transform',
            'transition-transform',
            'duration-300',
            'translate-y-0',
            'z-50',
            type === 'success' ? 'bg-rose-500' : 'bg-red-500',
            'text-white'
        );
        notification.textContent = message;

        document.body.appendChild(notification);

        setTimeout(() => {
            notification.classList.add('translate-y-full');
            setTimeout(() => notification.remove(), 300);
        }, 3000);
    }
    updateOrderSummary(subtotal = 0, shipping = this.SHIPPING_COST) {
        this.subtotal = subtotal;
        this.shipping = shipping;

        const elements = {
            subtotal: document.querySelector('[data-summary="subtotal"]'),
            shipping: document.querySelector('[data-summary="shipping"]'),
            total: document.querySelector('[data-summary="total"]'),
            checkout: document.querySelector('[data-summary="checkout"]'),
        };

        if (elements.subtotal) elements.subtotal.textContent = this.formatPrice(subtotal);
        if (elements.shipping) elements.shipping.textContent = this.formatPrice(shipping);

        let discount = this.couponDiscount || 0;
        let total = subtotal + shipping - discount;

        if (elements.total) elements.total.textContent = this.formatPrice(total);

        if (elements.checkout) {
            const isDisabled = this.items.length === 0;
            elements.checkout.disabled = isDisabled;
            elements.checkout.className = isDisabled
                ? 'mt-6 w-full bg-gray-300 cursor-not-allowed text-white py-3 px-4 rounded-lg'
                : 'mt-6 w-full bg-rose-500 text-white py-3 px-4 rounded-lg hover:bg-rose-600 transition-colors duration-200';

            elements.checkout.addEventListener('click', () => this.showShippingForm(elements.checkout));
        }
    }

    createCartItemElement(item) {
        const div = document.createElement('div');
        div.className = 'p-6 border-b border-gray-200';
        div.innerHTML = `
        <div class="flex items-center">
            <img src="${item.image}" alt="${item.name}" class="w-20 h-20 object-cover rounded-lg">
            <div class="ml-4 flex-1">
                <h3 class="text-lg font-medium text-gray-900">${item.name}</h3>
                <p class="mt-1 text-sm text-gray-500">${item.category}</p>
                <div class="mt-2 flex items-center justify-between">
                    <div class="flex items-center space-x-2">
                        <button type="button" class="quantity-btn p-1 rounded-md hover:bg-gray-100" data-action="decrease" data-product-id="${item.id}">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 12H4" />
                            </svg>
                        </button>
                        <span class="quantity-value text-gray-700 font-medium" id="quantity-${item.id}">${item.quantity}</span>
                        <button type="button" class="quantity-btn p-1 rounded-md hover:bg-gray-100" data-action="increase" data-product-id="${item.id}">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4" />
                            </svg>
                        </button>
                    </div>

                    <span class="font-medium text-gray-900">
                        ${this.formatPrice(item.price * item.quantity)}
                    </span>
                </div>
            </div>
            <button class="ml-4 text-gray-400 hover:text-red-500" data-action="remove" data-product-id="${item.id}">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                </svg>
            </button>
        </div>`;
        this.attachItemEventListeners(div, item.id);
        return div;
    }

    showShippingForm(checkoutButton) {
        const cartItemsContainer = document.querySelector('.cart-items');
        if (!cartItemsContainer) {
            console.error('Cart items container not found!');
            return;
        }

        const quantityButtons = cartItemsContainer.querySelectorAll('.quantity-btn');
        const removeButtons = cartItemsContainer.querySelectorAll('[data-action="remove"]');
        quantityButtons.forEach(button => button.disabled = true);
        removeButtons.forEach(button => button.disabled = true);

        const formContainerId = 'shipping-form-container';
        let formContainer = document.getElementById(formContainerId);

        if (!formContainer) {
            formContainer = document.createElement('div');
            formContainer.id = formContainerId;
            formContainer.className = 'mt-6 bg-gray-50 p-6 rounded-lg shadow-md';
            formContainer.innerHTML = `
                <h2 class="text-lg font-medium text-gray-900 mb-4">Informasi Pengiriman</h2>
                <form id="checkoutForm" class="space-y-4">
                    <div>
                        <label for="name" class="block text-sm font-medium text-gray-700">Nama Lengkap</label>
                        <input type="text" id="name" name="name" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-rose-500 focus:border-rose-500">
                    </div>
                    <div>
                        <label for="phone" class="block text-sm font-medium text-gray-700">Nomor Telepon</label>
                        <input type="text" id="phone" name="phone" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-rose-500 focus:border-rose-500">
                    </div>
                    <div>
                        <label for="shipping_address" class="block text-sm font-medium text-gray-700">Alamat Pengiriman</label>
                        <textarea id="shipping_address" name="shipping_address" rows="3" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-rose-500 focus:border-rose-500"></textarea>
                    </div>
                    <div>
                        <label for="notes" class="block text-sm font-medium text-gray-700">Catatan (Opsional)</label>
                        <textarea id="notes" name="notes" rows="2" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-rose-500 focus:border-rose-500"></textarea>
                    </div>

                    <div class="border-t pt-4 mt-4">
                        <h3 class="text-lg font-medium text-gray-900 mb-4">Metode Pembayaran</h3>
                        <div id="payment-methods-container" class="space-y-3">
                            <div class="text-center text-gray-500">
                                <span class="spinner-border spinner-border-sm me-2"></span>
                                Memuat metode pembayaran...
                            </div>
                        </div>
                    </div>

                    <div id="manual-payment-details" class="hidden border-t pt-4 mt-4">
                        <div id="payment-instructions" class="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
                        </div>
                        <div id="qris-image-container" class="hidden text-center mb-4">
                            <img id="qris-image" src="" alt="QRIS Code" class="mx-auto" style="max-width: 250px;">
                        </div>
                        <div id="ewallet-info" class="hidden bg-gray-100 rounded-lg p-4 mb-4">
                        </div>
                    </div>
                </form>
            `;
            cartItemsContainer.appendChild(formContainer);

            // Auto-fill form from saved user profile
            fetch('/user/profile', {
                headers: { 'Accept': 'application/json' }
            })
            .then(res => res.json())
            .then(data => {
                if (data.status === 'success' && data.data) {
                    const { name, phone, address } = data.data;
                    const nameInput = formContainer.querySelector('#name');
                    const phoneInput = formContainer.querySelector('#phone');
                    const addrInput = formContainer.querySelector('#shipping_address');
                    if (nameInput && name) nameInput.value = name;
                    if (phoneInput && phone) phoneInput.value = phone;
                    if (addrInput && address) addrInput.value = address;
                }
            })
            .catch(() => {/* silently ignore if not logged in */});

            // Load payment methods
            this.loadPaymentMethods();
        }

        const payButton = document.getElementById('payButton');
        if (payButton) {
            payButton.hidden = false;
        }
        checkoutButton.hidden = true;
    }

    async loadPaymentMethods() {
        try {
            const response = await fetch('/api/payment-settings');
            const settings = await response.json();

            const container = document.getElementById('payment-methods-container');
            if (!container) return;

            let html = '';

            // Always show Midtrans
            html += `
                <label class="flex items-center p-3 border rounded-lg cursor-pointer hover:bg-gray-50 transition payment-method-option">
                    <input type="radio" name="payment_method" value="midtrans" class="mr-3 accent-rose-500" checked>
                    <div class="flex items-center gap-3">
                        <div class="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
                            <svg class="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z"/>
                            </svg>
                        </div>
                        <div>
                            <div class="font-medium text-gray-900">Midtrans</div>
                            <div class="text-xs text-gray-500">Kartu Kredit, Bank Transfer, GoPay, OVO, dll</div>
                        </div>
                    </div>
                </label>
            `;

            if (settings.manual_payment_enabled === '1') {
                if (settings.cod_enabled === '1') {
                    html += `
                        <label class="flex items-center p-3 border rounded-lg cursor-pointer hover:bg-gray-50 transition payment-method-option">
                            <input type="radio" name="payment_method" value="cod" class="mr-3 accent-rose-500">
                            <div class="flex items-center gap-3">
                                <div class="w-10 h-10 rounded-lg bg-green-100 flex items-center justify-center">
                                    <svg class="w-5 h-5 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z"/>
                                    </svg>
                                </div>
                                <div>
                                    <div class="font-medium text-gray-900">Bayar di Tempat (COD)</div>
                                    <div class="text-xs text-gray-500">Bayar tunai saat pesanan tiba</div>
                                </div>
                            </div>
                        </label>
                    `;
                }

                if (settings.ewallet_enabled === '1') {
                    html += `
                        <label class="flex items-center p-3 border rounded-lg cursor-pointer hover:bg-gray-50 transition payment-method-option">
                            <input type="radio" name="payment_method" value="ewallet" class="mr-3 accent-rose-500">
                            <div class="flex items-center gap-3">
                                <div class="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
                                    <svg class="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z"/>
                                    </svg>
                                </div>
                                <div>
                                    <div class="font-medium text-gray-900">E-Wallet</div>
                                    <div class="text-xs text-gray-500">Transfer ke ${settings.ewallet_name || 'E-Wallet'}</div>
                                </div>
                            </div>
                        </label>
                    `;
                }

                if (settings.qris_enabled === '1') {
                    html += `
                        <label class="flex items-center p-3 border rounded-lg cursor-pointer hover:bg-gray-50 transition payment-method-option">
                            <input type="radio" name="payment_method" value="qris" class="mr-3 accent-rose-500">
                            <div class="flex items-center gap-3">
                                <div class="w-10 h-10 rounded-lg bg-purple-100 flex items-center justify-center">
                                    <svg class="w-5 h-5 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v1m6 11h2m-6 0h-2v4m0-11v3m0 0h.01M12 12h4.01M16 20h4M4 12h4m12 0h.01M5 8h2a1 1 0 001-1V5a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1zm12 0h2a1 1 0 001-1V5a1 1 0 00-1-1h-2a1 1 0 00-1 1v2a1 1 0 001 1zM5 20h2a1 1 0 001-1v-2a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1z"/>
                                    </svg>
                                </div>
                                <div>
                                    <div class="font-medium text-gray-900">QRIS</div>
                                    <div class="text-xs text-gray-500">Scan QR Code untuk bayar</div>
                                </div>
                            </div>
                        </label>
                    `;
                }
            }

            container.innerHTML = html;

            // Store settings for later use
            this.paymentSettings = settings;

            // Add event listeners
            container.querySelectorAll('input[name="payment_method"]').forEach(radio => {
                radio.addEventListener('change', (e) => this.handlePaymentMethodChange(e.target.value));
            });

            // Trigger initial state
            this.handlePaymentMethodChange('midtrans');

        } catch (error) {
            console.error('Error loading payment settings:', error);
            const container = document.getElementById('payment-methods-container');
            if (container) {
                container.innerHTML = `
                    <label class="flex items-center p-3 border rounded-lg cursor-pointer hover:bg-gray-50 transition payment-method-option">
                        <input type="radio" name="payment_method" value="midtrans" class="mr-3 accent-rose-500" checked>
                        <div class="flex items-center gap-3">
                            <div class="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
                                <svg class="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z"/>
                                </svg>
                            </div>
                            <div>
                                <div class="font-medium text-gray-900">Midtrans</div>
                                <div class="text-xs text-gray-500">Kartu Kredit, Bank Transfer, GoPay, OVO, dll</div>
                            </div>
                        </div>
                    </label>
                `;
            }
        }
    }

    handlePaymentMethodChange(method) {
        const detailsContainer = document.getElementById('manual-payment-details');
        const instructionsContainer = document.getElementById('payment-instructions');
        const qrisContainer = document.getElementById('qris-image-container');
        const qrisImage = document.getElementById('qris-image');
        const ewalletInfo = document.getElementById('ewallet-info');

        if (!detailsContainer) return;

        if (method === 'midtrans') {
            detailsContainer.classList.add('hidden');
            return;
        }

        detailsContainer.classList.remove('hidden');
        const settings = this.paymentSettings;

        if (method === 'cod') {
            instructionsContainer.innerHTML = `
                <div class="flex items-start gap-3">
                    <svg class="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                    </svg>
                    <div>
                        <h4 class="font-medium text-gray-900">Bayar di Tempat (COD)</h4>
                        <p class="text-sm text-gray-600 mt-1">${settings.cod_instructions || 'Bayar langsung kepada kurir saat pesanan tiba di alamat Anda.'}</p>
                        <p class="text-sm text-gray-600 mt-2">Anda akan membayar dengan kode unik saat pesanan tiba.</p>
                    </div>
                </div>
            `;
            qrisContainer.classList.add('hidden');
            ewalletInfo.classList.add('hidden');
        } else if (method === 'ewallet') {
            instructionsContainer.innerHTML = `
                <div class="flex items-start gap-3">
                    <svg class="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
                    </svg>
                    <div>
                        <h4 class="font-medium text-gray-900">Transfer E-Wallet</h4>
                        <p class="text-sm text-gray-600 mt-1">${settings.ewallet_instructions || 'Transfer ke nomor E-Wallet di bawah, lalu kirim bukti transfer.'}</p>
                    </div>
                </div>
            `;
            ewalletInfo.classList.remove('hidden');
            ewalletInfo.innerHTML = `
                <div class="text-center">
                    <p class="text-sm text-gray-500 mb-1">${settings.ewallet_name || 'E-Wallet'}</p>
                    <p class="text-lg font-bold text-gray-900">${settings.ewallet_number || '-'}</p>
                    <p class="text-sm text-gray-500">a.n. ${settings.ewallet_owner || '-'}</p>
                </div>
            `;
            qrisContainer.classList.add('hidden');
        } else if (method === 'qris') {
            instructionsContainer.innerHTML = `
                <div class="flex items-start gap-3">
                    <svg class="w-5 h-5 text-purple-600 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
                    </svg>
                    <div>
                        <h4 class="font-medium text-gray-900">Pembayaran QRIS</h4>
                        <p class="text-sm text-gray-600 mt-1">${settings.qris_instructions || 'Scan kode QRIS di bawah menggunakan aplikasi bank atau e-wallet Anda.'}</p>
                    </div>
                </div>
            `;
            ewalletInfo.classList.add('hidden');
            if (settings.qris_image) {
                qrisContainer.classList.remove('hidden');
                qrisImage.src = settings.qris_image;
            } else {
                qrisContainer.classList.add('hidden');
            }
        }
    }

    updateCartUI() {
        const cartContainer = document.querySelector('.cart-items');
        if (!cartContainer) return;

        cartContainer.innerHTML = '';
        if (this.items.length === 0) {
            cartContainer.innerHTML = `
            <div class="p-5 text-center text-gray-500">
                <p class="text-2xl mb-4">Keranjang belanja Anda kosong.</p>
                <a href="/" class="text-rose-600 hover:text-rose-700 font-medium">
                    Kembali belanja
                </a>
            </div>
            `;
            this.updateOrderSummary(0, 0);
            return;
        }

        const cartContent = document.createElement('div');
        cartContent.className = 'cart-content';

        this.items.forEach(item => {
            cartContent.appendChild(this.createCartItemElement(item));
        });

        cartContainer.appendChild(cartContent);

        const subtotal = this.calculateSubTotal();
        const shipping = this.SHIPPING_COST;
        this.updateOrderSummary(subtotal, shipping);
    }

    attachItemEventListeners(elements, productId) {
        elements.addEventListener('click', (e) => {
            const target = e.target.closest('[data-action]');
            if (!target) return;

            e.preventDefault();
            const action = target.dataset.action;

            switch (action) {
                case 'decrease':
                    this.updateQuantity(productId, -1);
                    break;
                case 'increase':
                    this.updateQuantity(productId, 1);
                    break;
                case 'remove':
                    this.removeItem(productId);
                    break;
            }
        });
    }

    attachEventListeners() {
        document.addEventListener('click', (e) => {
            const addToCartButton = e.target.closest('.add-to-cart-btn');
            if (!addToCartButton) return;

            e.preventDefault();
            const productCard = addToCartButton.closest('.product-card');
            if (!productCard) return;

            const product = {
                id: productCard.dataset.id,
                name: productCard.dataset.name,
                price: productCard.dataset.price,
                image: productCard.dataset.image,
                category_name: productCard.dataset.category
            };
            this.addItem(product);
            this.updateCartUI();
        });
    }

    async processPayment() {
        const form = document.getElementById('checkoutForm');
        if(!form || !form.checkValidity()) {
            form?.reportValidity();
            return;
        }
        const formData = new FormData(form);
        const paymentMethod = formData.get('payment_method') || 'midtrans';
        const payButton = document.getElementById('payButton');
        if(payButton) {
            payButton.disabled = true;
            payButton.textContent = 'Memproses Pembayaran...';
        }

        try{
            if (paymentMethod === 'midtrans') {
                // Process Midtrans payment
                const response = await fetch('/checkout/process', {
                    method: 'POST',
                    headers:{
                        'Content-Type': 'application/json',
                        'Accept': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')?.content
                    },
                    body: JSON.stringify({
                        name: formData.get('name'),
                        phone: formData.get('phone'),
                        shipping_address: formData.get('shipping_address'),
                        notes: formData.get('notes'),
                        cart: this.items
                    })
                });
                if(!response.ok){
                    const error = await response.json();
                    throw new Error(error.message || 'Proses pembayaran gagal');
                }

                const data = await response.json();
                if(!data.status === 'success' || !data.snap_token){
                    throw new Error(error.message || 'Respon pembayaran tidak valid');
                }
                this.handlePayment(data.snap_token, data.order_id, payButton);
            } else {
                // Process manual payment (COD, E-Wallet, QRIS)
                const response = await fetch('/checkout/manual', {
                    method: 'POST',
                    headers:{
                        'Content-Type': 'application/json',
                        'Accept': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')?.content
                    },
                    body: JSON.stringify({
                        name: formData.get('name'),
                        phone: formData.get('phone'),
                        shipping_address: formData.get('shipping_address'),
                        notes: formData.get('notes'),
                        cart: this.items,
                        payment_method: paymentMethod
                    })
                });

                if(!response.ok){
                    const error = await response.json();
                    throw new Error(error.message || 'Proses pembayaran gagal');
                }

                const data = await response.json();
                if(data.status !== 'success'){
                    throw new Error(data.message || 'Respon pembayaran tidak valid');
                }

                // Show success modal with payment details
                this.showManualPaymentSuccess(data);
            }
        }catch(error){
            console.error('payment error',error);
            this.showNotification(error.message || 'Gagal memproses pembayaran', 'error');
            if(payButton){
                payButton.disabled = false;
                payButton.textContent = 'Bayar Sekarang';
            }
        }
    }

    showManualPaymentSuccess(data) {
        const paymentMethodLabels = {
            'cod': 'Bayar di Tempat (COD)',
            'ewallet': 'E-Wallet',
            'qris': 'QRIS'
        };

        const modal = document.createElement('div');
        modal.id = 'manualPaymentModal';
        modal.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50';
        modal.innerHTML = `
            <div class="bg-white rounded-2xl p-6 max-w-md w-full mx-4 shadow-xl">
                <div class="text-center">
                    <div class="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <svg class="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
                        </svg>
                    </div>
                    <h3 class="text-xl font-bold text-gray-900 mb-2">Pesanan Berhasil Dibuat!</h3>
                    <p class="text-gray-600 mb-4">Kode Pesanan: <strong>${data.order_code}</strong></p>
                </div>

                <div class="bg-gray-50 rounded-lg p-4 mb-4">
                    <p class="text-sm text-gray-600 mb-2">Metode Pembayaran: <strong>${paymentMethodLabels[data.payment_method] || data.payment_method}</strong></p>
                    <div class="border-t pt-2 mt-2">
                        <p class="text-sm text-gray-600">Subtotal: Rp ${this.formatPrice(data.total_amount - 20000)}</p>
                        <p class="text-sm text-gray-600">Ongkir: Rp ${this.formatPrice(20000)}</p>
                        ${data.unique_code ? `<p class="text-sm text-gray-600">Kode Unik: +${data.unique_code}</p>` : ''}
                        <p class="text-lg font-bold text-gray-900 mt-2">Total Bayar: Rp ${this.formatPrice(data.unique_amount)}</p>
                    </div>
                </div>

                ${data.payment_method === 'cod' ? `
                <div class="bg-green-50 border border-green-200 rounded-lg p-4 mb-4">
                    <p class="text-sm text-green-800">
                        <strong>COD:</strong> Silakan siapkan uang tunai sebesar <strong>Rp ${this.formatPrice(data.unique_amount)}</strong>
                        saat pesanan tiba di alamat Anda.
                    </p>
                </div>
                ` : `
                <div class="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-4">
                    <p class="text-sm text-yellow-800">
                        <strong>Penting:</strong> Silakan transfer/bayar sebesar <strong>Rp ${this.formatPrice(data.unique_amount)}</strong>
                        ${data.unique_code ? `(dengan kode unik ${data.unique_code})` : ''} agar pesanan dapat segera diproses.
                    </p>
                </div>
                `}

                <div class="flex gap-3">
                    <a href="/" class="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg text-center hover:bg-gray-50 transition">
                        Kembali ke Beranda
                    </a>
                    <button onclick="document.getElementById('manualPaymentModal').remove()" class="flex-1 px-4 py-2 bg-rose-500 text-white rounded-lg hover:bg-rose-600 transition">
                        Tutup
                    </button>
                </div>
            </div>
        `;

        document.body.appendChild(modal);

        // Clear cart
        this.items = [];
        this.saveCartToStoreStorage();
    }
    handlePayButtonClick() {
        const payButton = document.getElementById('payButton');
        if (payButton) {
            payButton.addEventListener('click', async () => {
                await this.processPayment();
            });
        }
    }

    handlePayment(snapToken, orderId, payButton) {
        if (!window.snap || typeof window.snap.pay !== 'function') {
            console.error('Midtrans Snap is not initialized.');
            this.showNotification('Gateway pembayaran tidak aktif. Silakan muat ulang halaman.', 'error');
            payButton.disabled = false;
            payButton.textContent = 'Bayar Sekarang';
            return;
        }

        window.snap.pay(snapToken, {
            onSuccess: async (result) => {
                await this.updateOrderStatus(result, 'paid');
                this.items = [];
                this.saveCartToStoreStorage();
                window.location.href = '/orders';
            },
            onPending: async (result) => {
                await this.updateOrderStatus(result, 'pending');
                this.items = [];
                this.saveCartToStoreStorage();
                window.location.href = '/orders';
            },
            onError: async (result) => {
                await this.updateOrderStatus(result, 'failed');
                this.showNotification('Pembayaran gagal', 'error');
                payButton.disabled = false;
                payButton.textContent = 'Bayar Sekarang';
            },
            onClose: () => {
                if (confirm('Apakah Anda ingin melanjutkan pembayaran?')) {
                    window.location.href = '/orders';
                } else {
                    payButton.disabled = false;
                    payButton.textContent = 'Bayar Sekarang';
                }
            },
        });
    }

    updateOrderStatus(paymentResult, status) {
        fetch('/payments/update-status', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
            },
            body: JSON.stringify({
                order_id: paymentResult.order_id,
                transaction_id: paymentResult.transaction_id,
                payment_type: paymentResult.payment_type,
                status: status
            }),
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                console.log('Order status updated successfully:', data.message);
                setTimeout(() => {
                    window.location.href = '/';
                }, 2000);
            } else {
                console.error('Failed to update order status:', data.message);
            }
        })
        .catch(error => console.error('Error updating order status:', error));
    }
}

export default ShoppingCart;
