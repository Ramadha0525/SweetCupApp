# API Documentation - SEGARIN

Base URL: `https://cybershop.co-id.id/api`

## Authentication

All protected routes require `Authorization: Bearer {token}` header.

---

## Public Endpoints

### Register
```
POST /register
Body: {
    "name": "string",
    "email": "string",
    "password": "string",
    "password_confirmation": "string",
    "phone": "string",
    "address": "string"
}
Response: {
    "status": "success",
    "data": {
        "user": {...},
        "token": "string"
    }
}
```

### Login
```
POST /login
Body: {
    "email": "string",
    "password": "string"
}
Response: {
    "status": "success",
    "data": {
        "user": {...},
        "token": "string"
    }
}
```

### Get Products
```
GET /products?search=&category=&sort=&per_page=12
Response: {
    "status": "success",
    "data": {
        "data": [...],
        "links": {...},
        "meta": {...}
    }
}
```

### Get Product Detail
```
GET /products/{slug}
Response: {
    "status": "success",
    "data": {
        "id": 1,
        "name": "Product Name",
        "slug": "product-name",
        "description": "...",
        "price": 15000,
        "image": "base64...",
        "category": {...},
        "reviews": [...],
        "average_rating": 4.5,
        "reviews_count": 10
    }
}
```

### Get Categories
```
GET /categories
Response: {
    "status": "success",
    "data": [
        {
            "id": 1,
            "name": "Es Krim Cup",
            "icon": "🍦",
            "slug": "es-krim-cup",
            "products_count": 5
        }
    ]
}
```

### Get Payment Settings
```
GET /payment-settings
Response: {
    "status": "success",
    "data": {
        "shipping_cost": "20000",
        "manual_payment_enabled": "1",
        "cod_enabled": "1",
        "ewallet_enabled": "1",
        "ewallet_name": "GoPay",
        "ewallet_number": "08123456789",
        "qris_enabled": "1",
        "qris_image": "base64..."
    }
}
```

---

## Protected Endpoints (Requires Bearer Token)

### Logout
```
POST /logout
Response: {
    "status": "success",
    "message": "Logout berhasil"
}
```

### Get User Profile
```
GET /user
Response: {
    "status": "success",
    "data": {
        "id": 1,
        "name": "John Doe",
        "email": "john@example.com",
        "phone": "08123456789",
        "address": "Jl. Example No. 1",
        "role": "user"
    }
}
```

### Update Profile
```
PUT /profile
Body: {
    "name": "string (optional)",
    "phone": "string (optional)",
    "address": "string (optional)",
    "password": "string (optional)",
    "password_confirmation": "string (optional)"
}
Response: {
    "status": "success",
    "message": "Profil berhasil diupdate",
    "data": {...}
}
```

### Checkout (Midtrans)
```
POST /checkout
Body: {
    "name": "string",
    "phone": "string",
    "shipping_address": "string",
    "notes": "string (optional)",
    "coupon_code": "string (optional)",
    "cart": [
        {
            "id": 1,
            "name": "Product Name",
            "price": 15000,
            "quantity": 2
        }
    ]
}
Response: {
    "status": "success",
    "data": {
        "order_id": 1,
        "order_code": "ORDE260714001",
        "snap_token": "...",
        "total_amount": 50000,
        "discount": 5000
    }
}
```

### Checkout Manual (COD/E-Wallet/QRIS)
```
POST /checkout/manual
Body: {
    "name": "string",
    "phone": "string",
    "shipping_address": "string",
    "notes": "string (optional)",
    "payment_method": "cod|ewallet|qris",
    "cart": [...]
}
Response: {
    "status": "success",
    "data": {
        "order_id": 1,
        "order_code": "ORDE260714001",
        "payment_method": "cod",
        "total_amount": 50000,
        "unique_code": 627,
        "unique_amount": 50627
    }
}
```

### Get Orders
```
GET /orders?status=pending|paid|processing|shipped|delivered
Response: {
    "status": "success",
    "data": {
        "data": [...],
        "links": {...},
        "meta": {...}
    }
}
```

### Get Order Detail
```
GET /orders/{id}
Response: {
    "status": "success",
    "data": {
        "id": 1,
        "order_code": "ORDE260714001",
        "status": "pending",
        "total_amount": 50000,
        "unique_amount": 50627,
        "payment_method": "cod",
        "shipping_address": "...",
        "items": [...]
    }
}
```

### Add Review
```
POST /reviews
Body: {
    "product_id": 1,
    "rating": 5,
    "comment": "Produk bagus!"
}
Response: {
    "status": "success",
    "message": "Review berhasil disimpan"
}
```

### Delete Review
```
DELETE /reviews/{id}
Response: {
    "status": "success",
    "message": "Review berhasil dihapus"
}
```

### Toggle Wishlist
```
POST /wishlist/toggle
Body: {
    "product_id": 1
}
Response: {
    "status": "success",
    "data": {
        "status": "added|removed"
    }
}
```

### Get Wishlist
```
GET /wishlist
Response: {
    "status": "success",
    "data": {
        "data": [...],
        "links": {...},
        "meta": {...}
    }
}
```

### Apply Coupon
```
POST /coupons/apply
Body: {
    "code": "DISKON20"
}
Response: {
    "status": "success",
    "data": {
        "code": "DISKON20",
        "type": "percentage",
        "value": 20
    }
}
```

---

## Status Codes

- `200` - Success
- `201` - Created
- `400` - Bad Request
- `401` - Unauthorized
- `403` - Forbidden
- `422` - Validation Error
- `500` - Server Error

---

## Notes for Android Developer

1. **Cart Management**: Store cart in SharedPreferences/Room, send to API on checkout
2. **Image Handling**: Product images are base64 encoded, decode in app
3. **Payment Flow**:
   - Midtrans: Use Snap token with Midtrans SDK
   - COD: No payment needed, show instructions
   - E-Wallet: Show transfer details
   - QRIS: Display QR image for scanning
4. **Unique Code**: For manual payments (except COD), add unique code to total
5. **Error Handling**: Always check `status` field in response