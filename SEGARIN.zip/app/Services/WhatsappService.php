<?php

namespace App\Services;

use App\Models\Setting;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class WhatsappService
{
    /**
     * Send WhatsApp message using Fonnte API
     *
     * @param string $target Recipient number
     * @param string $message Message content
     * @return bool
     */
    public static function sendMessage(string $target, string $message): bool
    {
        $token = Setting::get('whatsapp_fonnte_token');
        if (empty($token)) {
            Log::warning('Fonnte token is empty, cannot send WhatsApp message');
            return false;
        }

        try {
            // Clean target phone number
            $target = self::cleanPhoneNumber($target);

            Log::info("Sending WhatsApp message to {$target} via Fonnte");

            $response = Http::withHeaders([
                'Authorization' => $token,
            ])->post('https://api.fonnte.com/send', [
                'target' => $target,
                'message' => $message,
                'countryCode' => '62',
            ]);

            if ($response->successful()) {
                $result = $response->json();
                Log::info("WhatsApp message sent successfully", ['result' => $result]);
                return $result['status'] ?? false;
            } else {
                Log::error("Fonnte API returned error response", [
                    'status' => $response->status(),
                    'body' => $response->body()
                ]);
            }
        } catch (\Exception $e) {
            Log::error("Error sending WhatsApp message: " . $e->getMessage());
        }

        return false;
    }

    /**
     * Clean phone number format for WhatsApp
     *
     * @param string $number
     * @return string
     */
    private static function cleanPhoneNumber(string $number): string
    {
        // Remove spaces, dashes, parentheses
        $number = preg_replace('/[^0-9]/', '', $number);

        // Convert leading 0 to 62
        if (str_starts_with($number, '0')) {
            $number = '62' . substr($number, 1);
        }

        return $number;
    }
}
