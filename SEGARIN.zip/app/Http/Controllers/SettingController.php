<?php

namespace App\Http\Controllers;

use App\Models\Setting;
use Illuminate\Http\Request;

class SettingController extends Controller
{
    public function gateway()
    {
        $fonnteToken = Setting::get('whatsapp_fonnte_token', '');
        $adminPhone = Setting::get('whatsapp_admin_number', '');
        $notifyCheckout = Setting::get('whatsapp_notify_checkout', '1');
        $notifyStatus = Setting::get('whatsapp_notify_status_update', '1');

        return view('admin.gateway', compact('fonnteToken', 'adminPhone', 'notifyCheckout', 'notifyStatus'));
    }

    public function storeGateway(Request $request)
    {
        $validated = $request->validate([
            'whatsapp_fonnte_token' => 'nullable|string',
            'whatsapp_admin_number' => 'nullable|string',
            'whatsapp_notify_checkout' => 'nullable|string',
            'whatsapp_notify_status_update' => 'nullable|string',
        ]);

        Setting::set('whatsapp_fonnte_token', $request->whatsapp_fonnte_token ?? '');
        Setting::set('whatsapp_admin_number', $request->whatsapp_admin_number ?? '');
        Setting::set('whatsapp_notify_checkout', $request->whatsapp_notify_checkout ? '1' : '0');
        Setting::set('whatsapp_notify_status_update', $request->whatsapp_notify_status_update ? '1' : '0');

        return back()->with('success', 'Pengaturan Gateway WhatsApp berhasil disimpan!');
    }

    public function midtransSettings()
    {
        $merchantId    = Setting::get('midtrans_merchant_id', '');
        $clientKey     = Setting::get('midtrans_client_key', '');
        $serverKey     = Setting::get('midtrans_server_key', '');
        $isProduction  = Setting::get('midtrans_is_production', '0');

        return view('admin.midtrans', compact('merchantId', 'clientKey', 'serverKey', 'isProduction'));
    }

    public function storeMidtrans(Request $request)
    {
        $request->validate([
            'midtrans_merchant_id' => 'nullable|string',
            'midtrans_client_key'  => 'nullable|string',
            'midtrans_server_key'  => 'nullable|string',
        ]);

        Setting::set('midtrans_merchant_id',   $request->midtrans_merchant_id   ?? '');
        Setting::set('midtrans_client_key',    $request->midtrans_client_key    ?? '');
        Setting::set('midtrans_server_key',    $request->midtrans_server_key    ?? '');
        Setting::set('midtrans_is_production', $request->midtrans_is_production ? '1' : '0');

        return back()->with('success', 'Konfigurasi Midtrans berhasil disimpan!');
    }
}
