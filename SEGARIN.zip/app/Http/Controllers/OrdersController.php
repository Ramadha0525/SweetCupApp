<?php

namespace App\Http\Controllers;

use App\Models\Order;
use Illuminate\Http\Request;
use App\Models\Setting;
use App\Services\WhatsappService;

class OrdersController extends Controller
{
    public function index(Request $request)
    {
        $orders = Order::query()
            ->with(['user', 'items.product'])
            ->whereIn('status', ['pending', 'paid', 'processing', 'shipped'])
            ->when($request->search, function ($query, $search) {
                $query->where(function ($q) use ($search) {
                    $q->where('id', 'like', "%{$search}%")
                      ->orWhere('order_code', 'like', "%{$search}%") 
                      ->orWhereHas('user', function ($q) use ($search) {
                          $q->where('name', 'like', "%{$search}%")
                            ->orWhere('email', 'like', "%{$search}%");
                      })
                      ->orWhere('shipping_address', 'like', "%{$search}%")
                      ->orWhere('resi_code', 'like', "%{$search}%");
                });
            })

            ->when($request->status, function ($query, $status) {
                $query->where('status', $status);
            })
            ->latest()
            ->paginate(5)
            ->withQueryString();

        return view('admin.order', compact('orders'));
    }


    public function updateStatus(Request $request, Order $order)
    {
        try {
            $validated = $request->validate([
                'status' => ['required', 'string', 'max:255'],
                'resi' => ['required_if:status,shipped', 'string', 'nullable'],
            ]);

            if ($request->status == 'shipped') {
                if (empty($request->resi_code)) {
                    throw new \Exception('Resi code is required for shipped status');
                }
                $order->resi_code = $request->resi_code;
                $order->save();
            }
            $order->updateStatus($request->status);

            // Send WhatsApp notification to Customer if enabled
            if (Setting::get('whatsapp_notify_status_update', '1') === '1') {
                $customerPhone = $order->user->phone;
                if (!empty($customerPhone)) {
                    $statusIndo = [
                        'pending' => 'Menunggu Pembayaran',
                        'paid' => 'Sudah Dibayar',
                        'processing' => 'Sedang Diproses',
                        'shipped' => 'Sedang Dikirim',
                        'delivered' => 'Sudah Diterima',
                        'cancelled' => 'Dibatalkan',
                    ][$request->status] ?? $request->status;

                    $msg = "🥤 *UPDATE STATUS PESANAN* 🥤\n\n"
                         . "Halo " . $order->user->name . ",\n"
                         . "Status pesanan Anda dengan kode *" . $order->order_code . "* saat ini adalah: *" . $statusIndo . "*\n\n";

                    if ($request->status === 'processing') {
                        $msg .= "Admin kami sedang menyiapkan es krim / jajanan Anda agar tetap segar saat tiba! 🚀\n";
                    } elseif ($request->status === 'shipped') {
                        $msg .= "Pesanan Anda sedang dalam perjalanan ke alamat Anda!\n";
                        if (!empty($order->resi_code)) {
                            $msg .= "No. Resi / Pengantar: *" . $order->resi_code . "*\n";
                        }
                    } elseif ($request->status === 'delivered') {
                        $msg .= "Terima kasih telah berbelanja di SweetCup! Selamat menikmati jajanan Anda. 😊🍦\n";
                    } elseif ($request->status === 'cancelled') {
                        $msg .= "Mohon maaf, pesanan Anda telah dibatalkan. Silakan hubungi admin jika ada pertanyaan.\n";
                    }

                    $msg .= "\nDetail pesanan Anda:\n"
                         . "Total Bayar: Rp " . number_format($order->total_amount, 0, ',', '.') . "\n"
                         . "Alamat Pengiriman: " . $order->shipping_address . "\n\n"
                         . "Terima kasih telah memilih SweetCup!";

                    WhatsappService::sendMessage($customerPhone, $msg);
                }
            }

            return redirect()->back()->with('success', 'Order status updated successfully');
        } catch (\Exception $e) {
            return redirect()->back()->with('error', $e->getMessage());
        }
    }

    public function confirmManualPayment(Request $request, Order $order)
    {
        try {
            $validated = $request->validate([
                'status' => ['required', 'string', 'in:confirmed,rejected'],
                'note' => ['nullable', 'string'],
            ]);

            if (!$order->isManualPayment()) {
                throw new \Exception('This order is not a manual payment order');
            }

            $order->update([
                'manual_payment_status' => $request->status,
                'manual_payment_note' => $request->note,
            ]);

            if ($request->status === 'confirmed') {
                $order->updateStatus('paid');
            }

            // Send WhatsApp notification to customer
            if (Setting::get('whatsapp_notify_status_update', '1') === '1') {
                $customerPhone = $order->user->phone;
                if (!empty($customerPhone)) {
                    $statusText = $request->status === 'confirmed' ? 'Dikonfirmasi ✅' : 'Ditolak ❌';
                    $msg = "🔔 *UPDATE PEMBAYARAN* 🔔\n\n"
                         . "Halo " . $order->user->name . ",\n"
                         . "Pembayaran pesanan *" . $order->order_code . "* telah *" . $statusText . "*\n\n"
                         . "Total Bayar: Rp " . number_format($order->unique_amount, 0, ',', '.') . "\n";

                    if ($request->status === 'rejected' && !empty($request->note)) {
                        $msg .= "Catatan: " . $request->note . "\n";
                    }

                    $msg .= "\nTerima kasih!";

                    WhatsappService::sendMessage($customerPhone, $msg);
                }
            }

            return redirect()->back()->with('success', 'Status pembayaran manual berhasil diupdate');
        } catch (\Exception $e) {
            return redirect()->back()->with('error', $e->getMessage());
        }
    }
}
