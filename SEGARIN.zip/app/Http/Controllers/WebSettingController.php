<?php

namespace App\Http\Controllers;

use App\Models\Setting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class WebSettingController extends Controller
{
    public function index()
    {
        $settings = [
            'store_name' => Setting::get('store_name', 'SweetCup Delivery'),
            'store_description' => Setting::get('store_description', 'Es Krim Cup & Jajanan Siap Antar Terpercaya'),
            'store_email' => Setting::get('store_email', 'support@sweetcup.com'),
            'store_phone' => Setting::get('store_phone', '08123456789'),
            'store_address' => Setting::get('store_address', 'Jl. Contoh No. 123'),
            'footer_text' => Setting::get('footer_text', '© 2026 SweetCup Delivery. All rights reserved.'),
            'whatsapp_number' => Setting::get('whatsapp_number', '6281322686833'),
            'instagram_url' => Setting::get('instagram_url', ''),
            'facebook_url' => Setting::get('facebook_url', ''),
            'tiktok_url' => Setting::get('tiktok_url', ''),
            'theme_primary' => Setting::get('theme_primary', '#f43f5e'),
            'theme_secondary' => Setting::get('theme_secondary', '#f97316'),
            'theme_dark' => Setting::get('theme_dark', '#1f2937'),
        ];

        return view('admin.web-setting', compact('settings'));
    }

    public function store(Request $request)
    {
        try {
            $validated = $request->validate([
                'store_name' => 'nullable|string|max:255',
                'store_description' => 'nullable|string|max:500',
                'store_email' => 'nullable|email|max:255',
                'store_phone' => 'nullable|string|max:255',
                'store_address' => 'nullable|string|max:500',
                'footer_text' => 'nullable|string|max:500',
                'whatsapp_number' => 'nullable|string|max:255',
                'instagram_url' => 'nullable|url|max:500',
                'facebook_url' => 'nullable|url|max:500',
                'tiktok_url' => 'nullable|url|max:500',
                'theme_primary' => 'nullable|string|max:7',
                'theme_secondary' => 'nullable|string|max:7',
                'theme_dark' => 'nullable|string|max:7',
            ]);

            foreach ($validated as $key => $value) {
                Setting::set($key, $value ?? '');
            }

            return back()->with('success', 'Pengaturan web berhasil disimpan!');
        } catch (\Exception $e) {
            Log::error('Error saving web settings: ' . $e->getMessage());
            return back()->with('error', 'Gagal menyimpan pengaturan: ' . $e->getMessage());
        }
    }

    public function getSettings()
    {
        return response()->json([
            'store_name' => Setting::get('store_name', 'SweetCup Delivery'),
            'store_description' => Setting::get('store_description', ''),
            'footer_text' => Setting::get('footer_text', '© 2026 SweetCup Delivery. All rights reserved.'),
            'whatsapp_number' => Setting::get('whatsapp_number', '6281322686833'),
            'instagram_url' => Setting::get('instagram_url', ''),
            'facebook_url' => Setting::get('facebook_url', ''),
            'tiktok_url' => Setting::get('tiktok_url', ''),
            'theme_primary' => Setting::get('theme_primary', '#f43f5e'),
            'theme_secondary' => Setting::get('theme_secondary', '#f97316'),
            'theme_dark' => Setting::get('theme_dark', '#1f2937'),
        ]);
    }
}
