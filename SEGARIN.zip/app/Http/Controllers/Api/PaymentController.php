<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Setting;

class PaymentController extends Controller
{
    public function settings()
    {
        return response()->json([
            'status' => 'success',
            'data' => [
                'shipping_cost' => Setting::get('shipping_cost', '20000'),
                'manual_payment_enabled' => Setting::get('manual_payment_enabled', '1'),
                'cod_enabled' => Setting::get('cod_enabled', '1'),
                'cod_instructions' => Setting::get('cod_instructions', ''),
                'ewallet_enabled' => Setting::get('ewallet_enabled', '1'),
                'ewallet_name' => Setting::get('ewallet_name', 'GoPay'),
                'ewallet_number' => Setting::get('ewallet_number', ''),
                'ewallet_owner' => Setting::get('ewallet_owner', ''),
                'ewallet_instructions' => Setting::get('ewallet_instructions', ''),
                'qris_enabled' => Setting::get('qris_enabled', '1'),
                'qris_image' => Setting::get('qris_image', ''),
                'qris_instructions' => Setting::get('qris_instructions', ''),
            ]
        ]);
    }
}
