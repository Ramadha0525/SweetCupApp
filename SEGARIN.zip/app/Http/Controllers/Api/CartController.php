<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Setting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Midtrans\Config;
use Midtrans\Snap;

class CartController extends Controller
{
    public function checkout(Request $request)
    {
        try {
            $this->initMidtrans();

            $validated = $request->validate([
                'name' => 'required|string',
                'phone' => 'required|string',
                'shipping_address' => 'required|string',
                'notes' => 'nullable|string',
                'cart' => 'required|array',
                'coupon_code' => 'nullable|string',
            ]);

            DB::beginTransaction();

            $order = Order::create([
                'user_id' => $request->user()->id,
                'shipping_address' => $request->shipping_address,
                'total_amount' => 0,
                'status' => 'pending',
                'notes' => $request->notes,
            ]);

            $totalAmount = 0;
            $items = [];

            foreach ($request->cart as $item) {
                OrderItem::create([
                    'order_id' => $order->id,
                    'product_id' => $item['id'],
                    'quantity' => $item['quantity'],
                    'price' => $item['price'],
                ]);

                $totalAmount += $item['price'] * $item['quantity'];
                $items[] = [
                    'id' => (string) $item['id'],
                    'price' => (int) $item['price'],
                    'quantity' => (int) $item['quantity'],
                    'name' => $item['name'],
                ];
            }

            $shippingCost = (int) Setting::get('shipping_cost', 20000);
            $totalAmount += $shippingCost;

            // Apply coupon if exists
            $discount = 0;
            if ($request->coupon_code) {
                $coupon = \App\Models\Coupon::where('code', strtoupper($request->coupon_code))->first();
                if ($coupon && $coupon->isValid()) {
                    $discount = $coupon->calculateDiscount($totalAmount);
                    $totalAmount -= $discount;
                    $coupon->increment('used_count');
                }
            }

            $order->update(['total_amount' => $totalAmount]);

            $params = [
                'transaction_details' => [
                    'order_id' => (string) $order->id,
                    'gross_amount' => (int) $totalAmount,
                ],
                'item_details' => array_merge($items, [
                    [
                        'id' => 'shipping',
                        'price' => $shippingCost,
                        'quantity' => 1,
                        'name' => 'Shipping Cost',
                    ]
                ]),
                'customer_details' => [
                    'first_name' => $request->name,
                    'email' => $request->user()->email,
                    'phone' => $request->phone,
                    'billing_address' => ['address' => $request->shipping_address],
                    'shipping_address' => ['address' => $request->shipping_address],
                ]
            ];

            $snapToken = Snap::getSnapToken($params);
            $order->update(['snap_token' => $snapToken]);

            DB::commit();

            $request->user()->update([
                'name' => $request->name,
                'phone' => $request->phone,
                'address' => $request->shipping_address,
            ]);

            return response()->json([
                'status' => 'success',
                'data' => [
                    'order_id' => $order->id,
                    'order_code' => $order->order_code,
                    'snap_token' => $snapToken,
                    'total_amount' => $totalAmount,
                    'discount' => $discount,
                ]
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'status' => 'error',
                'message' => $e->getMessage()
            ], 500);
        }
    }

    public function checkoutManual(Request $request)
    {
        try {
            $validated = $request->validate([
                'name' => 'required|string',
                'phone' => 'required|string',
                'shipping_address' => 'required|string',
                'notes' => 'nullable|string',
                'cart' => 'required|array',
                'payment_method' => 'required|in:cod,ewallet,qris',
            ]);

            DB::beginTransaction();

            $order = Order::create([
                'user_id' => $request->user()->id,
                'shipping_address' => $request->shipping_address,
                'total_amount' => 0,
                'status' => 'pending',
                'notes' => $request->notes,
                'payment_method' => $request->payment_method,
            ]);

            $totalAmount = 0;

            foreach ($request->cart as $item) {
                OrderItem::create([
                    'order_id' => $order->id,
                    'product_id' => $item['id'],
                    'quantity' => $item['quantity'],
                    'price' => $item['price'],
                ]);

                $totalAmount += $item['price'] * $item['quantity'];
            }

            $shippingCost = (int) Setting::get('shipping_cost', 20000);
            $totalAmount += $shippingCost;

            if ($request->payment_method !== 'cod') {
                $uniqueCode = Order::generateUniqueCode();
                $uniqueAmount = $totalAmount + $uniqueCode;
            } else {
                $uniqueCode = null;
                $uniqueAmount = $totalAmount;
            }

            $order->update([
                'total_amount' => $totalAmount,
                'unique_code' => $uniqueCode,
                'unique_amount' => $uniqueAmount,
                'manual_payment_status' => 'pending_confirmation',
            ]);

            DB::commit();

            $request->user()->update([
                'name' => $request->name,
                'phone' => $request->phone,
                'address' => $request->shipping_address,
            ]);

            return response()->json([
                'status' => 'success',
                'data' => [
                    'order_id' => $order->id,
                    'order_code' => $order->order_code,
                    'payment_method' => $request->payment_method,
                    'total_amount' => $totalAmount,
                    'unique_code' => $uniqueCode,
                    'unique_amount' => $uniqueAmount,
                ]
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'status' => 'error',
                'message' => $e->getMessage()
            ], 500);
        }
    }

    private function initMidtrans()
    {
        $serverKey = Setting::get('midtrans_server_key', config('midtrans.server_key'));
        if (empty($serverKey)) {
            throw new \Exception('Server key Midtrans belum dikonfigurasi');
        }

        $isProduction = filter_var(
            Setting::get('midtrans_is_production', '0'),
            FILTER_VALIDATE_BOOLEAN
        );

        Config::$serverKey = $serverKey;
        Config::$isProduction = $isProduction;
        Config::$isSanitized = true;
        Config::$is3ds = true;
    }
}
