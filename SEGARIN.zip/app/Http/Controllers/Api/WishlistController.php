<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Wishlist;
use Illuminate\Http\Request;

class WishlistController extends Controller
{
    public function index(Request $request)
    {
        $wishlists = Wishlist::with('product.category')
            ->where('user_id', $request->user()->id)
            ->latest()
            ->paginate(12);

        return response()->json([
            'status' => 'success',
            'data' => $wishlists
        ]);
    }

    public function toggle(Request $request)
    {
        $productId = $request->product_id;

        $existing = Wishlist::where('user_id', $request->user()->id)
            ->where('product_id', $productId)
            ->first();

        if ($existing) {
            $existing->delete();
            $status = 'removed';
        } else {
            Wishlist::create([
                'user_id' => $request->user()->id,
                'product_id' => $productId,
            ]);
            $status = 'added';
        }

        return response()->json([
            'status' => 'success',
            'data' => ['status' => $status]
        ]);
    }
}
