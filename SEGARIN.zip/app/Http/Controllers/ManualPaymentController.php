<?php

namespace App\Http\Controllers;

use App\Models\Setting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class ManualPaymentController extends Controller
{
    public function index()
    {
        $settings = [
            'shipping_cost' => Setting::get('shipping_cost', '20000'),
            'manual_payment_enabled' => Setting::get('manual_payment_enabled', '1'),
            'cod_enabled' => Setting::get('cod_enabled', '1'),
            'cod_instructions' => Setting::get('cod_instructions', 'Bayar langsung kepada kurir saat pesanan tiba di alamat Anda.'),
            'ewallet_enabled' => Setting::get('ewallet_enabled', '1'),
            'ewallet_name' => Setting::get('ewallet_name', 'GoPay'),
            'ewallet_number' => Setting::get('ewallet_number', ''),
            'ewallet_owner' => Setting::get('ewallet_owner', ''),
            'ewallet_instructions' => Setting::get('ewallet_instructions', 'Transfer ke nomor E-Wallet di atas, lalu kirim bukti transfer.'),
            'qris_enabled' => Setting::get('qris_enabled', '1'),
            'qris_image' => Setting::get('qris_image', ''),
            'qris_instructions' => Setting::get('qris_instructions', 'Scan kode QRIS di atas menggunakan aplikasi bank atau e-wallet Anda.'),
        ];

        return view('admin.manual-payment', compact('settings'));
    }

    public function store(Request $request)
    {
        try {
            $validated = $request->validate([
                'shipping_cost' => 'nullable|numeric|min:0',
                'manual_payment_enabled' => 'nullable|string',
                'cod_enabled' => 'nullable|string',
                'cod_instructions' => 'nullable|string',
                'ewallet_enabled' => 'nullable|string',
                'ewallet_name' => 'nullable|string|max:255',
                'ewallet_number' => 'nullable|string|max:255',
                'ewallet_owner' => 'nullable|string|max:255',
                'ewallet_instructions' => 'nullable|string',
                'qris_enabled' => 'nullable|string',
                'qris_image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
                'qris_instructions' => 'nullable|string',
            ]);

            Setting::set('shipping_cost', $request->shipping_cost ?? '20000');
            Setting::set('manual_payment_enabled', $request->manual_payment_enabled ? '1' : '0');
            Setting::set('cod_enabled', $request->cod_enabled ? '1' : '0');
            Setting::set('cod_instructions', $request->cod_instructions ?? '');
            Setting::set('ewallet_enabled', $request->ewallet_enabled ? '1' : '0');
            Setting::set('ewallet_name', $request->ewallet_name ?? '');
            Setting::set('ewallet_number', $request->ewallet_number ?? '');
            Setting::set('ewallet_owner', $request->ewallet_owner ?? '');
            Setting::set('ewallet_instructions', $request->ewallet_instructions ?? '');
            Setting::set('qris_enabled', $request->qris_enabled ? '1' : '0');
            Setting::set('qris_instructions', $request->qris_instructions ?? '');

            if ($request->hasFile('qris_image')) {
                $image = $request->file('qris_image');
                $imageBase64 = base64_encode(file_get_contents($image->getRealPath()));
                $qrisImage = 'data:' . $image->getMimeType() . ';base64,' . $imageBase64;
                Setting::set('qris_image', $qrisImage);
            }

            return back()->with('success', 'Pengaturan metode pembayaran manual berhasil disimpan!');
        } catch (\Exception $e) {
            Log::error('Error saving manual payment settings: ' . $e->getMessage());
            return back()->with('error', 'Gagal menyimpan pengaturan: ' . $e->getMessage());
        }
    }

    public function getSettings()
    {
        return response()->json([
            'shipping_cost' => Setting::get('shipping_cost', '20000'),
            'manual_payment_enabled' => Setting::get('manual_payment_enabled', '1'),
            'cod_enabled' => Setting::get('cod_enabled', '1'),
            'cod_instructions' => Setting::get('cod_instructions', ''),
            'ewallet_enabled' => Setting::get('ewallet_enabled', '1'),
            'ewallet_name' => Setting::get('ewallet_name', 'GoPay'),
            'ewallet_number' => Setting::get('ewallet_number', ''),
            'ewallet_owner' => Setting::get('ewallet_owner', ''),
            'ewallet_instructions' => Setting::get('ewallet_instructions', ''),
            'qris_enabled' => Setting::get('qris_enabled', '1'),
            'qris_image' => Setting::get('qris_image', ''),
            'qris_instructions' => Setting::get('qris_instructions', ''),
        ]);
    }
}
