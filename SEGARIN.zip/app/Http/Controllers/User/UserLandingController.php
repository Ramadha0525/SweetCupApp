<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Product;
use App\Models\Setting;
use Illuminate\Http\Request;

class UserLandingController extends Controller
{
    public function index(Request $request)
    {
        $categories = Category::all();
        $query = Product::query()->active()->inStock();

        if ($request->search) {
            $query->where('name', 'like', "%{$request->search}%");
        }
        if ($request->category) {
            $query->where('category_id', $request->category);
        }
        if ($request->sort) {
            switch ($request->sort) {
                case 'price_low':
                    $query->orderBy('price', 'asc');
                    break;
                case 'price_high':
                    $query->orderBy('price', 'desc');
                    break;
                case 'latest':
                    $query->orderBy('created_at', 'desc');
                    break;
            }
        } else {
            $query->latest();
        }

        $products = $query->paginate(8);
        $products->appends($request->all());

        $webSettings = [
            'store_name' => Setting::get('store_name', 'SweetCup Delivery'),
            'store_description' => Setting::get('store_description', ''),
            'footer_text' => Setting::get('footer_text', '© 2026 SweetCup Delivery. All rights reserved.'),
            'whatsapp_number' => Setting::get('whatsapp_number', '6281322686833'),
            'instagram_url' => Setting::get('instagram_url', ''),
            'facebook_url' => Setting::get('facebook_url', ''),
            'tiktok_url' => Setting::get('tiktok_url', ''),
            'theme_primary' => Setting::get('theme_primary', '#f43f5e'),
            'theme_secondary' => Setting::get('theme_secondary', '#f97316'),
            'theme_dark' => Setting::get('theme_dark', '#1f2937'),
        ];

        if ($request->ajax()) {
            return view('partials.product-user', compact('products'))->render();
        }

        return view('landing.landing-page', compact('products', 'categories', 'webSettings'));
    }
}
