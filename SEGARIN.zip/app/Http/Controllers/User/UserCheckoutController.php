<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\OrderItem;
use Exception;
use Illuminate\Http\Request;
use Midtrans\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Midtrans\Snap;
use Symfony\Component\HttpFoundation\JsonResponse;
use App\Models\Setting;
use App\Services\WhatsappService;

class UserCheckoutController extends Controller
{

    private function initMidtrans(): void
    {
        $serverKey = Setting::get('midtrans_server_key', config('midtrans.server_key'));
        if (empty($serverKey)) {
            throw new Exception('Server key Midtrans belum dikonfigurasi. Silakan atur di Settings → Konfigurasi Midtrans.');
        }

        $isProduction = filter_var(
            Setting::get('midtrans_is_production', '0'),
            FILTER_VALIDATE_BOOLEAN
        );

        Config::$serverKey    = $serverKey;
        Config::$isProduction = $isProduction;
        Config::$isSanitized  = true;
        Config::$is3ds        = true;
    }

    public function process(Request $request): JsonResponse
    {
        try {
            $this->initMidtrans();

            if (!auth()->check()) {
                return response()->json([
                    'status' => 'failed',
                    'message' => 'User not authenticated'
                ], 401);
            }

            $validated = $request->validate([
                'name' => ['required', 'string'],
                'phone' => ['required', 'string'],
                'shipping_address' => ['required', 'string'],
                'notes' => ['nullable', 'string'],
                'cart' => ['required', 'array'],
            ]);

            DB::beginTransaction();

            Log::info('Checkout process started', ['user_id' => auth()->id()]);

            $order = Order::create([
                'user_id' => auth()->id(),
                'shipping_address' => $request->shipping_address,
                'total_amount' => 0,
                'status' => 'pending',
                'notes' => $request->notes,
            ]);

            $totalAmount = 0;
            $items = [];

            foreach ($request->cart as $item) {
                if (!isset($item['id'], $item['quantity'], $item['price'], $item['name'])) {
                    throw new Exception('Invalid cart item');
                }

                OrderItem::create([
                    'order_id' => $order->id,
                    'product_id' => $item['id'],
                    'quantity' => $item['quantity'],
                    'price' => $item['price'],
                ]);

                $totalAmount += $item['price'] * $item['quantity'];

                $items[] = [
                    'id' => (string) $item['id'],
                    'price' => (int) $item['price'],
                    'quantity' => (int) $item['quantity'],
                    'name' => $item['name'],
                ];
            }

            $shippingCost = (int) Setting::get('shipping_cost', 20000);
            $totalAmount += $shippingCost;

            $order->update(['total_amount' => $totalAmount]);

            $params = [
                'transaction_details' => [
                    'order_id' => (string) $order->id,
                    'gross_amount' => (int) $totalAmount,
                ],
                'item_details' => array_merge($items, [
                    [
                        'id' => 'shipping',
                        'price' => $shippingCost,
                        'quantity' => 1,
                        'name' => 'Shipping Cost',
                    ]
                ]),
                'customer_details' => [
                    'first_name' => $request->name,
                    'email' => auth()->user()->email,
                    'phone' => $request->phone,
                    'billing_address' => [
                        'address' => $request->shipping_address
                    ],
                    'shipping_address' => [
                        'address' => $request->shipping_address
                    ]
                ]
            ];

            Log::info('Midtrans parameters prepared', ['params' => $params]);

            $snapToken = Snap::getSnapToken($params);
            if (empty($snapToken)) {
                Log::error('Failed to retrieve Snap Token', ['params' => $params]);
                throw new Exception('Snap Token is empty');
            }

            Log::info('Snap Token generated successfully', [
                'order_id' => $order->id,
                'snap_token' => $snapToken,
            ]);

            $order->update(['snap_token' => $snapToken]);

            DB::commit();

            // Save shipping info back to user profile for next checkout auto-fill
            auth()->user()->update([
                'name'    => $request->name,
                'phone'   => $request->phone,
                'address' => $request->shipping_address,
            ]);

            // Send WhatsApp notification to Admin if enabled
            if (Setting::get('whatsapp_notify_checkout', '1') === '1') {
                $adminPhone = Setting::get('whatsapp_admin_number');
                if (!empty($adminPhone)) {
                    $itemsDetail = "";
                    foreach ($request->cart as $item) {
                        $itemsDetail .= "- " . $item['name'] . " (" . $item['quantity'] . "x) @ Rp " . number_format($item['price'], 0, ',', '.') . "\n";
                    }
                    
                    $msg = "🔔 *PESANAN BARU MASUK!* 🔔\n\n"
                         . "Kode Pesanan: " . $order->order_code . "\n"
                         . "Nama Pemesan: " . $request->name . "\n"
                         . "No. Telepon: " . $request->phone . "\n"
                         . "Alamat Kirim: " . $request->shipping_address . "\n\n"
                         . "*Detail Produk:*\n" . $itemsDetail . "\n"
                         . "Ongkir: Rp " . number_format($shippingCost, 0, ',', '.') . "\n"
                         . "*Total Bayar:* Rp " . number_format($totalAmount, 0, ',', '.') . "\n\n"
                         . "Silakan klik link di bawah ini untuk melihat dan memproses pesanan:\n"
                         . url('/admin/orders') . "\n\n"
                         . "Terima kasih!";
                         
                    WhatsappService::sendMessage($adminPhone, $msg);
                }
            }

            Log::info('Order successfully created', [
                'order_id' => $order->id,
                'user_id' => auth()->id(),
                'total_amount' => $totalAmount,
            ]);

            return response()->json([
                'status' => 'success',
                'snap_token' => $snapToken,
                'order_id' => $order->id,
            ]);
        } catch (Exception $e) {
            DB::rollBack();
            Log::error('Checkout process error: ' . $e->getMessage(), [
                'file' => $e->getFile(),
                'line' => $e->getLine(),
                'user_id' => auth()->id() ?? null,
            ]);

            return response()->json([
                'status' => 'failed',
                'message' => 'Error in payment process: ' . $e->getMessage(),
            ], 442);
        }
    }



    public function updateStatus(Request $request)
    {
        try {
            $request->validate([
                'order_id' => 'required',
                'transaction_id' => 'required',
                'payment_type' => 'required',
                'status' => 'required|in:paid,pending,cancelled',
            ]);
            $order = Order::findOrFail( $request->order_id);

            if($order->user_id !== auth()->id()) {
                throw new Exception('Unauthorized access');

            }

            $order->update([
                'status' => $request->status,
                'midtrans_transaction_id' => $request->transaction_id,
                'midtrans_payment_type' => $request->payment_type
            ]);

            return response()->json([
                'status' => 'success',
                'message' => 'Order status updated successfully',
            ]);
        }catch (Exception $e) {
           Log::error( 'Error updating order status: ' . $e->getMessage());

           return response()->json([
                'status' => 'failed',
                'message' => 'Error updating order status: ' . $e->getMessage(),
           ], 422);
        }
    }

    /**
     * Return authenticated user's saved profile data for checkout auto-fill.
     */
    public function getProfile(): JsonResponse
    {
        if (!auth()->check()) {
            return response()->json(['status' => 'unauthenticated'], 401);
        }

        $user = auth()->user();
        return response()->json([
            'status' => 'success',
            'data' => [
                'name'    => $user->name,
                'phone'   => $user->phone,
                'address' => $user->address,
            ],
        ]);
    }

    /**
     * Process manual payment (COD, E-Wallet, QRIS)
     */
    public function processManual(Request $request): JsonResponse
    {
        try {
            if (!auth()->check()) {
                return response()->json([
                    'status' => 'failed',
                    'message' => 'User not authenticated'
                ], 401);
            }

            $validated = $request->validate([
                'name' => ['required', 'string'],
                'phone' => ['required', 'string'],
                'shipping_address' => ['required', 'string'],
                'notes' => ['nullable', 'string'],
                'cart' => ['required', 'array'],
                'payment_method' => ['required', 'in:cod,ewallet,qris'],
            ]);

            DB::beginTransaction();

            $order = Order::create([
                'user_id' => auth()->id(),
                'shipping_address' => $request->shipping_address,
                'total_amount' => 0,
                'status' => 'pending',
                'notes' => $request->notes,
                'payment_method' => $request->payment_method,
            ]);

            $totalAmount = 0;

            foreach ($request->cart as $item) {
                if (!isset($item['id'], $item['quantity'], $item['price'], $item['name'])) {
                    throw new Exception('Invalid cart item');
                }

                OrderItem::create([
                    'order_id' => $order->id,
                    'product_id' => $item['id'],
                    'quantity' => $item['quantity'],
                    'price' => $item['price'],
                ]);

                $totalAmount += $item['price'] * $item['quantity'];
            }

            $shippingCost = (int) Setting::get('shipping_cost', 20000);
            $totalAmount += $shippingCost;

            // Generate unique code only for non-COD payments
            if ($request->payment_method !== 'cod') {
                $uniqueCode = Order::generateUniqueCode();
                $uniqueAmount = $totalAmount + $uniqueCode;
            } else {
                $uniqueCode = null;
                $uniqueAmount = $totalAmount;
            }

            $order->update([
                'total_amount' => $totalAmount,
                'unique_code' => $uniqueCode,
                'unique_amount' => $uniqueAmount,
                'manual_payment_status' => 'pending_confirmation',
            ]);

            DB::commit();

            // Save shipping info back to user profile
            auth()->user()->update([
                'name'    => $request->name,
                'phone'   => $request->phone,
                'address' => $request->shipping_address,
            ]);

            // Send WhatsApp notification
            if (Setting::get('whatsapp_notify_checkout', '1') === '1') {
                $adminPhone = Setting::get('whatsapp_admin_number');
                if (!empty($adminPhone)) {
                    $paymentMethodLabel = match($request->payment_method) {
                        'cod' => 'Bayar di Tempat (COD)',
                        'ewallet' => 'E-Wallet',
                        'qris' => 'QRIS',
                        default => $request->payment_method,
                    };

                    $itemsDetail = "";
                    foreach ($request->cart as $item) {
                        $itemsDetail .= "- " . $item['name'] . " (" . $item['quantity'] . "x) @ Rp " . number_format($item['price'], 0, ',', '.') . "\n";
                    }

                    $msg = "🔔 *PESANAN BARU MASUK!* 🔔\n\n"
                         . "Kode Pesanan: " . $order->order_code . "\n"
                         . "Nama Pemesan: " . $request->name . "\n"
                         . "No. Telepon: " . $request->phone . "\n"
                         . "Alamat Kirim: " . $request->shipping_address . "\n"
                         . "Metode Bayar: *" . $paymentMethodLabel . "*\n\n"
                         . "*Detail Produk:*\n" . $itemsDetail . "\n"
                         . "Ongkir: Rp " . number_format($shippingCost, 0, ',', '.') . "\n"
                         . "Subtotal: Rp " . number_format($totalAmount, 0, ',', '.') . "\n";

                    if ($uniqueCode) {
                        $msg .= "Kode Unik: " . $uniqueCode . "\n";
                    }

                    $msg .= "*Total Bayar:* Rp " . number_format($uniqueAmount, 0, ',', '.') . "\n\n"
                         . "Silakan klik link di bawah ini untuk melihat dan memproses pesanan:\n"
                         . url('/admin/orders') . "\n\n"
                         . "Terima kasih!";

                    WhatsappService::sendMessage($adminPhone, $msg);
                }
            }

            return response()->json([
                'status' => 'success',
                'order_id' => $order->id,
                'order_code' => $order->order_code,
                'payment_method' => $request->payment_method,
                'total_amount' => $totalAmount,
                'unique_code' => $uniqueCode,
                'unique_amount' => $uniqueAmount,
            ]);
        } catch (Exception $e) {
            DB::rollBack();
            Log::error('Manual payment process error: ' . $e->getMessage(), [
                'file' => $e->getFile(),
                'line' => $e->getLine(),
            ]);

            return response()->json([
                'status' => 'failed',
                'message' => 'Error in payment process: ' . $e->getMessage(),
            ], 422);
        }
    }

    /**
     * Upload payment proof for manual payment
     */
    public function uploadProof(Request $request): JsonResponse
    {
        try {
            $validated = $request->validate([
                'order_id' => ['required', 'exists:orders,id'],
                'payment_proof' => ['required', 'image', 'max:2048'],
            ]);

            $order = Order::findOrFail($request->order_id);

            if ($order->user_id !== auth()->id()) {
                throw new Exception('Unauthorized access');
            }

            if (!$order->isManualPayment()) {
                throw new Exception('This order is not a manual payment order');
            }

            $image = $request->file('payment_proof');
            $imageBase64 = base64_encode(file_get_contents($image->getRealPath()));
            $proof = 'data:' . $image->getMimeType() . ';base64,' . $imageBase64;

            $order->update([
                'payment_proof' => $proof,
                'manual_payment_status' => 'pending_confirmation',
            ]);

            return response()->json([
                'status' => 'success',
                'message' => 'Bukti pembayaran berhasil diunggah',
            ]);
        } catch (Exception $e) {
            Log::error('Error uploading payment proof: ' . $e->getMessage());
            return response()->json([
                'status' => 'failed',
                'message' => 'Gagal mengunggah bukti pembayaran: ' . $e->getMessage(),
            ], 422);
        }
    }
}
