<?php $__env->startSection('title', 'Wishlist Saya'); ?>

<?php $__env->startSection('content'); ?>
    <div class="py-8">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between mb-6">
                <h1 class="text-2xl font-bold text-gray-900">Wishlist Saya</h1>
                <a href="/" class="text-rose-600 hover:text-rose-700 flex items-center gap-2 font-medium text-sm">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/>
                    </svg>
                    Lanjut Belanja
                </a>
            </div>

            <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4">
                <?php $__empty_1 = true; $__currentLoopData = $wishlists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wishlist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php $product = $wishlist->product; ?>
                    <div class="product-card bg-white border border-gray-200 rounded-lg shadow-sm hover:shadow-md transition-all"
                        data-id="<?php echo e($product->id); ?>">
                        <div class="aspect-square overflow-hidden rounded-t-lg relative">
                            <img src="<?php echo e($product->getPrimaryImage()); ?>" alt="<?php echo e($product->name); ?>"
                                class="w-full h-full object-cover hover:scale-105 transition-transform duration-300" />
                            <button onclick="toggleWishlist(<?php echo e($product->id); ?>)"
                                class="absolute top-2 right-2 w-8 h-8 bg-white rounded-full shadow flex items-center justify-center hover:bg-red-50 transition">
                                <svg class="w-5 h-5 text-red-500" fill="currentColor" viewBox="0 0 24 24">
                                    <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
                                </svg>
                            </button>
                        </div>
                        <div class="p-2 sm:p-3">
                            <h3 class="text-xs sm:text-sm font-semibold text-gray-900 line-clamp-1"><?php echo e($product->name); ?></h3>
                            <p class="mt-0.5 text-[10px] sm:text-xs text-gray-500"><?php echo e($product->category->name ?? ''); ?></p>
                            <div class="mt-2 flex items-center justify-between gap-1">
                                <span class="text-rose-600 font-bold text-xs sm:text-sm">Rp <?php echo e(number_format($product->price, 0, ',', '.')); ?></span>
                                <button onclick="addToCart(<?php echo e($product->id); ?>, '<?php echo e(addslashes($product->name)); ?>', <?php echo e($product->price); ?>, '<?php echo e($product->getPrimaryImage()); ?>', '<?php echo e(addslashes($product->category->name ?? '')); ?>')"
                                    class="add-to-cart-btn bg-rose-500 text-white px-2 py-1 text-[10px] sm:text-xs rounded-lg hover:bg-rose-600 transition-colors whitespace-nowrap">
                                    + Keranjang
                                </button>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-span-full text-center py-12">
                        <svg class="w-16 h-16 mx-auto text-gray-300 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"/>
                        </svg>
                        <h3 class="text-lg font-medium text-gray-900 mb-1">Wishlist kosong</h3>
                        <p class="text-gray-500 mb-4">Belum ada produk yang disimpan</p>
                        <a href="/" class="inline-flex px-6 py-2 bg-rose-500 text-white rounded-lg hover:bg-rose-600 transition">
                            Mulai Belanja
                        </a>
                    </div>
                <?php endif; ?>
            </div>

            <div class="mt-6">
                <?php echo e($wishlists->links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    function toggleWishlist(productId) {
        fetch('/wishlist/toggle', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
            },
            body: JSON.stringify({ product_id: productId })
        })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'removed') {
                window.location.reload();
            }
        });
    }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.layouts-landing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /data/data/com.termux/files/home/ecommerce-midtrans/resources/views/user/wishlist.blade.php ENDPATH**/ ?>