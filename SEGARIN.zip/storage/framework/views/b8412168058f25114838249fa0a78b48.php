<?php $__env->startSection('title', 'Konfigurasi Midtrans'); ?>

<?php $__env->startSection('header_title', 'Konfigurasi Midtrans'); ?>
<?php $__env->startSection('header_subtitle', 'Atur kredensial Midtrans Payment Gateway'); ?>

<?php $__env->startSection('content'); ?>
    <div class="max-w-3xl mx-auto space-y-6">

        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        
        <div class="bg-blue-50 border border-blue-200 rounded-xl p-4 flex gap-3">
            <svg class="w-5 h-5 text-blue-500 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
            </svg>
            <div class="text-sm text-blue-700">
                <p class="font-semibold mb-1">Cara mendapatkan kredensial Midtrans:</p>
                <ol class="list-decimal list-inside space-y-1">
                    <li>Login ke <a href="https://dashboard.midtrans.com" target="_blank" class="underline hover:text-blue-900">dashboard.midtrans.com</a></li>
                    <li>Pilih environment <strong>Sandbox</strong> (testing) atau <strong>Production</strong></li>
                    <li>Buka menu <strong>Settings → Access Keys</strong></li>
                    <li>Salin <strong>Merchant ID</strong>, <strong>Client Key</strong>, dan <strong>Server Key</strong></li>
                </ol>
            </div>
        </div>

        
        <div class="bg-white rounded-2xl p-6 shadow-sm">
            <form action="<?php echo e(route('admin.settings.midtrans.store')); ?>" method="POST" class="space-y-6">
                <?php echo csrf_field(); ?>

                
                <div class="border border-gray-200 rounded-xl p-4">
                    <h3 class="text-sm font-semibold text-gray-700 mb-3">Environment</h3>
                    <div class="flex items-center gap-6">
                        <label class="flex items-center gap-2 cursor-pointer">
                            <input type="radio" name="midtrans_is_production" id="env_sandbox" value="0"
                                <?php echo e($isProduction == '0' ? 'checked' : ''); ?>

                                class="accent-rose-500" onchange="updateEnvBadge(this.value)">
                            <span class="text-sm font-medium text-gray-700">Sandbox (Testing)</span>
                        </label>
                        <label class="flex items-center gap-2 cursor-pointer">
                            <input type="radio" name="midtrans_is_production" id="env_production" value="1"
                                <?php echo e($isProduction == '1' ? 'checked' : ''); ?>

                                class="accent-rose-500" onchange="updateEnvBadge(this.value)">
                            <span class="text-sm font-medium text-gray-700">Production (Live)</span>
                        </label>
                    </div>
                    <p id="env_desc" class="mt-2 text-xs <?php echo e($isProduction == '1' ? 'text-green-600' : 'text-amber-600'); ?>">
                        <?php echo e($isProduction == '1' ? '✅ Mode Production aktif — transaksi nyata menggunakan uang sungguhan.' : '⚠️ Mode Sandbox aktif — hanya untuk pengujian, tidak ada uang yang ditransfer.'); ?>

                    </p>
                </div>

                
                <div>
                    <label for="midtrans_merchant_id" class="block text-sm font-medium text-gray-700 mb-1">
                        Merchant ID
                    </label>
                    <input type="text" name="midtrans_merchant_id" id="midtrans_merchant_id"
                        value="<?php echo e(old('midtrans_merchant_id', $merchantId)); ?>"
                        placeholder="Contoh: G123456789"
                        class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-rose-200 focus:border-rose-500 transition font-mono text-sm">
                </div>

                
                <div>
                    <label for="midtrans_client_key" class="block text-sm font-medium text-gray-700 mb-1">
                        Client Key
                        <span class="ml-1 text-xs text-gray-400 font-normal">(digunakan di frontend / JS)</span>
                    </label>
                    <div class="relative">
                        <input type="text" name="midtrans_client_key" id="midtrans_client_key"
                            value="<?php echo e(old('midtrans_client_key', $clientKey)); ?>"
                            placeholder="SB-Mid-client-xxxxxxxxxxxxxxxx"
                            class="w-full px-4 py-2 pr-12 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-rose-200 focus:border-rose-500 transition font-mono text-sm">
                        <button type="button" onclick="toggleVisibility('midtrans_client_key')"
                            class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 transition"
                            title="Tampilkan/Sembunyikan">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
                            </svg>
                        </button>
                    </div>
                </div>

                
                <div>
                    <label for="midtrans_server_key" class="block text-sm font-medium text-gray-700 mb-1">
                        Server Key
                        <span class="ml-1 text-xs text-gray-400 font-normal">(digunakan di backend, jaga kerahasiaannya!)</span>
                    </label>
                    <div class="relative">
                        <input type="password" name="midtrans_server_key" id="midtrans_server_key"
                            value="<?php echo e(old('midtrans_server_key', $serverKey)); ?>"
                            placeholder="SB-Mid-server-xxxxxxxxxxxxxxxx"
                            class="w-full px-4 py-2 pr-12 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-rose-200 focus:border-rose-500 transition font-mono text-sm">
                        <button type="button" onclick="toggleVisibility('midtrans_server_key')"
                            class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 transition"
                            title="Tampilkan/Sembunyikan">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
                            </svg>
                        </button>
                    </div>
                </div>

                
                <div class="bg-gray-50 rounded-lg px-4 py-3 text-xs text-gray-500 flex items-start gap-2">
                    <svg class="w-4 h-4 text-gray-400 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
                    </svg>
                    <span>
                        Snap JS URL yang akan digunakan:
                        <code id="snap_url_preview" class="ml-1 font-mono text-rose-600">
                            <?php echo e($isProduction == '1' ? 'https://app.midtrans.com/snap/snap.js' : 'https://app.sandbox.midtrans.com/snap/snap.js'); ?>

                        </code>
                    </span>
                </div>

                
                <div class="border-t border-gray-100 pt-5 flex justify-end">
                    <button type="submit"
                        class="px-6 py-2.5 bg-rose-500 hover:bg-rose-600 text-white font-medium rounded-lg transition shadow-sm">
                        Simpan Konfigurasi
                    </button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    function toggleVisibility(fieldId) {
        const input = document.getElementById(fieldId);
        input.type = input.type === 'password' ? 'text' : 'password';
    }

    function updateEnvBadge(value) {
        const desc = document.getElementById('env_desc');
        const snapPreview = document.getElementById('snap_url_preview');
        if (value === '1') {
            desc.textContent = '✅ Mode Production aktif — transaksi nyata menggunakan uang sungguhan.';
            desc.className = 'mt-2 text-xs text-green-600';
            snapPreview.textContent = 'https://app.midtrans.com/snap/snap.js';
        } else {
            desc.textContent = '⚠️ Mode Sandbox aktif — hanya untuk pengujian, tidak ada uang yang ditransfer.';
            desc.className = 'mt-2 text-xs text-amber-600';
            snapPreview.textContent = 'https://app.sandbox.midtrans.com/snap/snap.js';
        }
    }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.layout-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /data/data/com.termux/files/home/ecommerce-midtrans/resources/views/admin/midtrans.blade.php ENDPATH**/ ?>