<?php $__env->startSection('title', 'Keranjang Belanja'); ?>

<?php $__env->startSection('content'); ?>
    <div class="py-12">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between mb-8">
                <h1 class="text-2xl font-bold text-gray-900">Keranjang Belanja</h1>
                <a href="/" class="text-rose-600 hover:text-rose-700 flex items-center gap-2 font-medium">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M10 19l-7-7m0 0l7-7m-7 7h18" />
                    </svg>
                    Kembali Belanja
                </a>
            </div>

            <div class="flex flex-col lg:flex-row gap-8">
                <!-- Cart Items -->
                <div class="flex-1">
                    <div class="bg-white rounded-xl shadow-sm overflow-hidden cart-items"
                        data-logged-in="<?php echo e(auth()->check() ? 'true' : 'false'); ?>">
                        <!-- Dynamic cart items will be loaded here -->
                    </div>
                </div>

                <!-- Order Summary -->
                <div class="w-full lg:w-96">
                    <div class="bg-white rounded-xl shadow-sm p-6">
                        <h2 class="text-lg font-medium text-gray-900">Ringkasan Pesanan</h2>

                        <!-- Coupon Input -->
                        <div class="mt-4">
                            <div class="flex gap-2">
                                <input type="text" id="couponCode" placeholder="Kode kupon"
                                    class="flex-1 px-3 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-rose-200 focus:border-rose-500">
                                <button type="button" onclick="applyCoupon()" class="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg text-sm hover:bg-gray-200 transition">
                                    Terapkan
                                </button>
                            </div>
                            <div id="couponMessage" class="text-xs mt-1 hidden"></div>
                            <div id="couponInfo" class="hidden mt-2 p-2 bg-green-50 rounded-lg text-sm text-green-700">
                                <span id="couponCodeDisplay"></span> - <span id="couponDiscount"></span>
                            </div>
                        </div>

                        <dl class="mt-4 space-y-3">
                            <div class="flex items-center justify-between">
                                <dt class="text-sm text-gray-600">Subtotal</dt>
                                <dd class="text-sm font-medium text-gray-900" data-summary="subtotal">Rp 0</dd>
                            </div>
                            <div class="flex items-center justify-between">
                                <dt class="text-sm text-gray-600">Ongkos Kirim</dt>
                                <dd class="text-sm font-medium text-gray-900" data-summary="shipping">Rp 0</dd>
                            </div>
                            <div id="discountRow" class="hidden flex items-center justify-between">
                                <dt class="text-sm text-green-600">Diskon Kupon</dt>
                                <dd class="text-sm font-medium text-green-600" data-summary="discount">- Rp 0</dd>
                            </div>
                            <div class="border-t border-gray-200 pt-3 flex items-center justify-between">
                                <dt class="text-base font-medium text-gray-900">Total</dt>
                                <dd class="text-base font-medium text-gray-900" data-summary="total">Rp 0</dd>
                            </div>
                        </dl>

                        <?php if(auth()->check()): ?>
                            <button data-summary="checkout"
                                class="mt-6 w-full bg-rose-500 text-white py-3 px-4 rounded-lg hover:bg-rose-600 focus:outline-none focus:ring-2 focus:ring-rose-500 focus:ring-offset-2 transition duration-200">
                                Lanjutkan ke Checkout
                            </button>
                            <button id="payButton"
                                class="mt-6 w-full bg-rose-500 text-white py-3 px-4 rounded-lg hover:bg-rose-600 focus:outline-none focus:ring-2 focus:ring-rose-500 focus:ring-offset-2 transition duration-200" hidden>
                                Bayar Sekarang
                            </button>
                        <?php else: ?>
                            <div class="flex flex-col gap-6">
                                <a href="<?php echo e(route('login')); ?>"
                                    class="mt-10 w-full bg-rose-500 text-white py-3 px-4 rounded-lg hover:bg-rose-600 focus:outline-none focus:ring-2 focus:ring-rose-500 focus:ring-offset-2 text-center transition duration-200">
                                    Masuk untuk Checkout
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(config('midtrans.payment_url')); ?>" data-client-key="<?php echo e(config('midtrans.client_key')); ?>"></script>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.layouts-landing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /data/data/com.termux/files/home/ecommerce-midtrans/resources/views/landing/shopping-cart.blade.php ENDPATH**/ ?>