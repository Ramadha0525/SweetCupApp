
<div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4">
    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="product-card bg-white border border-gray-200 rounded-lg shadow-sm hover:shadow-md transition-all"
            data-id="<?php echo e($product->id); ?>"
            data-name="<?php echo e($product->name); ?>"
            data-price="<?php echo e($product->price); ?>"
            data-image="<?php echo e($product->getPrimaryImage()); ?>"
            data-category="<?php echo e($product->category->name); ?>">
            <!-- Product Image -->
            <div class="aspect-square overflow-hidden rounded-t-lg relative">
                <img src="<?php echo e($product->getPrimaryImage()); ?>" alt="<?php echo e($product->name); ?>"
                    class="w-full h-full object-cover hover:scale-105 transition-transform duration-300" />
                <?php if(auth()->guard()->check()): ?>
                    <button onclick="event.stopPropagation(); toggleWishlist(<?php echo e($product->id); ?>)"
                        class="absolute top-2 right-2 w-7 h-7 bg-white rounded-full shadow flex items-center justify-center hover:bg-red-50 transition z-10">
                        <svg class="w-4 h-4 <?php echo e($product->isWishlistedBy(auth()->user()) ? 'text-red-500 fill-red-500' : 'text-gray-400'); ?>" fill="<?php echo e($product->isWishlistedBy(auth()->user()) ? 'currentColor' : 'none'); ?>" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"/>
                        </svg>
                    </button>
                <?php endif; ?>
            </div>
            <!-- Product Info -->
            <div class="p-2 sm:p-3">
                <h3 class="text-xs sm:text-sm font-semibold text-gray-900 line-clamp-1"><?php echo e($product->name); ?></h3>
                <p class="mt-0.5 text-[10px] sm:text-xs text-gray-500 line-clamp-1"><?php echo e(Str::limit($product->description, 30)); ?></p>
                <?php if($product->reviews_count > 0): ?>
                    <div class="flex items-center gap-1 mt-1">
                        <div class="flex text-yellow-400 text-[10px]">
                            <?php for($i = 1; $i <= 5; $i++): ?>
                                <?php if($i <= $product->average_rating): ?>
                                    ★
                                <?php else: ?>
                                    ☆
                                <?php endif; ?>
                            <?php endfor; ?>
                        </div>
                        <span class="text-[10px] text-gray-400">(<?php echo e($product->reviews_count); ?>)</span>
                    </div>
                <?php endif; ?>
                <div class="mt-2 flex items-center justify-between gap-1">
                    <span class="text-rose-600 font-bold text-xs sm:text-sm">Rp <?php echo e(number_format($product->price, 0, ',', '.')); ?></span>
                    <button
                        class="add-to-cart-btn bg-rose-500 text-white px-2 py-1 sm:px-3 sm:py-1.5 text-[10px] sm:text-xs rounded-lg hover:bg-rose-600 transition-colors whitespace-nowrap">
                        + Keranjang
                    </button>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <!-- No Results -->
        <div id="noResults" class="col-span-full text-center py-8">
            <h3 class="text-sm font-medium text-gray-900">No products found</h3>
            <p class="mt-1 text-xs text-gray-500">Try adjusting your search terms or filters.</p>
        </div>
    <?php endif; ?>
</div>


<?php if($products->hasPages()): ?>
    <div class="mt-6">
        <nav class="justify-center flex-wrap gap-2" id="pagination-links">
            <?php echo e($products->links()); ?>

        </nav>
    </div>
<?php endif; ?>
<?php /**PATH /home/u70inskj/public_html/resources/views/partials/product-user.blade.php ENDPATH**/ ?>