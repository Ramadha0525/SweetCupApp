<?php $__env->startSection('title', 'Order'); ?>

<?php $__env->startSection('header_title', 'Order'); ?>
<?php $__env->startSection('header_subtitle', 'Manage your order'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <!-- Header Section -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="h3">Order List</h1>
        </div>

        <!-- Order Table -->
        <div class="card shadow">
            <div class="card-body">
                <div class="table-responsive">
                    
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <form action="<?php echo e(route('admin.orders.index')); ?>" method="GET"
                            class="d-flex align-items-center gap-2">

                            <div class="input-group">
                                <input type="text" name="search" class="form-control form-control-sm"
                                    placeholder="Search orders ID..." value="<?php echo e(request('search')); ?>">
                                <select name="status" class="form-select form-select-sm" id="">
                                    <option value="">All Status</option>
                                    <?php $__currentLoopData = ['processing', 'shipped']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($status); ?>"
                                            <?php echo e(request('status') == $status ? 'selected' : ''); ?>>
                                            <?php echo e(ucfirst($status)); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <button type="submit" class="btn btn-sm btn-outline-secondary">
                                    <i class="bi bi-search"></i>
                                </button>
                            </div>
                            <?php if(request('search') || request('status')): ?>
                                <a href="<?php echo e(route('admin.orders.index')); ?>" class="btn btn-sm btn-outline-secondary">
                                    <i class="bi bi-x-circle me-1"></i>
                                </a>
                            <?php endif; ?>
                        </form>
                    </div>

                    
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Order Code</th>
                                <th>Customer</th>
                                <th>Total Amount</th>
                                <th>Status</th>
                                <th>Payment Method</th>
                                <th>Unique Code</th>
                                <th>Created At</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($order->order_code); ?></td>
                                    <td><?php echo e($order->user->name ?? 'N/A'); ?></td>
                                    <td>
                                        <?php if($order->unique_amount): ?>
                                            <div>Rp <?php echo e(number_format($order->unique_amount, 0, ',', '.')); ?></div>
                                            <small class="text-muted">+<?php echo e($order->unique_code); ?> kode unik</small>
                                        <?php else: ?>
                                            Rp <?php echo e(number_format($order->total_amount, 0, ',', '.')); ?>

                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php
                                            $statusLabel = [
                                                'pending' => 'Menunggu Pembayaran',
                                                'paid' => 'Lunas',
                                                'processing' => 'Diproses',
                                                'shipped' => 'Dikirim',
                                                'delivered' => 'Diterima',
                                                'cancelled' => 'Dibatalkan',
                                            ][$order->status] ?? ucfirst($order->status);
                                        ?>
                                        <span class="badge bg-<?php echo e($order->status_color); ?>">
                                            <?php echo e($statusLabel); ?>

                                        </span>
                                        <?php if($order->isManualPayment() && $order->manual_payment_status): ?>
                                            <br>
                                            <span class="badge bg-<?php echo e($order->manual_payment_status === 'confirmed' ? 'success' : ($order->manual_payment_status === 'rejected' ? 'danger' : 'warning')); ?> mt-1">
                                                <?php echo e($order->manual_payment_status === 'confirmed' ? '✓ Dikonfirmasi' : ($order->manual_payment_status === 'rejected' ? '✗ Ditolak' : 'Menunggu Konfirmasi')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($order->payment_method): ?>
                                            <?php echo e($order->payment_method_label); ?>

                                        <?php else: ?>
                                            <?php echo e($order->midtrans_payment_type ?? '-'); ?>

                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($order->unique_code ?? '-'); ?></td>
                                    <td><?php echo e($order->created_at->format('d M Y')); ?></td>
                                    <td>
                                        <button type="button" class="btn btn-sm btn-info" data-bs-toggle="modal"
                                            data-bs-target="#orderDetailModal<?php echo e($order->id); ?>">
                                            <i class="bi bi-eye"></i>
                                        </button>
                                        <button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal"
                                            data-bs-target="#UpdateStatusModal<?php echo e($order->id); ?>"
                                            <?php if(empty($order->getNextPossibleStatuses())): ?> disabled <?php endif; ?>>
                                            <i class="bi bi-pencil"></i>
                                        </button>
                                        <?php if($order->isManualPayment() && $order->manual_payment_status === 'pending_confirmation'): ?>
                                            <button type="button" class="btn btn-sm btn-success" data-bs-toggle="modal"
                                                data-bs-target="#ConfirmPaymentModal<?php echo e($order->id); ?>">
                                                <i class="bi bi-check-circle"></i>
                                            </button>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php if($orders->isEmpty()): ?>
                                <tr>
                                    <td colspan="8" class="text-center py-4">
                                        <div class="d-flex flex-column align-items-center">
                                            <i class="bi bi-inbox display-4 text-muted mb-2"></i>
                                            <p class="text-muted mb-0">No Order Found</p>
                                        </div>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    
                    <div class="mt-4">
                        <?php echo e($orders->links()); ?>

                    </div>
                </div>
            </div>
        </div>

        
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <div class="modal fade" id="orderDetailModal<?php echo e($order->id); ?>" tabindex="-1"
                aria-labelledby="orderDetailModalLabel<?php echo e($order->id); ?>">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title fw-bold" id="orderDetailModallabel<?php echo e($order->id); ?>">
                                <i class="bi bi-box-seam me-2"></i>Order #<?php echo e($order->id); ?>

                            </h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="row gap-4">
                                
                                <div class="col-12">
                                    <div class="card border-0 bg-light">
                                        <div class="card-body p-4">
                                            <div class="d-flex justify-content-between align-items-center mb-3">
                                                <div>
                                                    <p class="text-muted mb-1">Order Status</p>
                                                    <h4 class="mb-0">
                                                        <?php
                                                            $detailStatusLabel = [
                                                                'pending' => 'Menunggu Pembayaran',
                                                                'paid' => 'Lunas',
                                                                'processing' => 'Diproses',
                                                                'shipped' => 'Dikirim',
                                                                'delivered' => 'Diterima',
                                                                'cancelled' => 'Dibatalkan',
                                                            ][$order->status] ?? ucfirst($order->status);
                                                        ?>
                                                        <span class="badge bg-<?php echo e($order->status_color); ?>">
                                                            <?php echo e($detailStatusLabel); ?>

                                                        </span>
                                                    </h4>
                                                </div>
                                                <div class="text-end">
                                                    <p class="text-muted mb-1">Order Date</p>
                                                    <h6 class="mb-0"><?php echo e($order->created_at->format('d M Y')); ?></h6>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                
                                <div class="col-md-6">
                                    <div class="card h-100 border-0 shadow-sm">
                                        <div class="card-body">
                                            <h6 class="card-title mb-3">
                                                <i class="bi bi-person me-2"></i>Customer Information
                                            </h6>
                                            <div class="mb-2">
                                                <label class="text-muted small">Name</label>
                                                <p class="mb-0"><?php echo e($order->user->name ?? 'N/A'); ?></p>
                                            </div>
                                            <div class="mb-2">
                                                <label class="text-muted small">Email</label>
                                                <p class="mb-0"><?php echo e($order->user->email ?? 'N/A'); ?></p>
                                            </div>
                                            <div class="mb-0">
                                                <label class="text-muted small">Phone</label>
                                                <p class="mb-0"><?php echo e($order->user->phone ?? 'N/A'); ?></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                
                                <div class="col-md-6">
                                    <div class="card h-100 border-0 shadow-sm">
                                        <div class="card-body">
                                            <h6 class="card-title mb-3">
                                                <i class="bi bi-truck me-2"></i>Shipping Information
                                            </h6>
                                            <div class="mb-2">
                                                <label class="text-muted small">Address</label>
                                                <p class="mb-1 fw-medium"><?php echo e($order->shipping_address ?? 'N/A'); ?></p>
                                            </div>
                                            <?php if($order->resi_code): ?>
                                                <div class="mb-0">
                                                    <label class="text-muted small">Tracking Number</label>
                                                    <p class="mb-1 fw-medium"><?php echo e($order->resi_code); ?></p>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                
                                <div class="col-12">
                                    <div class="card border-0 shadow-sm">
                                        <div class="card-body">
                                            <h6 class="card-title mb-3">
                                                <i class="bi bi-credit-card me-2"></i>Payment Information
                                            </h6>
                                            <div class="row gap-3">
                                                <?php if($order->payment_method): ?>
                                                    <div class="col-md-4">
                                                        <label class="text-muted small">Payment Method</label>
                                                        <p class="mb-1 fw-medium">
                                                            <?php echo e($order->payment_method_label); ?>

                                                        </p>
                                                    </div>
                                                    <?php if($order->unique_code): ?>
                                                        <div class="col-md-4">
                                                            <label class="text-muted small">Unique Code</label>
                                                            <p class="mb-1 fw-medium">
                                                                +<?php echo e($order->unique_code); ?>

                                                            </p>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <label class="text-muted small">Total (with unique code)</label>
                                                            <p class="mb-1 fw-medium text-success">
                                                                Rp <?php echo e(number_format($order->unique_amount, 0, ',', '.')); ?>

                                                            </p>
                                                        </div>
                                                    <?php endif; ?>
                                                    <?php if($order->ewallet_number): ?>
                                                        <div class="col-md-4">
                                                            <label class="text-muted small">E-Wallet Number</label>
                                                            <p class="mb-1 fw-medium">
                                                                <?php echo e($order->ewallet_number); ?>

                                                            </p>
                                                        </div>
                                                    <?php endif; ?>
                                                <?php elseif($order->midtrans_transaction_id): ?>
                                                    <div class="col-md-4">
                                                        <label class="text-muted small">Transaction ID</label>
                                                        <p class="mb-1 fw-medium">
                                                            <?php echo e($order->midtrans_transaction_id); ?>

                                                        </p>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <label class="text-muted small">Payment Type</label>
                                                        <p class="mb-1 fw-medium">
                                                            <?php echo e(ucwords(str_replace('_', ' ', $order->midtrans_payment_type))); ?>

                                                        </p>
                                                    </div>
                                                <?php endif; ?>
                                            </div>

                                            
                                            <?php if($order->isManualPayment() && $order->payment_proof): ?>
                                                <div class="mt-4">
                                                    <label class="text-muted small">Bukti Pembayaran</label>
                                                    <div class="mt-2">
                                                        <img src="<?php echo e($order->payment_proof); ?>" alt="Payment Proof" class="img-fluid rounded" style="max-width: 300px;">
                                                    </div>
                                                </div>
                                            <?php endif; ?>

                                            
                                            <?php if($order->isManualPayment()): ?>
                                                <div class="mt-4">
                                                    <label class="text-muted small">Status Konfirmasi</label>
                                                    <p class="mb-0">
                                                        <?php if($order->manual_payment_status === 'confirmed'): ?>
                                                            <span class="badge bg-success">✓ Dikonfirmasi</span>
                                                        <?php elseif($order->manual_payment_status === 'rejected'): ?>
                                                            <span class="badge bg-danger">✗ Ditolak</span>
                                                        <?php else: ?>
                                                            <span class="badge bg-warning">Menunggu Konfirmasi</span>
                                                        <?php endif; ?>
                                                    </p>
                                                    <?php if($order->manual_payment_note): ?>
                                                        <p class="mt-2 text-muted small"><i>Catatan: <?php echo e($order->manual_payment_note); ?></i></p>
                                                    <?php endif; ?>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                
                                <div class="col-12">
                                    <div class="card border-0 shadow-sm">
                                        <div class="card-body">
                                            <h6 class="card-title mb-3">
                                                <i class="bi bi-box me-2"></i>Order Items
                                            </h6>
                                            <div class="table-responsive">
                                                <table class="table table-borderless align-middle">
                                                    <thead class="bg-light">
                                                        <tr>
                                                            <th>Product</th>
                                                            <th class="text-end">Price</th>
                                                            <th class="text-end">Quantity</th>
                                                            <th class="text-end">SubTotal</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                                <td><?php echo e($item->product->name); ?></td>
                                                                <td class="text-end">Rp
                                                                    <?php echo e(number_format($item->product->price, 0, ',', '.')); ?>

                                                                </td>
                                                                <td class="text-end"><?php echo e($item->quantity); ?></td>
                                                                <td class="text-end">Rp
                                                                    <?php echo e(number_format($item->product->price * $item->quantity, 0, ',', '.')); ?>

                                                                </td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                    <tfoot class="border-top">
                                                        <tr>
                                                            <td colspan="3" class="text-end fw-medium">Total</td>
                                                            <td class="text-end fw-medium">Rp
                                                                <?php echo e(number_format($order->total_amount, 0, ',', '.')); ?></td>
                                                        </tr>
                                                    </tfoot>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer border-0 pt-8">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>


            
            <div class="modal fade" id="UpdateStatusModal<?php echo e($order->id); ?>" tabindex="-1">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <form action="<?php echo e(route('admin.orders.updateStatus', $order)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <div class="modal-header">
                                <h5 class="modal-title">Update Status Pesanan #<?php echo e($order->order_code); ?></h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                            <div class="modal-body">
                                <div class="mb-3">
                                    <label class="form-label">Status Saat Ini</label>
                                    <div>
                                        <?php
                                            $currentStatusLabel = [
                                                'pending' => 'Menunggu Pembayaran',
                                                'paid' => 'Lunas',
                                                'processing' => 'Diproses',
                                                'shipped' => 'Dikirim',
                                                'delivered' => 'Diterima',
                                                'cancelled' => 'Dibatalkan',
                                            ][$order->status] ?? ucfirst($order->status);
                                        ?>
                                        <span class="badge bg-<?php echo e($order->status_color); ?>"><?php echo e($currentStatusLabel); ?></span>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Ubah Status</label>
                                    <select name="status" class="form-select status-select" required>
                                        <option value="">Pilih Status</option>
                                        <?php
                                            $statusLabels = [
                                                'pending' => 'Menunggu Pembayaran',
                                                'paid' => 'Lunas',
                                                'processing' => 'Diproses',
                                                'shipped' => 'Dikirim',
                                                'delivered' => 'Diterima',
                                                'cancelled' => 'Dibatalkan',
                                            ];
                                        ?>
                                        <?php $__currentLoopData = $order->getNextPossibleStatuses(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($status); ?>"
                                                <?php if($status == 'cancelled'): ?> class="text-danger" <?php endif; ?>>
                                                <?php echo e($statusLabels[$status] ?? ucfirst($status)); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php if(empty($order->getNextPossibleStatuses())): ?>
                                        <small class="text-muted">Tidak ada perubahan status tersedia</small>
                                    <?php endif; ?>
                                </div>
                                <div class="mb-3" id="resiField<?php echo e($order->id); ?>" style="display: none">
                                    <label class="form-label">Nomor Resi</label>
                                    <input type="text" name="resi_code" class="form-control"
                                        placeholder="Masukkan nomor resi">
                                    <div class="form-text">Wajib diisi saat status dikirim</div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                                <?php if(!empty($order->getNextPossibleStatuses())): ?>
                                    <button type="submit" class="btn btn-primary">Update Status</button>
                                <?php endif; ?>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            
            <?php if($order->isManualPayment() && $order->manual_payment_status === 'pending_confirmation'): ?>
                <div class="modal fade" id="ConfirmPaymentModal<?php echo e($order->id); ?>" tabindex="-1">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <form action="<?php echo e(route('admin.orders.confirmPayment', $order)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="modal-header">
                                    <h5 class="modal-title">Konfirmasi Pembayaran #<?php echo e($order->order_code); ?></h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                    <div class="mb-3">
                                        <p><strong>Total yang harus dibayar:</strong></p>
                                        <h4 class="text-success">Rp <?php echo e(number_format($order->unique_amount, 0, ',', '.')); ?></h4>
                                        <small class="text-muted">(Rp <?php echo e(number_format($order->total_amount, 0, ',', '.')); ?> + <?php echo e($order->unique_code); ?> kode unik)</small>
                                    </div>

                                    <?php if($order->payment_proof): ?>
                                        <div class="mb-3">
                                            <p><strong>Bukti Pembayaran:</strong></p>
                                            <img src="<?php echo e($order->payment_proof); ?>" alt="Payment Proof" class="img-fluid rounded" style="max-width: 100%;">
                                        </div>
                                    <?php else: ?>
                                        <div class="alert alert-warning">
                                            <i class="bi bi-exclamation-triangle me-2"></i>
                                            Belum ada bukti pembayaran yang diunggah
                                        </div>
                                    <?php endif; ?>

                                    <div class="mb-3">
                                        <label class="form-label">Status Konfirmasi</label>
                                        <select name="status" class="form-select" required>
                                            <option value="confirmed">✓ Konfirmasi Pembayaran</option>
                                            <option value="rejected">✗ Tolak Pembayaran</option>
                                        </select>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Catatan (Opsional)</label>
                                        <textarea name="note" class="form-control" rows="3"
                                            placeholder="Catatan untuk pelanggan..."></textarea>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                    <button type="submit" class="btn btn-primary">Simpan</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        <?php if(session('success')): ?>
            Swal.fire({
                icon: 'success',
                title: 'Success!',
                text: "<?php echo e(session('success')); ?>",
                showConfirmButton: false,
                timer: 3000,
                toast: true,
                position: 'top-end'
            });
        <?php endif; ?>

        // Show error message
        <?php if(session('error')): ?>
            Swal.fire({
                icon: 'error',
                title: 'Error!',
                text: "<?php echo e(session('error')); ?>",
                showConfirmButton: true
            });
        <?php endif; ?>
        document.querySelectorAll('select[name="status"]').forEach(select => {
            select.addEventListener('change', function() {
                const modal = this.closest('.modal');
                const resiField = modal.querySelector('[id^=resiField]');
                const resiInput = resiField.querySelector('input');

                if (this.value === 'shipped') {
                    resiField.style.display = 'block';
                    resiInput.required = true;
                } else {
                    resiField.style.display = 'none';
                    resiInput.required = false;
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.layout-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /data/data/com.termux/files/home/ecommerce-midtrans/resources/views/admin/order.blade.php ENDPATH**/ ?>