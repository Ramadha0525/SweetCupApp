<footer class="bg-white border-top py-3">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <span class="text-muted">&copy; <?php echo e(date('Y')); ?></span>
            </div>
            <div>
                <span class="text-muted"></span>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH /home/u70inskj/public_html/resources/views/partials/footer.blade.php ENDPATH**/ ?>