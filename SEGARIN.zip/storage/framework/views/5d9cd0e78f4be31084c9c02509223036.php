<?php $__env->startSection('title', $webSettings['store_name'] . ' - Toko Es Cup & Jajanan Siap Antar'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Hero Section -->
    <div id="hero-section" class="relative overflow-hidden bg-white py-16">
        <div class="max-w-7xl mx-auto">
            <div class="relative z-10 pb-8 bg-white sm:pb-16 md:pb-20 lg:pb-28 lg:w-full">
                <main class="mt-10 mx-auto max-w-7xl px-4 sm:mt-12 sm:px-6 md:mt-16 lg:mt-20 lg:px-8">
                    <div class="text-center">
                        <h1 class="text-4xl tracking-tight font-extrabold text-gray-900 sm:text-5xl md:text-6xl">
                            <span class="block">Nikmati Kelembutan</span>
                            <span class="block" style="color: <?php echo e($webSettings['theme_primary']); ?>">Es Krim Cup & Jajanan Hangat</span>
                        </h1>
                        <p class="mt-3 text-base text-gray-500 sm:mt-5 sm:text-lg sm:max-w-xl sm:mx-auto md:mt-5 md:text-xl">
                            <?php echo e($webSettings['store_description'] ?: 'Tersedia aneka rasa es krim cup lembut premium, es tradisional segar, serta camilan gurih hangat siap antar ke rumah Anda.'); ?>

                        </p>
                        <div class="mt-5 sm:mt-8 flex justify-center">
                            <div class="rounded-md shadow">
                                <a href="#featured-products"
                                    class="w-full flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-white hover:opacity-90 md:py-4 md:text-lg md:px-10 transition duration-200"
                                    style="background-color: <?php echo e($webSettings['theme_primary']); ?>">
                                    Pesan Sekarang
                                </a>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
        </div>
    </div>

    <!-- Products Section -->
    <div id="featured-products" class="products-section bg-gray-50 py-8">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <!-- Category Icons -->
            <div class="mb-6">
                <h2 class="text-lg font-bold text-gray-900 mb-4">Menu Pilihan Kami</h2>
                <div class="flex gap-3 overflow-x-auto pb-2 scrollbar-hide">
                    <a href="<?php echo e(route('home')); ?>"
                        class="flex-shrink-0 flex flex-col items-center gap-1.5 px-4 py-3 rounded-xl transition-all <?php echo e(!request('category') ? 'bg-rose-500 text-white shadow-md' : 'bg-white text-gray-600 hover:bg-rose-50 border border-gray-100'); ?>">
                        <span class="text-2xl">✨</span>
                        <span class="text-[11px] font-medium whitespace-nowrap">Semua</span>
                    </a>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('home', ['category' => $category->id])); ?>"
                            class="flex-shrink-0 flex flex-col items-center gap-1.5 px-4 py-3 rounded-xl transition-all <?php echo e(request('category') == $category->id ? 'bg-rose-500 text-white shadow-md' : 'bg-white text-gray-600 hover:bg-rose-50 border border-gray-100'); ?>">
                            <span class="text-2xl"><?php echo e($category->icon ?? '🍽️'); ?></span>
                            <span class="text-[11px] font-medium whitespace-nowrap"><?php echo e(Str::limit($category->name, 15)); ?></span>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <!-- Search & Sort -->
            <form id="filter-form" action="<?php echo e(route('home')); ?>" method="GET" class="mb-6">
                <?php if(request('category')): ?>
                    <input type="hidden" name="category" value="<?php echo e(request('category')); ?>">
                <?php endif; ?>
                <div class="flex gap-2 items-center">
                    <div class="flex-1 relative">
                        <svg class="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
                        </svg>
                        <input type="text" name="search" value="<?php echo e(request('search')); ?>"
                            placeholder="Cari menu..."
                            class="w-full pl-10 pr-4 py-2.5 bg-white border border-gray-200 rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-rose-200 focus:border-rose-400" />
                    </div>
                    <div class="relative">
                        <select name="sort"
                            class="appearance-none bg-white border border-gray-200 rounded-full px-4 py-2.5 pr-8 text-sm focus:outline-none focus:ring-2 focus:ring-rose-200 focus:border-rose-400 cursor-pointer">
                            <option value="newest" <?php echo e(request('sort') == 'newest' ? 'selected' : ''); ?>>Terbaru</option>
                            <option value="price_low" <?php echo e(request('sort') == 'price_low' ? 'selected' : ''); ?>>Harga Terendah</option>
                            <option value="price_high" <?php echo e(request('sort') == 'price_high' ? 'selected' : ''); ?>>Harga Tertinggi</option>
                        </select>
                        <svg class="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/>
                        </svg>
                    </div>
                </div>
            </form>

            <!-- Products Grid -->
            <div id="products-container">
                <?php echo $__env->make('partials.product-user', ['products' => $products], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>

    <!-- Newsletter Section -->
    <div id="newsletter-section" class="bg-rose-50 py-12">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center">
                <h2 class="text-2xl font-bold text-gray-900 mb-4">Dapatkan Promo Menarik</h2>
                <p class="text-gray-600 mb-6">Berlangganan newsletter kami untuk info promo es cup & diskon khusus jajanan setiap minggu.</p>
                <form id="newsletter-form" class="max-w-md mx-auto">
                    <?php echo csrf_field(); ?>
                    <div class="flex gap-4">
                        <input type="email" name="email" placeholder="Masukkan alamat email Anda"
                            class="flex-1 px-4 py-2 rounded-lg border border-gray-200 focus:border-rose-500 focus:ring-2 focus:ring-rose-200">
                        <button type="submit"
                            class="px-6 py-2 bg-rose-500 text-white rounded-lg hover:bg-rose-600 transition-colors">
                            Langganan
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layouts-landing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /data/data/com.termux/files/home/ecommerce-midtrans/resources/views/landing/landing-page.blade.php ENDPATH**/ ?>