<?php $__env->startSection('title', 'Kupon'); ?>

<?php $__env->startSection('header_title', 'Kupon'); ?>
<?php $__env->startSection('header_subtitle', 'Kelola kupon diskon'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h4 class="mb-1 fw-bold">Daftar Kupon</h4>
                <p class="text-muted small mb-0">Total: <?php echo e($coupons->total()); ?> kupon</p>
            </div>
            <button type="button" class="btn btn-rose" data-bs-toggle="modal" data-bs-target="#addCouponModal">
                <i class="bi bi-plus-lg me-1"></i> Tambah Kupon
            </button>
        </div>

        <div class="card border-0 shadow-sm">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="bg-light">
                            <tr>
                                <th class="ps-3">Kode</th>
                                <th>Tipe</th>
                                <th class="text-end">Nilai</th>
                                <th class="text-end">Min. Belanja</th>
                                <th class="text-center">Terpakai</th>
                                <th class="text-center">Status</th>
                                <th class="text-center pe-3" style="width: 100px;">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="ps-3">
                                        <span class="badge bg-rose-100 text-rose-700 font-monospace"><?php echo e($coupon->code); ?></span>
                                    </td>
                                    <td>
                                        <span class="badge <?php echo e($coupon->type === 'percentage' ? 'bg-blue-100 text-blue-700' : 'bg-green-100 text-green-700'); ?>">
                                            <?php echo e($coupon->type === 'percentage' ? 'Persen' : 'Nominal'); ?>

                                        </span>
                                    </td>
                                    <td class="text-end fw-medium">
                                        <?php echo e($coupon->type === 'percentage' ? $coupon->value . '%' : 'Rp ' . number_format($coupon->value, 0, ',', '.')); ?>

                                    </td>
                                    <td class="text-end">
                                        Rp <?php echo e(number_format($coupon->min_purchase, 0, ',', '.')); ?>

                                    </td>
                                    <td class="text-center">
                                        <?php echo e($coupon->used_count); ?>/<?php echo e($coupon->usage_limit ?? '∞'); ?>

                                    </td>
                                    <td class="text-center">
                                        <?php if($coupon->isValid()): ?>
                                            <span class="badge bg-success-subtle text-success">Aktif</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger-subtle text-danger">Nonaktif</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center pe-3">
                                        <div class="btn-group btn-group-sm">
                                            <button type="button" class="btn btn-outline-primary" data-bs-toggle="modal"
                                                data-bs-target="#editCouponModal<?php echo e($coupon->id); ?>">
                                                <i class="bi bi-pencil"></i>
                                            </button>
                                            <form action="<?php echo e(route('admin.coupons.destroy', $coupon)); ?>" method="POST" class="d-inline delete-form">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-outline-danger">
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="7" class="text-center py-5">
                                        <div class="mb-3">
                                            <i class="bi bi-ticket-perforated display-4 text-muted"></i>
                                        </div>
                                        <h5 class="text-muted">Belum ada kupon</h5>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="mt-4 d-flex justify-content-center">
            <?php echo e($coupons->links()); ?>

        </div>

        <!-- Add Coupon Modal -->
        <div class="modal fade" id="addCouponModal" tabindex="-1">
            <div class="modal-dialog">
                <div class="modal-content border-0 shadow">
                    <form action="<?php echo e(route('admin.coupons.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="modal-header border-0 pb-0">
                            <h5 class="modal-title fw-bold">
                                <i class="bi bi-plus-circle text-rose me-2"></i>Tambah Kupon
                            </h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="row g-3">
                                <div class="col-12">
                                    <label class="form-label fw-medium">Kode Kupon <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" name="code" required placeholder="Contoh: DISKON20" style="text-transform: uppercase;">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-medium">Tipe <span class="text-danger">*</span></label>
                                    <select class="form-select" name="type" required>
                                        <option value="percentage">Persen (%)</option>
                                        <option value="fixed">Nominal (Rp)</option>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-medium">Nilai <span class="text-danger">*</span></label>
                                    <input type="number" class="form-control" name="value" required min="0">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-medium">Min. Belanja</label>
                                    <input type="number" class="form-control" name="min_purchase" value="0" min="0">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-medium">Maks. Diskon</label>
                                    <input type="number" class="form-control" name="max_discount" min="0">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-medium">Batas Penggunaan</label>
                                    <input type="number" class="form-control" name="usage_limit" min="1">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-medium">Berlaku Hingga</label>
                                    <input type="datetime-local" class="form-control" name="expires_at">
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer border-0 pt-0">
                            <button type="button" class="btn btn-light" data-bs-dismiss="modal">Batal</button>
                            <button type="submit" class="btn btn-rose">
                                <i class="bi bi-check-lg me-1"></i>Simpan
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Edit Coupon Modals -->
        <?php $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="modal fade" id="editCouponModal<?php echo e($coupon->id); ?>" tabindex="-1">
                <div class="modal-dialog">
                    <div class="modal-content border-0 shadow">
                        <form action="<?php echo e(route('admin.coupons.update', $coupon)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="modal-header border-0 pb-0">
                                <h5 class="modal-title fw-bold">
                                    <i class="bi bi-pencil text-primary me-2"></i>Edit Kupon
                                </h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                            <div class="modal-body">
                                <div class="row g-3">
                                    <div class="col-12">
                                        <label class="form-label fw-medium">Kode Kupon <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" name="code" value="<?php echo e($coupon->code); ?>" required style="text-transform: uppercase;">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label fw-medium">Tipe <span class="text-danger">*</span></label>
                                        <select class="form-select" name="type" required>
                                            <option value="percentage" <?php echo e($coupon->type === 'percentage' ? 'selected' : ''); ?>>Persen (%)</option>
                                            <option value="fixed" <?php echo e($coupon->type === 'fixed' ? 'selected' : ''); ?>>Nominal (Rp)</option>
                                        </select>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label fw-medium">Nilai <span class="text-danger">*</span></label>
                                        <input type="number" class="form-control" name="value" value="<?php echo e($coupon->value); ?>" required min="0">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label fw-medium">Min. Belanja</label>
                                        <input type="number" class="form-control" name="min_purchase" value="<?php echo e($coupon->min_purchase); ?>" min="0">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label fw-medium">Maks. Diskon</label>
                                        <input type="number" class="form-control" name="max_discount" value="<?php echo e($coupon->max_discount); ?>" min="0">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label fw-medium">Batas Penggunaan</label>
                                        <input type="number" class="form-control" name="usage_limit" value="<?php echo e($coupon->usage_limit); ?>" min="1">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label fw-medium">Berlaku Hingga</label>
                                        <input type="datetime-local" class="form-control" name="expires_at" value="<?php echo e($coupon->expires_at ? $coupon->expires_at->format('Y-m-d\TH:i') : ''); ?>">
                                    </div>
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" class="form-check-input" name="is_active" value="1" <?php echo e($coupon->is_active ? 'checked' : ''); ?>>
                                            <label class="form-check-label">Aktif</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer border-0 pt-0">
                                <button type="button" class="btn btn-light" data-bs-dismiss="modal">Batal</button>
                                <button type="submit" class="btn btn-rose">
                                    <i class="bi bi-check-lg me-1"></i>Update
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <style>
        .btn-rose {
            background-color: #f43f5e;
            border-color: #f43f5e;
            color: white;
        }
        .btn-rose:hover {
            background-color: #e11d48;
            border-color: #e11d48;
            color: white;
        }
        .bg-success-subtle {
            background-color: #d1e7dd !important;
        }
        .bg-danger-subtle {
            background-color: #f8d7da !important;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        <?php if(session('success')): ?>
            Swal.fire({
                icon: 'success',
                title: 'Berhasil!',
                text: "<?php echo e(session('success')); ?>",
                showConfirmButton: false,
                timer: 2000,
                toast: true,
                position: 'top-end'
            });
        <?php endif; ?>

        document.querySelectorAll('.delete-form').forEach(form => {
            form.addEventListener('submit', function(e) {
                e.preventDefault();
                Swal.fire({
                    title: 'Hapus kupon?',
                    text: "Kupon yang dihapus tidak dapat dikembalikan!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#f43f5e',
                    cancelButtonColor: '#6c757d',
                    confirmButtonText: 'Ya, hapus!',
                    cancelButtonText: 'Batal'
                }).then((result) => {
                    if (result.isConfirmed) {
                        this.submit();
                    }
                });
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.layout-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /data/data/com.termux/files/home/ecommerce-midtrans/resources/views/admin/coupon.blade.php ENDPATH**/ ?>