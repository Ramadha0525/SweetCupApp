-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Waktu pembuatan: 16 Jul 2026 pada 20.50
-- Versi server: 10.11.15-MariaDB-log
-- Versi PHP: 8.3.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `u70inskj_campur`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `cache`
--

CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `cache_locks`
--

CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `icon` varchar(10) DEFAULT NULL,
  `slug` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `categories`
--

INSERT INTO `categories` (`id`, `name`, `icon`, `slug`, `description`, `created_at`, `updated_at`) VALUES
(1, 'Es Krim Cup', '🍦', 'es-krim-cup', 'Es krim cup berbagai rasa lembut dan nikmat dengan topping melimpah', '2026-07-14 08:26:11', '2026-07-14 08:26:11'),
(2, 'Es Tradisional & Cendol', '🍧', 'es-tradisional-cendol', 'Es serut tradisional, cendol, doger, dan es campur legendaris', '2026-07-14 08:26:11', '2026-07-14 08:26:11'),
(3, 'Jajanan Siap Antar', '🍩', 'jajanan-siap-antar', 'Camilan gurih dan manis hangat yang siap menemani hari Anda', '2026-07-14 08:26:11', '2026-07-14 08:26:11'),
(4, 'Minuman Segar', '🧋', 'minuman-segar', 'Minuman segar pelepas dahaga dari teh murni hingga thai tea premium', '2026-07-14 08:26:11', '2026-07-14 08:26:11');

-- --------------------------------------------------------

--
-- Struktur dari tabel `coupons`
--

CREATE TABLE `coupons` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `code` varchar(50) NOT NULL,
  `type` enum('percentage','fixed') NOT NULL,
  `value` decimal(15,2) NOT NULL,
  `min_purchase` decimal(15,2) NOT NULL DEFAULT 0.00,
  `max_discount` decimal(15,2) DEFAULT NULL,
  `usage_limit` int(11) DEFAULT NULL,
  `used_count` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL,
  `reserved_at` int(10) UNSIGNED DEFAULT NULL,
  `available_at` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `job_batches`
--

CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '0001_01_01_000000_create_users_table', 1),
(2, '0001_01_01_000001_create_cache_table', 1),
(3, '0001_01_01_000002_create_jobs_table', 1),
(4, '2024_11_07_133714_create_categories', 1),
(5, '2024_11_07_133837_create_products', 1),
(6, '2024_11_07_134744_create_orders', 1),
(7, '2024_11_07_135133_create_order_items', 1),
(8, '2026_07_14_153533_create_settings_table', 2);

-- --------------------------------------------------------

--
-- Struktur dari tabel `orders`
--

CREATE TABLE `orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_code` varchar(255) NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `total_amount` decimal(15,2) NOT NULL,
  `status` enum('pending','paid','processing','shipped','delivered','cancelled') NOT NULL DEFAULT 'pending',
  `shipping_address` text NOT NULL,
  `midtrans_transaction_id` varchar(255) DEFAULT NULL,
  `midtrans_payment_type` varchar(255) DEFAULT NULL,
  `snap_token` varchar(255) DEFAULT NULL,
  `resi_code` varchar(255) DEFAULT NULL,
  `payment_method` varchar(255) DEFAULT NULL,
  `unique_code` int(11) DEFAULT NULL,
  `unique_amount` decimal(15,2) DEFAULT NULL,
  `payment_proof` text DEFAULT NULL,
  `manual_payment_status` enum('pending_confirmation','confirmed','rejected') DEFAULT NULL,
  `manual_payment_note` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `orders`
--

INSERT INTO `orders` (`id`, `order_code`, `user_id`, `total_amount`, `status`, `shipping_address`, `midtrans_transaction_id`, `midtrans_payment_type`, `snap_token`, `resi_code`, `payment_method`, `unique_code`, `unique_amount`, `payment_proof`, `manual_payment_status`, `manual_payment_note`, `created_at`, `updated_at`) VALUES
(1, 'ORD260601RTL0001', 1, 102000.00, 'pending', 'Jl. Admin No. 1, Jakarta', 'TRX-188332', 'bank_transfer', 'SNAP-914073', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-05-31 21:15:28', '2026-07-14 08:26:23'),
(2, 'ORD260610PDO0001', 1, 84000.00, 'processing', 'Jl. Admin No. 1, Jakarta', 'TRX-623869', 'bank_transfer', 'SNAP-864523', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-10 16:00:41', '2026-07-14 08:26:23'),
(3, 'ORD260606QVW0001', 1, 30000.00, 'delivered', 'Jl. Admin No. 1, Jakarta', 'TRX-902713', 'e-wallet', 'SNAP-922819', 'JNE8MLDC7J5FO', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-05 22:58:18', '2026-07-14 08:26:23'),
(4, 'ORD260425ROT0001', 2, 87000.00, 'paid', 'Ki. Teuku Umar No. 903, Banjar 76841, Kaltara', 'TRX-176386', 'e-wallet', 'SNAP-201534', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-04-25 11:07:43', '2026-07-14 08:26:23'),
(5, 'ORD260530WZI0001', 2, 12000.00, 'processing', 'Ki. Teuku Umar No. 903, Banjar 76841, Kaltara', 'TRX-707683', 'credit_card', 'SNAP-535791', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-05-30 10:24:19', '2026-07-14 08:26:23'),
(6, 'ORD260622UCH0001', 2, 108000.00, 'processing', 'Ki. Teuku Umar No. 903, Banjar 76841, Kaltara', 'TRX-536900', 'e-wallet', 'SNAP-176454', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-21 18:43:12', '2026-07-14 08:26:23'),
(7, 'ORD260425ZAO0002', 3, 20000.00, 'pending', 'Kpg. Dahlia No. 930, Palu 52882, Malut', 'TRX-195930', 'e-wallet', 'SNAP-165970', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-04-24 22:57:54', '2026-07-14 08:26:24'),
(8, 'ORD260511PBC0001', 3, 24000.00, 'delivered', 'Kpg. Dahlia No. 930, Palu 52882, Malut', 'TRX-509512', 'bank_transfer', 'SNAP-187947', 'JNEQKBTNIPE68', NULL, NULL, NULL, NULL, NULL, NULL, '2026-05-10 18:03:57', '2026-07-14 08:26:24'),
(9, 'ORD260603NPT0001', 4, 48000.00, 'processing', 'Psr. Flores No. 880, Padang 49763, Malut', 'TRX-642059', 'credit_card', 'SNAP-229368', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-03 00:49:52', '2026-07-14 08:26:24'),
(10, 'ORD260503DEP0001', 4, 24000.00, 'shipped', 'Psr. Flores No. 880, Padang 49763, Malut', 'TRX-900890', 'bank_transfer', 'SNAP-804469', 'JNE4WSTJH7CIA', NULL, NULL, NULL, NULL, NULL, NULL, '2026-05-02 17:18:02', '2026-07-14 08:26:24'),
(11, 'ORD260511ZUR0002', 4, 58000.00, 'shipped', 'Psr. Flores No. 880, Padang 49763, Malut', 'TRX-921598', 'credit_card', 'SNAP-779819', 'JNEFPM4ANKHQO', NULL, NULL, NULL, NULL, NULL, NULL, '2026-05-11 14:00:11', '2026-07-14 08:26:24'),
(12, 'ORD260429KDZ0001', 5, 36000.00, 'processing', 'Ds. Jaksa No. 278, Padangpanjang 18121, Jatim', 'TRX-190294', 'e-wallet', 'SNAP-236917', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-04-29 06:19:57', '2026-07-14 08:26:24'),
(13, 'ORD260518NGQ0001', 5, 45000.00, 'processing', 'Ds. Jaksa No. 278, Padangpanjang 18121, Jatim', 'TRX-673943', 'credit_card', 'SNAP-723243', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-05-18 10:09:02', '2026-07-14 08:26:24'),
(14, 'ORD260608SMJ0001', 6, 30000.00, 'paid', 'Jln. Jakarta No. 80, Dumai 17171, Jabar', 'TRX-963603', 'credit_card', 'SNAP-744417', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-07 18:33:03', '2026-07-14 08:26:24'),
(15, 'ORD260510TGJ0001', 6, 45000.00, 'paid', 'Jln. Jakarta No. 80, Dumai 17171, Jabar', 'TRX-610703', 'e-wallet', 'SNAP-269372', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-05-10 08:29:49', '2026-07-14 08:26:24'),
(16, 'ORD260428RWJ0001', 7, 101000.00, 'paid', 'Jln. Basmol Raya No. 219, Sabang 84524, Sulut', 'TRX-855117', 'credit_card', 'SNAP-900701', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-04-28 11:29:18', '2026-07-14 08:26:24'),
(17, 'ORD260708JLD0001', 7, 54000.00, 'processing', 'Jln. Basmol Raya No. 219, Sabang 84524, Sulut', 'TRX-459199', 'bank_transfer', 'SNAP-583797', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-07-08 03:48:44', '2026-07-14 08:26:24'),
(18, 'ORD260603YEP0002', 7, 32000.00, 'pending', 'Jln. Basmol Raya No. 219, Sabang 84524, Sulut', 'TRX-581336', 'e-wallet', 'SNAP-590455', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-03 04:39:08', '2026-07-14 08:26:24'),
(19, 'ORD260520GIY0001', 8, 111000.00, 'processing', 'Jln. Imam No. 431, Batam 14831, Lampung', 'TRX-288673', 'bank_transfer', 'SNAP-630781', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-05-20 12:32:23', '2026-07-14 08:26:24'),
(20, 'ORD260627HRW0001', 8, 52000.00, 'shipped', 'Jln. Imam No. 431, Batam 14831, Lampung', 'TRX-946135', 'e-wallet', 'SNAP-798058', 'JNEDFLATI1YEJ', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-27 00:01:36', '2026-07-14 08:26:25'),
(21, 'ORD260501DUO0001', 8, 87000.00, 'shipped', 'Jln. Imam No. 431, Batam 14831, Lampung', 'TRX-959486', 'e-wallet', 'SNAP-935842', 'JNEC92XYDATHI', NULL, NULL, NULL, NULL, NULL, NULL, '2026-05-01 09:27:17', '2026-07-14 08:26:25'),
(22, 'ORD260531VYF0001', 9, 10000.00, 'paid', 'Ki. Siliwangi No. 594, Cilegon 66550, Sumbar', 'TRX-447915', 'e-wallet', 'SNAP-231435', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-05-31 12:57:10', '2026-07-14 08:26:25'),
(23, 'ORD260624ABU0001', 9, 15000.00, 'paid', 'Ki. Siliwangi No. 594, Cilegon 66550, Sumbar', 'TRX-576458', 'bank_transfer', 'SNAP-874133', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-24 05:49:33', '2026-07-14 08:26:25'),
(24, 'ORD260522JHB0001', 10, 66000.00, 'pending', 'Ki. Moch. Toha No. 321, Palembang 29169, Jambi', 'TRX-936192', 'e-wallet', 'SNAP-120521', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-05-22 13:32:01', '2026-07-14 08:26:25'),
(25, 'ORD260415JGW0001', 10, 60000.00, 'paid', 'Ki. Moch. Toha No. 321, Palembang 29169, Jambi', 'TRX-961876', 'bank_transfer', 'SNAP-676386', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-04-15 08:52:38', '2026-07-14 08:26:25'),
(26, 'ORD260702IDW0001', 11, 15000.00, 'shipped', 'Jln. Casablanca No. 812, Lubuklinggau 94020, Sumut', 'TRX-399144', 'bank_transfer', 'SNAP-419601', 'JNEFDZ9JXM53S', NULL, NULL, NULL, NULL, NULL, NULL, '2026-07-01 22:21:27', '2026-07-14 08:26:25'),
(27, 'ORD260612XZR0001', 11, 30000.00, 'delivered', 'Jln. Casablanca No. 812, Lubuklinggau 94020, Sumut', 'TRX-325333', 'e-wallet', 'SNAP-894684', 'JNEXAUEBSMZFQ', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-11 17:20:09', '2026-07-14 08:26:25'),
(28, 'ORD260510TBU0002', 11, 45000.00, 'delivered', 'Jln. Casablanca No. 812, Lubuklinggau 94020, Sumut', 'TRX-203912', 'bank_transfer', 'SNAP-526792', 'JNEBJZHQCME3K', NULL, NULL, NULL, NULL, NULL, NULL, '2026-05-10 16:25:18', '2026-07-14 08:26:25');

-- --------------------------------------------------------

--
-- Struktur dari tabel `order_items`
--

CREATE TABLE `order_items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(15,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `quantity`, `price`, `created_at`, `updated_at`) VALUES
(1, 1, 2, 3, 12000.00, '2026-05-31 21:15:28', '2026-05-31 21:15:28'),
(2, 1, 3, 2, 15000.00, '2026-05-31 21:15:28', '2026-05-31 21:15:28'),
(3, 1, 2, 3, 12000.00, '2026-05-31 21:15:28', '2026-05-31 21:15:28'),
(4, 2, 6, 2, 12000.00, '2026-06-10 16:00:41', '2026-06-10 16:00:41'),
(5, 2, 12, 3, 15000.00, '2026-06-10 16:00:41', '2026-06-10 16:00:41'),
(6, 2, 3, 1, 15000.00, '2026-06-10 16:00:41', '2026-06-10 16:00:41'),
(7, 3, 4, 2, 15000.00, '2026-06-05 22:58:18', '2026-06-05 22:58:18'),
(8, 4, 11, 1, 18000.00, '2026-04-25 11:07:43', '2026-04-25 11:07:43'),
(9, 4, 13, 2, 12000.00, '2026-04-25 11:07:43', '2026-04-25 11:07:43'),
(10, 4, 12, 3, 15000.00, '2026-04-25 11:07:43', '2026-04-25 11:07:43'),
(11, 5, 1, 1, 12000.00, '2026-05-30 10:24:19', '2026-05-30 10:24:19'),
(12, 6, 11, 2, 18000.00, '2026-06-21 18:43:12', '2026-06-21 18:43:12'),
(13, 6, 2, 3, 12000.00, '2026-06-21 18:43:12', '2026-06-21 18:43:12'),
(14, 6, 6, 3, 12000.00, '2026-06-21 18:43:12', '2026-06-21 18:43:12'),
(15, 7, 5, 2, 10000.00, '2026-04-24 22:57:54', '2026-04-24 22:57:54'),
(16, 8, 13, 2, 12000.00, '2026-05-10 18:03:57', '2026-05-10 18:03:57'),
(17, 9, 5, 3, 10000.00, '2026-06-03 00:49:52', '2026-06-03 00:49:52'),
(18, 9, 11, 1, 18000.00, '2026-06-03 00:49:52', '2026-06-03 00:49:52'),
(19, 10, 10, 2, 12000.00, '2026-05-02 17:18:02', '2026-05-02 17:18:02'),
(20, 11, 8, 3, 12000.00, '2026-05-11 14:00:11', '2026-05-11 14:00:11'),
(21, 11, 16, 1, 10000.00, '2026-05-11 14:00:11', '2026-05-11 14:00:11'),
(22, 11, 13, 1, 12000.00, '2026-05-11 14:00:11', '2026-05-11 14:00:11'),
(23, 12, 17, 3, 12000.00, '2026-04-29 06:19:57', '2026-04-29 06:19:57'),
(24, 13, 14, 3, 5000.00, '2026-05-18 10:09:02', '2026-05-18 10:09:02'),
(25, 13, 4, 2, 15000.00, '2026-05-18 10:09:02', '2026-05-18 10:09:02'),
(26, 14, 3, 2, 15000.00, '2026-06-07 18:33:03', '2026-06-07 18:33:03'),
(27, 15, 4, 3, 15000.00, '2026-05-10 08:29:49', '2026-05-10 08:29:49'),
(28, 16, 16, 2, 10000.00, '2026-04-28 11:29:18', '2026-04-28 11:29:18'),
(29, 16, 8, 3, 12000.00, '2026-04-28 11:29:18', '2026-04-28 11:29:18'),
(30, 16, 4, 3, 15000.00, '2026-04-28 11:29:18', '2026-04-28 11:29:18'),
(31, 17, 4, 2, 15000.00, '2026-07-08 03:48:44', '2026-07-08 03:48:44'),
(32, 17, 13, 2, 12000.00, '2026-07-08 03:48:44', '2026-07-08 03:48:44'),
(33, 18, 6, 1, 12000.00, '2026-06-03 04:39:08', '2026-06-03 04:39:08'),
(34, 18, 5, 2, 10000.00, '2026-06-03 04:39:08', '2026-06-03 04:39:08'),
(35, 19, 11, 3, 18000.00, '2026-05-20 12:32:23', '2026-05-20 12:32:23'),
(36, 19, 8, 1, 12000.00, '2026-05-20 12:32:23', '2026-05-20 12:32:23'),
(37, 19, 4, 3, 15000.00, '2026-05-20 12:32:23', '2026-05-20 12:32:23'),
(38, 20, 15, 2, 8000.00, '2026-06-27 00:01:36', '2026-06-27 00:01:36'),
(39, 20, 17, 1, 12000.00, '2026-06-27 00:01:36', '2026-06-27 00:01:36'),
(40, 20, 1, 2, 12000.00, '2026-06-27 00:01:36', '2026-06-27 00:01:36'),
(41, 21, 5, 3, 10000.00, '2026-05-01 09:27:17', '2026-05-01 09:27:17'),
(42, 21, 2, 1, 12000.00, '2026-05-01 09:27:17', '2026-05-01 09:27:17'),
(43, 21, 9, 3, 15000.00, '2026-05-01 09:27:17', '2026-05-01 09:27:17'),
(44, 22, 16, 1, 10000.00, '2026-05-31 12:57:10', '2026-05-31 12:57:10'),
(45, 23, 9, 1, 15000.00, '2026-06-24 05:49:33', '2026-06-24 05:49:33'),
(46, 24, 13, 1, 12000.00, '2026-05-22 13:32:01', '2026-05-22 13:32:01'),
(47, 24, 12, 2, 15000.00, '2026-05-22 13:32:01', '2026-05-22 13:32:01'),
(48, 24, 10, 2, 12000.00, '2026-05-22 13:32:01', '2026-05-22 13:32:01'),
(49, 25, 9, 3, 15000.00, '2026-04-15 08:52:38', '2026-04-15 08:52:38'),
(50, 25, 4, 1, 15000.00, '2026-04-15 08:52:38', '2026-04-15 08:52:38'),
(51, 26, 3, 1, 15000.00, '2026-07-01 22:21:27', '2026-07-01 22:21:27'),
(52, 27, 4, 2, 15000.00, '2026-06-11 17:20:09', '2026-06-11 17:20:09'),
(53, 28, 12, 3, 15000.00, '2026-05-10 16:25:18', '2026-05-10 16:25:18');

-- --------------------------------------------------------

--
-- Struktur dari tabel `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(15,2) NOT NULL,
  `stock` int(11) DEFAULT NULL,
  `image` longtext DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `products`
--

INSERT INTO `products` (`id`, `category_id`, `name`, `slug`, `description`, `price`, `stock`, `image`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 1, 'Es Krim Vanilla Cup Premium', 'es-krim-vanilla-cup-premium', 'Es krim cup rasa vanilla lembut premium dengan topping saus cokelat dan taburan kacang.', 12000.00, 94, 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAlgAAAJYBAMAAABMSIXvAAAAG1BMVEX+zdO+Ejzmhpreb4funq3WWHT2tcDOQGHGKU5eOEcSAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAHaElEQVR4nO3bz3cTxwEHcCHJso8ZU2IfreQl6RFqEnqUgPRxjAoNPdotEB+jEEqOqGnz+LMr7e+dlYzW6hL7vc/nAN7VzuzuV7O7M+N1rwcAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFxrX/3Ufd39tyfd7+wS/dOKySUbfn6//Pn0tPn5vdvb7G5welZbHp6ebFEqr3sQ7rbZ2f/dXqj47pINZ4fFj/vhD83Ptzv+vWgf++Fki1I3Oaz58aT5+XbHPwyf1JbPw9kWpa5PWN+8Kly2YRnWfvhtzedbHv/isLZ47842ha5PWCfbbViGNT8+W/P5lscfpbNYc0FvrvvmhbW+YfUe3V+3tuE8VJdG4d02hfK6b1xYo/UNa1sHtf0NLr1NNty4sC7WN6xtDcKPlaWDMGlX+GaFNVrs1LCWF96nlaXpcavCNy2si/Cv3XY4rz4OZ+1O+oaFNVoc7bjDcbWCxacbt1vnhoV1UbvlXMWtSjd02LK2axnWi8ePz+J1SVhbNqzR47+kPwzzH6o7vNvc+ehxvMfRmkNYG1azaHfWhPXPxWro8+bL+tokrIvKo/6H16t/h188T1tHNhEwenvS6y8r+HW18O2ynnh+YFjpWmWt7B9/X+3w+FmvqKH3clnF0Tf5dvkkQzOsetGuNcMa5CPF+iWyCmu4qPS/p6tGtjqp9L6THf8wfDdKwv4tH3fGD4TKfSq5f43+nO/wP3kNvZfpivzQNvXg46Jda4Q1modfv3z14vN5NORdhfWk2odchZWc1LtksQzrSXj24otwvBoX3X/xVYgv3MoTMGmtw2UbevrZ44fLNjLJahguwrNXD2ch33JTWHHRrjXC2s+/pUeNljUM1YHdMqzlSb3Ob0rF8X+/WFVwEe7uJY1qWrlHpeXKvlXyfQyPs8HMkzT2ZVjT8H0v+domtbqbYUVFu9YIa7yh07kMq37ey7DG4edisQjreVLBKHwyTqLtRy200mvvJw11lC+O0hmJYXiWzZft5XeCjZdhVLRrjbDmG+YBZofDUHtgT4+GoXKI5ZWRDofuHS7SU51H51GOB/ejiyftgg3DL9l8WdHb//Csw3jX7t9W9sLTYlY5efpsatCzw+iCmh6dVycBy7DSldOQNdF4yqqcaTiPBju3QlZD/n3lt7cPh3Ur9D6C6kxp0pPa1E+cHYV6E5kezar97yKsLJuDfPM4krLtjqNT3k96EsPyKTi9U6v7krD2t5px3VUzrHfrN5yF6IKd1lcUYWVR7Of3qsaXPs6b2jwa7OwljXJYPj/znD8c1t5HeRxWp5XPVivi+3FuFne8pvVOQRHWu7zi7NZ0EH/p+fxf43sZJOkPy1+HHIRa3ZeENdh21LaT5g1+w7BrdntRv/lMa5MtZVg/5hVnJ9YIK/+NziDuVORhvctXXPuwxhsa9Ozwoj6tOa23tDis4sQat5N+tkkjxTysot686LUNaz+sb1qzw1G9aUUPx0vCmkRVZU3yvHIZP/z67S/v318prErRrjXHhvNwZ7Jmw2WntN60pvWG0SKsbB7xXvF07c9DORhsF1ataNfWD6RfTxobLs+w3rSm9adci7CmaZNa5I+S1R7fLPt5D9qHVS/atTVTNIPVrEFj0mPVHGpNK5o/bxHWQdafyiobLUeYZ2mRk167sKKiXVs3+Td6sEzr39HKVVi1pnX1sNKPiq7RRT7CbB9WVLRr66eVhw8a81DJjaY6R3P1sNIO1kFWfrQor6mTXquw4qJd2zQH/zJEsw/Z3FPZtK4eVtp1z8cy5Ys1e23Diot2beNenqyZKa31F3YIK9l2lnXUy7Fj67Diol3buJdRNG6eZZNNxUN7h7CSk8w76sVQMevatwgrLtq1zV9JNLWSdY7KprVDWKtV/fzz8vWcW23Diot2bXNY0dRKdmBl09ohrNUU6V7epy1nG6dtw4qLdm1zWNHUSv4tFk1rh7BWl+CtfLBTnvHs6mHNfu+w1rasZavIjnyXsJY39/Fh+XMvK9r6MoyKdq3tZbialkiPeJewlt2GYuavGLoctA4rLtq1tjf4smntEtZBKKevi3rmt9uGFRftWiOss+z/YfT+dvnkGadFdglrED4r9nuQbfhDtq5FWHHRrjXC+u8k/X8cvcFYhtVPe2C7hDUMz4vHxyBtqf3F7X7bsOKiXdsLb/5WWO1wcfzXybJL2vi1e+U9+LRp7RJWb1EZN83DT2ejR4twt3VYcdGuNf5oYPWuxfv3zb8gqIQ1SJrWTmHdq1zk+/m7He3Diop2rfkXFt8mL8E0JrQqYS1P9WTHsM6rv9n5Y0hfTWofVlT0dzB6ePr0T5OPucdHX582XnrrvigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGT+B1+SWc/zrti1AAAAAElFTkSuQmCC', 1, '2026-07-14 08:26:12', '2026-07-14 08:26:25'),
(2, 1, 'Es Krim Cokelat Choco Chips', 'es-krim-cokelat-choco-chips', 'Es krim cokelat pekat nan manis dengan taburan choco chips melimpah yang renyah.', 12000.00, 80, 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAlgAAAJYBAMAAABMSIXvAAAAG1BMVEX+zdO+Ejzmhpreb4funq3WWHT2tcDOQGHGKU5eOEcSAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAI5klEQVR4nO3bzXvbtgHHcZmiKB+HOq50lGo/aY5VVC8+So4fz8epqff0KKee7eOYNHWP5rqs+bNHEi8ECOg1UtT5+X4OicQXEPwJJAFIbjQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/DlFD71VNk9upzPXtR8W7Pztu1UOtUFHw8r3c7aLhiPzujn8zlvfFP6ymX7+TQjxxw/T8No9sWD3wcHyh9qoiagcztmuJXrmdSpG3vpVwvqbOl73H8HVTyqstviPv36FsO7ymN4Mr/LW9VVw/WeEdbtsHdYzObg1pnO2s8JKu4ENlw8rzsTvZQFvTzcdlt38t2ESrvCcerTFfwPrlw9rXDWoi+AGTymsYMNqxNYDYK5YBPe3PKGw7oINa3n3C/d/OmEl2aKGseiAC/d/OmEtbhjzxTMegZYnE1aSdaafdby2+NeiTZ5MWPeLz3W+sZgu2uSphJU3rM893uIC/r/CSs7PvR6QrMeSDevmfCpfnOsXRvYsuEdyVm0ZCuvWrpEVVl5V6xBfPqzktBj6dGrD3LIeSVaNiJKHshd6diXnCPSsw927RuNFPp4pVsb5WKrTc4qJxV8ClUheFSPFH9S7KqzWgxw9xkWVqpJMWG9/KoeYPzqV3CI/rIEaKbrXS1mPS/F3syAuGllS1HZavNU9+PFh3vyKM5iqcaf7QGhaJRiJGqD+W741YSWq/6vWd3u6hjIs+akWyrHq0XD4Srwvp09GS578qryw7kT35e3tWf5ZO4uLsGKrYZVhlWfRLd9WYeVbXZxNxGP+4Pv94ix1L9x2aFR0mR/y4uZboYI0YV2qffvi8Pj25lToBqXCivNP4s0352f5BzZqFHMhRm+VBFbghZV2R7Iqr5zFRVhju1kUYV2KzvdT+bYK674oIMkO8nv5tNjMuRvvB2Z38gHQSB5CNmYdVqR2bYrD8iB9HbQOq6sm4C7zT2YnYUUzOp15WO5552FFojPSb6uw0rKAaxHJaPtOC90L9Bzu9WegPgwd1kSddF/9Hwv1cNCXoT54kn1lKhms/KbUw2oHPnpVj7FzCeVhja26mbDUOLkpXnRUgT1rr+vAky7Vd0eVhgrrTk2bJabPP5ZXvN916HdMJYOV35TJYTWtPC1q2g1v1xLH7gUVi1/tScAqrGdqtWqi7i197BdvteVBuVaGZcYKLVOA/iC9sHRb3HpYwr3Ur2d0GlsidWsSiw/2JVWFpU4t0yPv8oaijf3iraYn72jy1E1B1+YwsVrkhdVWm3zxsGa2rNoIOHYXVGGN5IJUX3BOz6rvh2UdMSoff2VYTVO6tUsmi/LCaqmDbj0sa1q50Zg91mjVO155WHanwISlT32iuxnZ19ZmgbAGVkdXfK2rMFEPZeeuOpGXuBdWU4X05W/w4enhljh1+5OxcB5sJiydxkSf0aKw0me110VY1hSjtX9fVvZPE1YkwoO3lnieOd/+xG5L88IyZ5QuCEtY68uE87Ds7q91zxsfukVXB++pSvaCld8Uv1Mablp5Pe6dplXrbc4Jy07ffxo6D4B+kUYeVr+qRGJd7erpY4d1dvLw26dPuwqrLcSPge3yeiRO04rtFvEZYcV2WOXee6JpPTvieWFFqdNn38lAuuN/kV/U494d7jjzB0uG5XdK7TBklnvC/gIpEh+vtEktrGYe04dhMYDumUpuU2A+qxjMH45qC4t6JO5A+tFev2RYe94AIbLDupZh2Y02svo2atCui04y8X4qD94zldym0OTfz6k1H6KU9bh3pmge7fVLhtX2TicUVmrN60Tijwfjg1P0vfhFH7xXVXKLwtPKr9PaPJSsh/2QWi+sljefFboM/2mN5mN/BkwPpLPqcuxVldyiGXPwyaQ2+yDrYU3SrBdW5O7VqIclb/D5fXMUXO8UXQXf2m1YeSMKzJTa/YX1wkq8bpzbdVBhRdXjMJkZVjVO2nVY+XPLObCqRzVNs15YjdT7XZP9VB2oTql1nIY/a6+K7pui2rsOqzZbrupRNa01w+p7s3/OcKeoTRGWdXd0hkt20VXV93Ydlju1YuphPvI1w9r3BggTqz+emYF09aVboCd4UCtYz0I2dxVWrfnrsEzTWjOsSNQbytieoinKLMNKTMfUH056YU1MWOFZgE2ZE9aj/c60cD1sWzOsRlof8FjfYch7j5wlaul5WP87Dn0Z6oJjseuwZlyG5juXdcO6rvebmtXjblzGpKbUdPeh6T0OVdHmCPs6rCj0reQGrXiDb5imtW5Ykfc7X9O3VL1MFZbuPlR9T00Vba7f9MDcI7xuxkbVw0r0i7Hb+quw1EmsG1beYn51F5gvie7kuerJ2r6Zqa5dXKpo/ay4E9+Y+X7vyblR9bD21fxMvQFYT+W+6p8+2uuXD6spxF/VMa7UAvklaqx+VKjD0t0HvT4ftDpFN+UNIcoOIl05vxe3UZOOmQC5Kn6ZsS8+Huf/va197W6HJZvW2mE1LoV4f9EofiGgth2Ij6PykHKEZb4GuFdtcCAOn+f/3ZwKt+hUvJsmrzPxnQmrXwytk6PlT3819T8aaGZCdD9l3l8Q2P29QTmoXjusZGAfsFH+Ml50q0N6Pwwp1n96yP+phdXWPwsxYbWKygt/6npDvL+wiH+Sr0fudnZY5UTm+mGZn7/IyaiGnvDUF5v1kyPVfVAToh+f14p+USx916jCkku2ey26bo5OhsdbPsTwang8rd4nRydv5h7y7OTqZeBPDF6fDGtL3568eTn1NwQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAW+h8Nnm3l0dt3NQAAAABJRU5ErkJggg==', 1, '2026-07-14 08:26:13', '2026-07-14 08:26:25'),
(3, 1, 'Es Krim Durian Kupang', 'es-krim-durian-kupang', 'Es krim durian murni dengan daging buah durian asli di dalamnya, aroma mantap.', 15000.00, 38, 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAlgAAAJYBAMAAABMSIXvAAAAG1BMVEX+zdO+Ejzunq32tcDOQGHWWHTeb4fmhprGKU6x5k0VAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAH5klEQVR4nO3bwXfaRgIHYALYznGntR2OJOk6PSZp326OZTduewy7dZJj6DZuj3W6fdmj6aaN/+wVkpA0QhCwwTj7vu9iIwbN8NNImhmg1QIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAYC12T/sbruH0+w1XsNC9qv7iopWnO/fuN5S4HX5ett52Ut39Lx4uW3xqfGfVV6xRO1R9urho5ekn4ZOGIiuEdTer8d3z/rKvSH2MYXXGod9QZPWwEt8s3djW1sPaPyk9W1y0DKu5Y60W1vHJyXffTtL6Y4WTccthLexNc4p2xr1+U5GVwkoj6hwNQlghgI8wrCfhv41FVg8r8e8Q/r7sqz7CsNrjXvOZ07639BlVhtX6LDT30yaNN+HrcqmwPp/TsVZRCas1WsP+rsNlwmqHOR1rFdWw5vbUG+YyYd1dR0eohpU8+Orqe9y8S4S1lo4Vh9UOh1ff4+ZdIqy7K9y85ovCSq5aH8N5uHpYe2F/HRXHYd0Or9ax0w1bPayz9Vxf4rD2wp/WsdMNawyr8/oiXBz/+LCpaNyxHvyS/b13LyvyNn/Ng2Rwuvdt+D0do3Z+GF+8qJ9mcVitbBS/96Zsw9t+dY/tfMljWuFk7P/dRegdT5ds2m+zmnrHRYm1awqrPchmuL1/NBQ9C9UJZDag/nUcQvqwGMGPP2ntjSe76LcmF6RE/QpeC2t4kG7sVWo7L/e49zLkXa8YwR+N83n4+1Zedb/VGaZb/rXE+76UprCSKt8dP500ZrboXjiobpu0vZOGkbe4DGsY3j0Nk/n2l6H3NIm/NkmvhXU33cGcsP4yqSAOq5sezXcXYbrjSVhJQ46TOjc2aGsIqxv2057815cNYY3iNz1p+39C2D85zVtchNUNf0uiTUabyaT758mgv9a1amHdSh82hzXpo8fPXxUVZo3svZjMfNov86OXhJU0vJ+eF5uaDzSENSpmw0czRXfjjjVp+04IxelaCWuUhvMkPOtmI41BbXBQCyt7ZXNYw3DQr1SY6n6Tv7wzyFbWkrAGvbT2ehvXZzaszrwVk0nRUe0Wn7R9EP5ZPCzDOswKJq85y24IT2qvrIW1kz7dGFY3HJRFp2F1KnU+y/78edqjNjZomw1rd97QICm6Wz+Zxnd2wm/lwzKs6dEdHI7P892eR6+shbWbvuXGsIbVNYnZJZp81HE7DPcfTlvxqvkdXFU7HJwWfpxs6c6rKgmr3rGStp9VL6eVsM6zf85CHkqndlRqYe2lh6gprLfRJahhPStbtL0dinJzD/dVRWvw6QnTnbeAl+Q6c4aOD8fVt1IJK//nUXEBqb3NpcP6Kbq5NYQ1uJMVLHbY2dQId6WwwsxT4170wUUZ1vRd3yo61CA+g2fCOm81hzWOVvsbwhoeZgXL/Td/QHB17XCn8rnhZEu3PiIqi4aZM3QcX8TKsA6KLef5f8P4HlULqz03rLjOprAOsoJldxpsaO256QJ/Pq/owcw4fBz3+DKsaXPL6EcLw5rfs+LBXkNYozys8hhfX1idecOUxgt8vKEprGmBUbxYsfQ1Kz4+C8IqWzLc0OpYw6B0OOc8bBw6xJ+1zoa1s2RYu3PDiq8/cViPH7w9PR0cRFW3rjWsZCbROBVtHJT2oodXCWveOOs8rrAS1lE+4Z8Ja3R9YU0m0l/3m4vWu9Y4TuDyYc0fwX8VV1iElS8xbDusdIlmNq606DAePYzj69vlw5o/N4yvCWVYoxB+f/NFq7xmbSesVvunyfpH/VxMi+7E49Jx3KzLhzV/1eFVtVi54y9DL1/l23JY6fLMzKAqKxp3rbWFlcW0QljFHGH7YaUrkbUP1bOicddaW1jzV0pfVYsVO94pZ4w3IKzJlevTpqJR11pbWNkLlg/rbjlmGd6AsJJxYjwuyItGXWtdYeXrLMuHVZlp3oiwWmfxnW9adFDZvK6w8lnRo3Jus7cwrOqCz+ygdBthdeMxzrRot9K11hXWWfaoEtbuwrDalbHqdsdZU7VPPouila61prA6+X4qYe0sDGuvPI7tmxFWZ05Y3XK+tqawuvm97Va58dbCsCqLoTs3JazoubLooLgVrSmsYb7DyjseLduzHt2UsJp7VqVrrSes4gZbLuh0wgfCOp9uGdyMsGrLgGXRTtG11hJWu1gVK2vsLg6rUxyu3XAz7oa1hkbfVs7buo6wOsPi9touMhgcLh5nFcsdo/2zLYbV7k//G9SXySvfg8+71hrCag8r86pB/lHOk/D94rCmH5sn055thrW7n8/mP6utXTX9wuLKYT1+HarfGcm/rrobDj4wgs+Xm/fGvf51htW7KJ2nDQ1f//Kw9fiH+rJD0293rhLWpMJ08a78+H9S+YuHnWQS/6qzOKzkBvDH/ce/jpNwrzOs+g+dyhXI9/Wis78Ku0pY03XOaE41yjb+1vpAWK3Ps4JJ/dsMK/tuWsPvj6Kw8q511bDeHb+JtuaH6n3rg2Fl3wqbtPH6wmrUOXp9crqt330cvX6+3Bcdj06WLAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/N/5HwoGmt22wAieAAAAAElFTkSuQmCC', 1, '2026-07-14 08:26:13', '2026-07-14 08:26:25'),
(4, 1, 'Es Krim Matcha Latte Cup', 'es-krim-matcha-latte-cup', 'Es krim matcha khas Jepang dengan rasa teh hijau premium yang seimbang antara manis dan sedikit pahit.', 15000.00, 39, 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAlgAAAJYBAMAAABMSIXvAAAAG1BMVEX+zdO+Ejzunq32tcDOQGHWWHTeb4fmhprGKU6x5k0VAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAJ3UlEQVR4nO3bzX/TRh7HccfPxw7kQcc4dBOOdqAlR7wLLce6u6E54jZJe8RlgR6jboD82TuaGY3mSV6sOn6RfX3eB7CTsSV9NRrN/Oy0WgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPiL+pf7G99m+/L1xrZ14Npf3tT5defgQaLFUKyw48cH49pnK+iLH5q9cHVt4bq/vKnz6xNxL9FkpbBy8dR5Nhdfff5LXV9+WJ1c7CearBSW8OLJl2+83kbD2j6tLN2sG1a6Y60UVke47+E/CwyWDYUbDeuzT6jTtJNn+6kmq4Ql+/RO9WwgxF5t0654Vf8+X3xYJ+I/ySarhDUQ06x61hPT3dqmdzqsdp6lb13tFW5pfXEuqtZDsdipbXqnw3pY07FW0hPvnH442Rlt1za9y2G1RU3HWklXHDiHudibiCVNX9W/zxce1mgdHUteeGNxZZ9N72+J2jNwh8NaT8dqbQmZkH0mrobJmZtyh8MaiX+sY8uTrDW3N8C2+KFbfye9u2ENRP1IvAo5oFdjel+87tUncnfDWnhLuubkVGFox/SuGC856C86rM7Fjbh5/us41dTvWEdv9P8HB7rJe/OaI3lJDV6ID+rK6pznNz9Fw5y8Bnt2mNrK5Bs/LTd/+K8bkT3/2TaNwvr2LM+uX+oX67Devsiuf6kaHF+8yEXZYm1SYbWnelmd/ZhouvBOZK7WKG9zofuIncHn91qDvHiLYnfnxZtF8/PZnsznlXky2pVvf6UfH+ZmWf+pbBqG9W/T4O/FExXWb+p5OZa2fzMNsvWWulJhzYS4fv6s2OW46UB4E+0irI4KQz11w5qJ62dqdfxYZM9k/OHFMr0nV89Py00WT3QRoquO8vpG6Jf0naKICfyxfHhd7J86U0VYD+Urihfsm7cuGt/IviXqVwVNJMLqim11cT05S4Q19w+6COsPIbZPL9VTJ6xucd4Hcl0kF92vi0l/2LVknq283HgugzJ70hXZT0VhsX2mDjUOq52Lj/vy/+PzMiy5JpcXwfG0LFxMxYffi8v+b/l6x7NEWHN7Dz+MmvaDcyXD6qk91Zyw9LTgpJgSqKtjGs45iw3PTKVBdbFcH2r3e9OwMy16yuD09PRMfFAVJL2dE5v7o+IfGdZI/FPvoFmZPzMjqeyD9XWfBuKwOnW1kqLpPBg9ZFhTvadKFdaubihfs9A3hJPgleqqKxfPavCa6u12nHcz/cIfs4K6Y1/8WKY3MpuvTku+1uswDqtfNzWQTfvhxZTv9cSf1dMqrLIHTnfzK/O2V8G7XamJqaJui7PwQh2UpVQvrF7QW/riRbnVXrTri/oFZwNtsXNp/Rrtmd/0ftixZFgLd+3jhHVV7q25/DrBWVEzha755bAIbR71gjIWb5cmwT70q7JhfOa36tdQDXg1+G29ZzX3W5lrdIXmu7m7qHbCMg8mdpDL/deqO37fNJsUjRbRysBcmH5Ys8xv1HdutHm4f0vWUA2sFJaIfpVn3qmrwiqPaMue7KASqlY3bXOc8+IgF0EK1YXphZUHV2tfVK+Lqq1L1lANtMWe87mh3rOa220RVrjp3B/EqrB27E+uzKOZf5Xpc2J+q8oPo2h8KV/ihhVdan2nu0dXcm+tc4fUAH9V13Qnniz5n/ZVYZUHUEUfHIiuyEz1qKQ2OYkKWvNEWNHu9Z1dmIdX8noXjqmpQ83tNjnA+z9IhVU2CA5E1/r0bExfjfFgnAor6vju3Tu6km87LLlOSW8gOXXwDzAOq1cXlq4i6yKNHue9j4aOj95fXk4TYQ3D8+Xm4YbVOXj/7vL8tsOS641f6ppGk1L/VK4Q1ijTL9BbHLe8SA7NUj4R1lZ4k3HDGtndaZ+bm9Yth1UspL/bTzcNu1buJ7BCWHqioIs0W+axObDOrLw9J8KahBdrMqxv7B3+tsNSJZo4LtV05p/YPBy1PzssPR7pIs1CnQE7+MyFXAg/aqXHrM8KS8695Gp8vIExy9SDomtRNe3589Jg0rNCWHoOpYs0M3VPHJj73GORmYVwOqzgnpkISy7BP42jX/51NWXlJ2fxpEo39btW87DM7FwVafKv9PvrOYCd/TcOa2jP6EbCUvXK4MsfuqnftZqHZQoyRZHG1ADN6rFXfSrZ9DKc2fXqhsIqRq77qaZe12oelnnzokhTVpf1unlUpZGawUezsTisdlWXuO0ZvDUQ/rygXZ55p2s1DqssIm9lLfu5hX6Rs75Lh/U/pw5O842F1Vr4+1U2nTo/bhxW+fFEMcUampOiYnJLOStPSnVYzrBWu9BtZFlYXb+WVjbtOl2rcVjlB1/F5H1kMlEdqe2s/VLzrKjAF4dVTU1lP9xUWAN/lWybOl2rcVjlIRbLwvme06L6+LBYuesHbliD8Iu6cVhOYWy0sbA6NWF1qwG0cVj257Ijld8PUSs7Z13cS4UVfUQQh+VsqW6d28zysLzfVU2n9o7UOCxbYpzeK4tauqDl9CxbZfWG6WCFtbRndW5/uVNtKt2znK7VOCz7BaP5blku1QPzoBqzpsmwFsHcIRGWHbO6mwsrqLNVTTu2azUOy351bbJdFuL1FKpjT0RflHdD7wOnYVD9S90N9+02NxZWcJf2vq1sjqhxWPb2PhTd6mHxanuZzberjxWdLh58gSAR1rDMti++v+Ww2vvlo+BDZO978OU8smlYtuDeE3aI0eN4+YG4XPaUYfmD+syfPMRh2ar8LHty2zX4bbPm/zqoXaX+wqJxWHZcGQj7HnpoGurNDvJs337be+p+ONm1X455p/Y3XhuaYvcf4s/BmsPKbipXauPiuzfj1vF5WHZI/e1O47DsM+fvUPTQJH/w8cHx21yup21YI7HzoPXorTnwWVGsenT8bmpq0lFYE5H9/OjoTGTjdYcV/qFTVaf8FDaN/yqscVjVB2PVB0TmRvjQfmXGhmW+SvPUtCu/wFUXVts0eNW67bD0d9Okj+OwqROW6VqNw6qWy9UQZApa+vtexdarP7r42isRD3SJfluVJ1OV0m+FqV6uN6ykzuHF6WXqjy835PD05ZvgR0/kHjk/O7o4ffn7kndoX5yG3/IEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD/d/4LnD23k2/V11oAAAAASUVORK5CYII=', 1, '2026-07-14 08:26:13', '2026-07-14 08:26:25'),
(5, 2, 'Es Cendol Nangka Cup', 'es-cendol-nangka-cup', 'Es cendol kenyal pandan dengan santan gurih, saus gula aren legit, dan potongan nangka wangi.', 10000.00, 100, 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAlgAAAJYBAMAAABMSIXvAAAAG1BMVEW799AVgD2R2at8ypgpjk+m6L1ou4ZTrHQ+nWFdshYYAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAJ4klEQVR4nO3bzXvTyAHHcWFbdo5M4t34aIeQp8cadqHHqJsSjhgSlmO00MBxVUqS47qbbvizO5o3jUYjY6fq8xD6/Rx2Y1mjl59Go5mRSRIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA36Ynf48vPut2N6/fdru9uN7jyp9Xr/n++uj5xY8bbr/4Lro4ux8cxdT/8GLDnSTJbHfjIrcwEJX4eRnDTK90PN1o++uFNRB/qz6MxOqrFvN1hdWTWd1cXsn/Hm60/XXD8k72aw7r1FlV+wuxOy3/f7A83Gj764Ylpu7D1xzWWquNxK6NcrrR9tcO6zdvX3c8rOIWJ6ALrhlWseM+3PWw+mLnyytFrRvWydg1Anc9rIU4u+X21w2rL361H+56WMXktttfN6xkuW0/3PGwUrH95ZXi1g5r5q7HHQ9rVN0jm1o7rCqiOx7WwOsFbWjtsNLMduLvUljpk6ubi0f1QxlHSqZPry7tSFH1Zw+uLn+pvj64uik/ubDKzb51T7xmWMncnq8L68F7eSRmF+lpUg5Pby6mtkzv/Wf15ak6QhfW6WmjbGcaYfWWaugz8WcL8u+bBftqrPiTWUG2ae+8z0mal5+eVWH11WYnU/N9JKwtW31NWK/1gYh/qYVD+a0ano5Nknqs+kz2aspiLqyhal7rZTvTCKsQ48vLa3le3rJls32XY8XnF1dC/Ft9kmHti8nlP4Vt3PbLkeRS/NWGlS7F+EaOLCembkXC6tlOvA6rXwbz+bOM5KxcKMOSu7y5zMwoUn44Pn8v9xCEVZT9taBsZ8KwRuJZeT7pUz+syBB7Lv6hDln3JfPtvhoPvbanIibyhNN34syEtS9+eqHqm2mYImElthNvwzpWd9GfdH9YhjUXn9Qm1PWY6VrzTrythXWiEg/KdiYMa2570mm1LG3ONPRNZ2Kkq0O+PRtPyz9m+l6yndjiex1WmumTSZdm87GwbCfehGXbgblqMIdiT9bTpLwO22qDpmUoJn5YPb04KNuZMKws8vTqeaNcY2EbGF0d8h1zPw71dV+aUxkKvb0tez/YTkgsLNuJD56G+uNQzM0tnO/WN+iHNQ8epLd5sK4wEHvWw6SsRJEeVb+50KaRLNS1y4WtkCqFvku30Hfw3N3U2Xa1mn8UaqO2ttbOsKf2PhT2DlbrVl3YzAtrpCtfWLYz3uTfWG39rLlOM6zqxhyqY81dq1aUJ7wlbB9hoL+o6qs5y2hY5ruwOqjkZVhmm6Nyj4V75MyqsNKlfX7Uy3YmCKsfC2vYWFgt0VUxd+c3L2/LhbvuPRWWd4FNByEalkkpDCs7VHu0bXW//Loqf68K66RZj1TZzni34V7SUm+bYVVVRx9O7hrSWXl/5tVDSNWpUTUCMFcjGpbpxIdhLe+rYzg0H1Xlr2rMlgurF3n2Le83Fv0XwgY+NhHfDOte9ZQpysOpeq2L8hJ7Y5zld/WdpPo0o2GZTnxLWPYYVF32J3SmiQ4r1w/kZtnOhGHFJmOaYXlDsbxMo6pKKiwvCpXbwtuo/i4elq4lLWHZhTqs3+y3LqyR/4aoVrYzYVgn4QMliTXw82r8My+b2iqse2UuXr9MheUPc5e6xY+GpatdFZYcT14fHYl6WCoo/zZ8ofYgW/faJr2ynQnDSjPxbBqsEwlrp/5nPazUewapsLxszXMsHpbutbmwnponTySsqsbc0w/S3f169ffLdqYxNpTPaPFH/Qnc7JTmcuRlZJuGpVZtCWtQVhMb1g9CHL99vLeXRcKqdqjbudm43rrXynamOUVTjtjHtV8opI3rk3uvZpth+Y/Uot6k2b9bwlJ12PUgJnqKZRkJy73fSHUvdyZqtb9etjORyb/0qRyuf/KXNMZA+e65U85ahTXrtmGpTrwJq7APt1hYfTO8sn2r2STzp//qZTsTnSlNP4jaY7gIOzDzYEFXbZYaPdlZBxNHNCzZEKjP/Uw367PdN95Og7KdaZlW3q+9opiH/Yl5MBvYWVhlL0WHNXAvEuNhifHHhy/lPaBvAfm8LaqxTlC2M21z8LUH8aLqsCf22Go66jok6o7XYVUBxxr4nrjULebv7oCGVT8rKNuZtrBq7yi2wl7pIqhqQVje9dSdUm9aSazolCbq4abDqkYBsa7DYJK8usrGx3bSv7wcc3fIQdnOtIVVG1H3w9m/sFQQVjUnsNlwJ1GdeB2WC7wXC2sWTHTXx4ZB2c60hVWf2MqCNmrk17ukEZbXRgk9kHZnOlwxkNb7PdRru/mC0bphJa5fGpTtzHphzYNGK+ymBmFV4+y+maJxqw/0llrDkmNyE5ZdYxENK3gc6/ks230IynamLaz6XM1WeB9m9SsbhFXVJDv551afr5j8M3/+rG9D2+4so21WMNjWjxDbfQjKdqYtrGHtaNIsaNGDNwFBWNVE6tJMK9vV01XTykpfPufKXdtZn+E41nXoifHFI/M+tWSet4V52VQv25m2sILewkkw/7FVvw+DsJLcZDsa64vsfixhn6vtYSXLscplZvpK+U4R62ft657DczMuM2GZ7kNQtjNBWKl5pZwGTXovE+awep/097YL+FIflV1RhzXQXWhZj+yrML26m0dZEdZCqFy29CbeiF+jYSUH1zouPaNke3K6+xCU7cxAVKO8s/IG2i1HoL0inGh4I8RHeb4vP5ip1DdmxQ/qKMOwUpWt3MrUdHlO1O935QIzDlkR1lCHlYrxj3KYKnaTeFhyjZd7D+w7cBuW7j4EZTsT/rS7KF98y4vW+FXKD+UrDe8H4HLF527FMKwy26Pr8uV+7q0uF9j6uiKsJNO5yBvtSP20oS0s5Wd9AG6MoLsP9bKdCcNK/6L+1L/jrtFfjD/auZF33r8haISl1/49cWHJSlWubRvCVWGZN6VpYX4GsjIs/1WYKqW6D/Wy/0Ppk/PzR7EveuUXXrP/6sn524etm3l1fl7/xc+Dls22k9t/8cWV+mGDsUHZ/z/djpW/ca4Hii9r+SEmYqhZG6DNWl/k91BocxJMrSGUuh5qOIhFQyrM5Huad/tztW9RKkdOv5wm6cGyOYhF6LX55+3VP0NAu94HFdcfDADXku493iMqAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOjUfwBL4KyhatMcnQAAAABJRU5ErkJggg==', 1, '2026-07-14 08:26:14', '2026-07-14 08:26:25'),
(6, 2, 'Es Doger Tape Ketan', 'es-doger-tape-ketan', 'Es doger legendaris dengan serutan es kelapa, lengkap dengan topping tape ketan hitam, pacar cina, dan roti tawar.', 12000.00, 68, 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAlgAAAJYBAMAAABMSIXvAAAAG1BMVEW799AVgD2R2aum6L0+nWFTrHRou4Z8ypgpjk+Ixze7AAAACXBIWXMAAA7EAAAOxAGVKw4bAAAJrElEQVR4nO3czX/TRgLGcUXy27FDnayPNnShR0xakmPcTZYc190kcIxbEnqM6RY4Rixs82evZkYv8yY5CXbc8Pl9D4DlGUt+PBrNjGyiCAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFiu+KFpYdFH209XdywPh9W/k4ePVrej2xoJU2MSedFPJ8PVHEosvq0e7IoHq9nLl7h5WJkXKzkUM6wkFcOV7OSLjMTBcWVx0aNDmdb/VnEymmHVN6x3v6xg19c0am5NgaLJ44kQf1vBoRhhJelgWFNqsrWCXV/TzcPK/EeIfyz/UIywdsV/60rdu7Ci70TtJ397VVhxOqg9qvsXVjSr/+hvrQrr+4ZXv4dhNX32t1WGFYuGF7+HYWUP9pZ9KGVYo6Zmex/DisXSD7oIq7Fh3cuwsl5r2edhEdao8VJ7L8PqidMlH0oeVlf0m0rdy7C64pslH0oe1ry5N/zLhfX8VTr4dPJ7c9FqFL9zlBU3ZyFyw4Hc8H6Yb3l8mA7+WTyI3+sXis1lhiIst2FZNSMvrGdnh6kxt39yIQ//UHx6uYoJWSis7/L58udhU9Hppl38z/KZ58WGRFzqLR/UhsGpftQT8i11Xwm7ceqw5uJf5ka7ZuSEFf+WH+rgQm9Isynlj2rL1grSCoTVzva9rybM3zQVHQmj+H5azYDiVAwOzrIoPhZh/SBE/+AoLa5yKiyVqB9WV2ya2+yaM2OB5FRumMh/XWVtq6iVhdXJqhxlTyx/1BwKayJeyG3JH2ljWBv5vDpVaxBJNl8c6ifmYlM+s5OK33VYXSF+zv6Kp/kbkGF1szd4cHJqvqAKa2Y1LKdmIKzPb+W+/p7m1bKwJuKnSE3Ilt+0/LA6ZWcUnzYV1SdTNufNz4vv81WVcpjUFVs6rHne6LJhf1lzKjaHzo5lWB27YTk1/zg+Pk4HejVJ1d4v+tUf8p2nD1p5f2Cnvhx+WGNxca2i7eLDHerHST4D2i2vZrtChZWUXfaufgNZWC3d+iwyrJk1IPFqRk6fVb1GqkNOH0zzj6pjrrsuiR/WrG6Y4xTtqOPvVqt0eUqzsv3HOqxW0c0Xg4MsrGlg1SJ7tmPPC7yaUe3QYa570HSz7DrT5Y8xRuLkvHTRcDReWF2VzUbV2mOdm7EwOFVvdlStEOsraE+8D3W/WSB2w/Jr1h/ehi6aVl1V7Yd+e9Ya/J46mrpV0GBYc6MfncjDi8vWIM/oy2Jz8RLyz574LdT7xmLTWYH1aka1YbV055FWJ99YBAt+iS8J6zKyG7sq0DY6VnUaJcZyek99/j2RhlbYs7PW7i79mlFtWHkPmlZNc2P5tzxG4m1121C9+mSztqgVlmpCsXljQU0XW8Yb7sgi5ryoo95LTwTnlbFwtvs1o4aw1GeUVs2pVXehur1ABz+4XtGuTuKy2tKWTdMLq23M9fSpm4UVen15GlpJ+DWj2rA6eVjVJ30nYY3rBiihPss86XRyLaP1d/SG03KDHtL3wmthXgfv14wWhlU92176skggrLaoOQ+9ocOes1Cjru92y9orB6+aOrF64ZuC3tDBrxmFwkoevn93/joPq+pw7ySsbJgZvocaGmdtWG1dhmAeY0sXGRol5MWqZ567FW9Q6teM/LDi1/nVyQ2rcydhZTPjfui2b2gEb19y5JXf7MVUlGPxaLuU6rD2QoeipztGFn7NyAvrx/JSvp6w1JpLIK7Q3HBshaUO1TjH1NLz2Po2xQNVM9grqrN4ajRVv2bkhtURYvDy0dOqz7rzsKLHaej7DKFVh7G1TXWv1XQnUb1fKKzT0KGosNrGuHRxWMlE/FlMBdcVllyeEd4ly13PkkMMJyx5qD1jIv2tKnJu+DVqDstsWn7NyAmrV0a7xrD0GuTHxqJqtub3WdWXOrp6hWvs7aExLKNp+TUjJ6xp2YrXGpbquZ42FVXH5YSlTpWp6MtlpuxcVg/9aUdjWEbTCk5YzLCM+UN7vWFFc+cKH7q7Yw2F9FyuI7JTeHCV/dFX5W8aVtW0FoZljFrXHVbXWQOwi6oxlDXIzt/teLCtbyN81sX9aJrDysZ5Fw3lJtbYojyi1prDMldI/KJz9ahjDpnU7CaaZsf77N35m2LFt+0NFBaE1So+JL9mZIc1qqaxG+sOa27Pd62iiZ6FWbda9ZtzbnPYc21lQVhl0/JrRnZYc3O9a81hjRvCaum1TnPJKZ/7uHeqE28muCisVl7DrxnZYRmLodP1h2UPrMyH07zzNVe/dEv0FvZSd2K+KKzyJohXMzLWlyOzZSVrm+4UGlpWeckyN+r3NnOXjOfuLhaGVTQtr2bkhFX2Wa21h+UsAxpF43L51pgU5zefdrN5pTOJ3Isie8NpaHdVWEnetEIzbvM+RDUznfXXHZZzM6kqmkyrG7HVrGikjy6RE8urq/2DIrKuO3FaGFbxNXivZmRfdcowO+LFesIqf8DTcm5TlkXjqfFl5XIFKi7uiHYn+dS3n4+Xps4QYHFYxQ8s3JqRfQ+4vHk+HeysJ6zZC70lnjh7y4s+OysWj5S26A/l38m0uhf4+Gz/8Ep+t0U9k6VefMllR90BXRxW0bTcmlF5Gdby3uCD+Ni9m7CuDHLLTPTfbKvfUWyFiqo2829j81T2UcnOJJ/dlOTKxVZRZCDPyZ3XxR3p4NsI/XbHqalKiZ+z3elfzoyzp7efvBKDp3cUlkm+3XLtcXBRU3TTekJ+H6b6Xov1THEfMJZFBrLMdcMqmpZTU9JfpelXL6x2vaaw1LfM5CH+Giz66eCts133UV7xSL7jS7OIGLxUj64TVtG07JqqmNqSDyCeF7u+k7CCnp0fn/xSf5V0Je+Oj9+EisfVVPzJ2fHJ2+u/pMGrme3upNxdfBbe9T1Ue3cbvnnd3W34RoR1fYR1A5yGNzClg7+24Oodwlrhb4CgEFf/TMqvfSOsV31H4sPyf8D5lekVX8BJXovlf1HxK9OR96OPz8+Psr9/WvfB/OWVC6Ur+i9rvjKP1RrPZ/fHnQhLtrfXfQgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAANzQ/wEQlb+owQT7HAAAAABJRU5ErkJggg==', 1, '2026-07-14 08:26:14', '2026-07-14 08:26:24'),
(7, 2, 'Es Teler Cup Spesial', 'es-teler-cup-spesial', 'Es teler berisi alpukat mentega potong, daging kelapa muda, nangka wangi, susu kental manis, dan sirup spesial.', 15000.00, 90, 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAlgAAAJYBAMAAABMSIXvAAAAG1BMVEW799AVgD2R2aum6L1TrHQ+nWF8yphou4Ypjk99nM93AAAACXBIWXMAAA7EAAAOxAGVKw4bAAAIoUlEQVR4nO3cvWPTRhjH8cTy28jRmGaMXRoYcZsmHuOWQMaqjQtjHMB0rGlIO8ZtePmzq3fd2ffIki1RDd/PghC+k/SzdDqdzuzsAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQeDM5+L93oVwD0zdrCzQGK6RCc3W5za4dn31Wnz88f7VNHaVqKNPe2hJDtWJf+Oh2Yb2Jq7/bppYy1Tesv7UN/LF5NWWqbViPvXo/3Mxm1y+9hdONqylVQ+19r3uytoQTf3SsXsWLwke3CKvjfQXvwsXj8xqFtWnRsTpY84ktwhrr195JbS7DWoblnVj/bli0QjUNa656G5asUj3DatSmTTfUM6xuLU+smoY1V19tVrBatQzLUds9J1WllmF16nkV1jOsXXV/o3JVq2VYU/XzRuWqVsuw3Ho2WXJYjddnk8nzq4yiK2Ed+yX0dWZYzuvJ5OJdjn3y2vccnzKLeHW/qHzgSwrraBEOKPTko1sKywnHVPb/TFcZYZ2ENX5KHtWjVrxx/Xmpo9AW2vepvsGmuhf8ues/Q3bCun8T97UcQljNdPzlgVR0Kaz56uCTHlYn/uev4zVhJMG3YobVFLYphtWOvln1q7Sv5bCH5Xhbv5gNZteudnDLzLAee2fhzeDwvdJOCy2shlfji6vBW6/CuPEOPngUHKQZVle4GYphuX7d/qYrbuvsYY2Uiq6mw3G+sNpKfQwWTtI09LCmaj9YdtJHZH+h7Y8a3wy0inb8479n3aAU1iiq2zvBxMugFPawxtoJLbbxRlj9pJ5RWmMaVvpk7J200ZIf1tho4yJDoecgheXGV77XeByslCqRNayGOFCs08Ny0qbKS+MyWkzDGqZX8yj++r2wWtE5YeoLQw5CWNfp+TSvdhTMGlYzVw9aD6ulVTNUt9FSGpabHr8TfxNeWK61SZ4KLyiEsBbp6ubmvcY8lsfgg5Xd5HCz6GH1tRKd5JtOwjJO1Xit6nXsd495sbD0hmqh1r9E2Nzy251oB05zFNXDcvXjWMRNeBJWSz9Vu1GTpHpDeypj4aYmhXWqf+R0pzrWsIZFw3KMRm4cf71JWEP9VG1GPQXVc+0XjfQcJYWlnUxd4UZajnLC6hj37H6c0XxlIdxk+GFva7frKjYIYemJdyrtPFjbrN2ibVbL6FYmV3GSkWs0JdHhKelGXzAs/WbkVNrCW++GraJ3QzPdVvy3JCyzK+KGfxNffxcMy7jwFnk6PZuyhiU9yZq0YzKv2068/3FYS9/3PLzYlfSVFAzr1iybuc/bsffgF3keSbVjmhr3r3Z8UcZhtc2WZBpelFKTVTQso7s/r7IPbw+rb+1ZL9GOab4U1n1zdWc5rKCgODlGGjPME9a0ymdpe1htZXtmW2KEdaD9Q3y708IyLrjobimOERTslBph9b98WMGEn7s1I49aWGN1pU0EPFwOq6ke6BMFp3FYQm9b6lnmC6vCSSTSSGkw7Jk95c4Iy7QS1pJgtTh43C826mB8WHgoKIc4Bh9OUvwxo+jWYUl3+aHQ8ucL6zRjl7ckv91pn/uH9Ytc1AhrYogGw9Oweua/B6vFsLrCy/v6nlme7/y4fhL/2QjL2vykYdmOXgxL6hPXOqxghHxfHPOoLCxh5Ka+DXzkSMkvh8Wuw066+jL4s2M9VcSwpIHaunYdtI3neWEhdAWFHnxEHrte2LPP1ym1Fi3HurDa8tthLSzh5I/DalgTl8Ma229pRhAt6XGnwqHStXMdXPGrEh+kE8KDdEQOq2+/HQph3eqfcb/8g7RGetVihCUM2icPedaBEzmslv3aN9qjXfsQTaUzu9aGJY/Ha2EJr4OSsKzjCHJYbfuTkBFW3zr4Z7/gy7I2rK54O9QSaNtrScKyPu1lvJx0rRs1+lBuEpYeT76XeJvKcWblCEt4KE7C2rU1Qhlh9a23T31XGsr6wiLfgPim1oYlP2zpYc2tn0rC6ti2khGW/T18S2ueulpY2qal0Z1yrA1Lej1shjW0nv5JWI7t4LPmCLi2+vS+7VgLKz0LnVzzDja2Niz5Ha8eVsf6WJQOedomIWQd2MiWbiO91TXVXRqW/pap0mk01rCcdLEp34uNW5xrm5KRhtWyhJkVlrOw3daSKSeOq46SsC7ShMbVzty1vwr7mCyO5d86GGGNtEFiJ75w07AcferUSfhH5iUziud7+R5GbdU0ruSxut9Je/DJrJMfMh77y+Cd2jNdMJTcUr1wSNmfJ3opFTXC8tLYj4ahH7lxO6y9efAPPjyQxvuok50ZlnfuqE8HUX1xw96KRoweenulhTWKXhicVP27O+vPfr2dUh/+mgWzJOVGwOxp+qOhF1eDw9cvlbKE5bfIvWeDwexsofKEFcwJVHfPn/qfjyv0E7ybvT1X6p8dLaxgmuRs9j5rPKkU1rCc35O/9+TNL3XLv00riRsOPayGm9YZrllz5zpJ69s/jdbF49N7O0ZYyQTcU6mycgg/KH8UHdregVx0+RnmYbTL6Vshcz7IeXTkz6L8193m23G8L9LthN/I3RMzrHhqtzyqW7HD67PJ06zfDKxy3p5NLp7J/43G8fXEq7LAlXL41CtwYxTw6jB/eBB26/1NG79XgI38OIYVhFUAYRVAWAUQVgGEVQBhFUBYBRBWAYRVAGEVQFgFEFYBhFUAYRWQ77eRAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgw39gU4mQHTFnLAAAAABJRU5ErkJggg==', 1, '2026-07-14 08:26:15', '2026-07-14 08:26:15'),
(8, 2, 'Es Campur Serut Jelly', 'es-campur-serut-jelly', 'Es serut dengan sirup cocopandan merah, berisi aneka buah jelly kenyal, kolang-kaling, dan susu kental manis.', 12000.00, 96, 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAlgAAAJYBAMAAABMSIXvAAAAG1BMVEW799AVgD18yphou4aR2atTrHSm6L0+nWEpjk/IlLcPAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAIxklEQVR4nO3bzXvTRgLHcaEoSo6dBK99tJ+EwhHX7cLRgjzpHmtoyh6dF0KOa+iWPaJl2/Jn77zqdSxZidcO+3w/B4idGUn+eUaaGSlBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGxNfD3f6P42vLsWR5Pc922FL/8lhPjz1XwDx6WEbza6u3Yzkeu1lP3Rlhv8spFD20nt7v66kd2toENY7+Rxv56cydZ1sIkjixdC/FPvTvzjdhuYr/eAZFiH15nmjUep+KxLXDzfSFg3oj/Vu5uJv9xqA7O1H+bqW0zyBnW67qPwmYmh/enxVxdWJAbzde+8eX8Ps5+nt9rCFsO6EX+se9+NdsVPd9zCFsOabbZhBftiesctbC+saDOXwNwDcdctbC+svVtev2/t/CsOKxHzde+62fngrlvYXliz/rr33OJr6YbxyUltJJU+rJcLgqtqyauTufnhxP3gfnE87XZg3hN8fFXZbJNNhBU/V1Offnn+GolvalXjR3ry9vvUvHz3PgieyBnRU1VczqL6w/z9UE5dxHtb7/Gv2VY/6jLvPugXj94UT4u+ocPLtLCZUq3w49QV+tEV2ERYYztTLPW7nfqhX6ZuXm2OM+nJsZh6Obczzv7cvR+agv+2O8h2GYqnuoTa1Vu5ueJIPapPct6WNlOqtZMN94PRodryZDJZ9FdbS1ldLax3YvDd9fWLZ6J0ztgzH6sokfPc745PZPMyPTTpRWnv9MVMfJKlP5++WNjrpwxrIT6cXj0SNnBvWDqIT8XtL6pneBn5q9Nr2brMoZRqVcPay5cH1ti+amEtbEOJnhXf9ZxBks+2YGo+VdK7UVXj9FBeDeaqaRza9/eE7ng7dlnDF5acpX+onCfPxW/lN8biF1PJbrdYazthhf5ZzYP6yOHK/XBjDjTpLXTVcxGaJjQybTPpzcynk21RF/SFNRLZicyJXP/OCh+4zUxrtaph+T7a3VW3uOefZTQNEUPT3xI7094RT/p2U0P9/sB14ch8EZ6wvPODRPTmpUMYus18qtXaUFi9fFlZHdoD/1gwaRoimitlYs9dkbCN014UknxR0TQxT1jn5UZkxKnoFd6eZZtZPKzV2lBYhZVStb9z/+AzaRqTLvR1K3EXzNQeeGxbQH7eNqNyT1gz74rVjry0/uxexPnVMenVam0pLH8TGjWFNTPftOvAC9dlXYsbuoKmj9fDEnmRkst8oOA6u7IvarU2FFZhWVm9XjLLaAzLfPqsp2b9JbUtbu4KmjO/J6xlW1eDWZvWbh7Hrs68VGtbJ/jagEofwQphuSLu4ufCyttqrFuHJ6yl68ZqOmFGEPvFzIfVWtsJKxTeSWCXsMbuaO25rFBVd0xPWA3LP4/tCKJw5Yl0Ay3V2k5Y8ozja1pLrobR0ZuPX76ky8J6WHo/sPF5wvK2Zmtkvr7Clcc00FKtLYUlx74/14v5w3pcHCSvFJZ6xxPWvOEI41SP35J6WIVaWwpLTaT7tcmnd1CqSr5WM9aVw5otCavxEG90NqPBWcaGVSizrbACtURTHA0qDzwD+xvRNzfWl56z6mEdBL6wmhdFzU2xUWGMo0dupVpbCyu4lBfswbD01l59JBSn5o7x/zysYKHGIqPBx9xP1VrbCysIXi7capTlWYq7yU6wHcLyd8OWsPTvk+qTGPcmrCCelVcfwvJak66ZT/nueoJvCUsvedQmXPcnrCBKSwcX14ZfcR5fh7D8Q4eWsPR4tDZpvUdh5SsixqLaC8K8Y65+NVwyKG0JS08pa/Ow+xRWZdV9VB0LFeZqK4+zqtOdnVVb1rQ03TGWhTXeQlhx+Sy1Xx1l56uEUUtYeZOoTqT3OnTD3er1eFlYC7f78ebCCso3v8LqZDcPa7ctrGleZyj/HWU9+ny1sPSIOKxOIEu18pNCLLKwDoM1awjrU+ll9WbLbpZB0hZW9inNYlneL2erhWVm8dXbvKVaUbaT3W2EVemG8ustj7R2sn6ZtoWV7cIs3mSn6lCsFlZqVqMrl8NyrawfjLKwRm0PFHe26glefrLyviMX5p5oGZQK1wbtDYtsNpD0G8KK5vmR6DPATeWsWa61OHD7yM5ZjUvht1INK86OpTobHFfu45nvO4gXB6OWq2H6H7fJofrPDXBD8b4hrF23nizbii4ViXK3Ktca2VejfjZ0OF/7gz/VsPbt+ky1IenbB/aB9PBM/Ts2n+GJeNoWlm0TYWo3mZqp1Hhw1RSWfTY6eOuWj+1NVvn9eGrtm69yR/yRuN3v3flBy6pZP1/5eKV3+vux/O9iUV+9/JtQ93/Vnf2+OZb+t8HVc/l9t4UVpeq5/3yTicohfi5+ixrCCtVK0XVw9cytK6tvSz2tEr9Mv6nXivTfFlzK7yELK9TPhl80LSx2VP2jAfVnDYMvqe8vCOJxsaBaU7WPhbSFpf/cQG7SvR/Jal/Uy6aw9K0dLet98tsa/Kn+iMATljo1qn08DbKw1GeTn6RhybqralhB9Hfz87Re1jyMJNvXXL8M1WM06sGi1rDMH7Lk95ff2peNYQWhOZLPWTW7MjswT0NVasX6k8iOmoelD3DtfbHs6uiHyfGSX03OJsdz9yqavP5+7i9YoEOUFYurr6rmCkdyIXf3bfGN6Ojsdb7/ipc/TKbld+KjSv17b/1X8P9jhNUBYXVAWB0QVgeE1QFhdUBYHRBWB4TVAWF1QFgdXCyZlAMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADAhvwXiv+Oj0+I5jsAAAAASUVORK5CYII=', 1, '2026-07-14 08:26:15', '2026-07-14 08:26:24'),
(9, 3, 'Cireng Rujak Pedas (Isi 10)', 'cireng-rujak-pedas-isi-10', 'Cireng renyah di luar kenyal di dalam, disajikan hangat dengan bumbu rujak pedas manis asam yang segar.', 15000.00, 136, 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAlgAAAJYBAMAAABMSIXvAAAAG1BMVEX+16rCQQz2xJbnnm7YeUfRZjPJUx/gjFvvsYIGw83HAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAKVUlEQVR4nO3czV/bOALG8cRJiI9VC2GPAT7QHktpF45xl5c5NjOkneNklzJ7bAa69JgMs4U/e/0i25ItxQbjQLq/76XBduz4iSRLstNGAwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACw9N6Npo/9EVTd0c/3XvvQto7Oxfnnkzfpkol4XesR3dvAn5v9cpu3xfN7r31g74R0liRUd1iz+JDnn94Ub/2EwvqPSH2RyxYWVvAVTQs3fzJhffc/7+eLvb3Lj/6LgVy4yLBE70vR5k8lrK7/Yb9FL7eOFxjW+83A7f5RkNa0YPOnEpaX1r1G4+XiquEgfun6zcB6weZPJCy/YP3TsHiBYYUNwcC2YeSJhDURa6bFr27rPawWll+6X8zf3Lmdzlm7qLDcwi+1HnpYfvHuV9jZosJaMRes2ulhNYai8II4x6LCmiyy86vIhLUhfquwswWF5YiaG3KbTFidSqe7oLC6j1QLs2F1xd8q7GxBYTUrfcgKMmG1ii6Hcy0orF3xYRGHyVvGsIaP1GQtY1h++36v920djUYn0+zSm6PRoTbf4rw9Gp1+M+6hSpvlXF+O/OOnh1pMWC1r+54Md5qyot4cj+OOoxPN6fT+iDduBr0k5zhc+i9l7+NwyZq/J6+X2X8mLHm6LS0zT2TXh0d/O5aTFb/382uDlqVooHlPbWvpz4QVJdGP12Umv8Kw4qXJSLMVn1RvWhjWStTPKhFWa5hO7azn1gav62pZVqylXw/L8UQalj/sXbu4vf4qkmLZ9M98R4izg72vynTLJFiyeXs5FquFYW1E5bdEWCtB+qdXV1fH6eybWu6G4t9FZ31PTfHMskYPa9f/gCcH0di6FVe1lyK+lPphuePoQ75Mipb/Ff8avWEoPhSFJQ9XKqy1b/3w1dY4rhdKWDtirW8724o2rD0HLay20j74p7mafLDVeJvBRlwnkoVeUkv8nm9BWI6I1pcJ65d+ulCWdaWS1jgvMLPuWgtrqDTbTtpUOWO5UVO8H8e1z5Fn4AoxTQ8j5ofVkcGWCMtRNoiH3+naSaUuyHy71sG+GlZHLdqdpGClw9+mOErb9Um0zxXlY7tFYXmyhJe5GiriipGsbRdPUN/fpFRY2lYzZX6gKwNp+mH044UyQW1s4M0Pazt++x3D6sgmN17rt+6mWd8H4lkvs0pYP2sdl2FauxqN8ZrcRjlJOYEwVKfzduaGlV4U7hhW3JWN135XSv3D89Qz1yhhjdRC4Gin7UWJNNV7HvIMtO5ue05YzluRVPM7huXKkp10aStNIRYpFZZ2ol2tBZ1FWzXVTdywILpacWwZwvo1vIG/99XvuvZeJ9vdMax1dW2drXujbFjqCeizdM2ofDTVZJywLugjY8cQVmotaQvuGJajhbWtNJx1KBfWQFne1OZ/O9FfTe1UZFja2GBeWGnH6e5hraZr/Y5Mvc/SlAtL3WYjc1fmWbTNb8rCsNVv6Wc3LyylVFYJa1Zr694oGZZ2nrva9VNG0tQGAjIs9bRN1XAQ/LN5fSyUN1cIq1v73QT7fWclrHXj8pA8OUNYbqbNyk4FpVdD9XpfNixn/+g8LJVpWF5tA+hYqU7pC335VPlLRmIIy9EqRSs3x6R0HcbpLkuGlcxopWHV3bo3gko1sKxRwtK+U08c3KaujWGFVW6oVrxObipI6ZQqY4JSYcm5x3NfEtaLcf031mdlZh20WRxP6KxhafV1pl0BoiWD+GU7LXalwvq73zH7x5/Bq7TNKn4Opzr7jWAlLG2T0mGtqMO0ca66K2E546QQlglLmS9Sw6pxUCitWGf67WGNNL9E2+TDaimNSCd3MdTGhmnLWSasdJ5MCWutzukGKd+WxOxh9fMbm8JSLk/OMH8YNaz0ECXC6ipfgtJ1mNR/t7hrrerVw+oI8T584UwMXSA1rHS8WSKsmVLhlLBa9T+04ebrh2QLa2LqxhrDCvronw42X+0PhaELpIaVdllLhKVOEamd0ln9TfzY1oW3hbVr+gKNYY17yU0rw2lok3/JQKI4LK3/5iphOfV3HjzbEWxhzUzdWFNY/gm4x3KkbNi/FlbSg9HDGhrC0m5dt9Sx4XZ993WSj2m5HNrC2jClawqrGezg1eXh4cXUfGBlP8lFuTisjtrta6thNWqdU46ObanptrBWTD0zU1iz+U9RaGHFJSQzohSGsLTjr2hh1Xq3ItCyPflqC6ttukSbwtq1XToi+t2d+DEKLSzXHJZyqA0trLpnSoOyax7w2MJqmWaNjGHdoWQl3VJHLeidwpLl6WHVPAcffGjzt2ELq2EqiuZqOPeD62Elwy51KmdmCqujfBxH6GHVPv/XFubOgzWsiaGFN48N1/tzjpu9Iy2/MqVN9+umMaznyrsyYfndh3ofZDQMRQLWsDYM25vC8luc+AkOEz0sNy5RSp83GB030j+SrkNaUb3VTFh1PhYi928sWtawuoZZNmOndDecdPo8OlV/IJvIPGURt/DKnJHXM3VKlTFHVzzPhlV398EvuqbegzUs0+cxhuWkszln09z+c48cRX+mT0hsi+eW4U78Rk+8zoVla1Ueyo76aONfcZfPHtaOMmR1vshtDGE1GvsfkzuD0+xRM2HF87HJeNj1B2IT80Bafrff/Re5sOruPjj+EO73afjyZiiKw/KLYk9WrJvhM7mNMazgx1y31+GvL3NXqdwzpTKCoVjt+/+4we/EjGHFz8i9C/oJ+bDq7j60wppycngU3AYoDitseU8Pbq/ffow3t4YV8c88dwnNhJVMPGwHc8Z7l+OgN24My49TnF1dDsP6kA+r9u7Dy3SWuDeQy+aE1fhvuv0Huc3csILCa7+7E0keyI9bukHDElY7vrHTN4ZVe/cheQL40zReNC+sxl/yVtTZm3ib+WGlDzQmsmElj3O54WfpvW/YwpLfVTgPbwgreLwpc6yHdn04Gh1elD6Is380Oo3usJRzh98TBvvO/SBBi2PrcHR4UP7YS8d+z62chf6fII9txfoMeTnVfo+4ZDqEVV7ValQ17KXSrniyVavxUqlaMqr94HzJ2H/3Uo79pyA/IPuDYIt5/zJxqv2PIHNuBv+AdireW+9aHzP4IbT+UP5wqw5ud+u+yfW4uuKn5LXjVRvbOu/Ej30x7KZzEi1P3P9xfmdv/3Is6n+69lG5wSzO2snFXvhb5vu3WN1oMqje3048Old5+jScKb6fMKzeT8UbLrmb+Gl10yNHZXXPP5+Wn2dbZltXh6cn/x+nCgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB4ev4HGc3K3nn1JdMAAAAASUVORK5CYII=', 1, '2026-07-14 08:26:15', '2026-07-14 08:26:25'),
(10, 3, 'Cilok Goang Kuah Pedas', 'cilok-goang-kuah-pedas', 'Cilok kenyal berisi daging sapi cincang, disiram kuah goang pedas daun jeruk kencur yang segar dan menghangatkan.', 12000.00, 92, 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAlgAAAJYBAMAAABMSIXvAAAAG1BMVEX+16rCQQz2xJbvsYLgjFvRZjPJUx/YeUfnnm48gOSuAAAACXBIWXMAAA7EAAAOxAGVKw4bAAALEElEQVR4nO3c0WPTNgLH8dR22jyeOZrymBRa+ngdDPrY3MrgcTnWdo/kjnZ7JBsdPDYHt/Jnn2xLtiRLchLikY7v5wFS14mdny1ZkuV2OgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACwHnZ3B+aCaXqsXm6ldxvevZHe+YxN3S7xs0mapv3zD9qylsJ6fFVs6rvBgvu4Lp6myvY/y4WthNWblpvqvx8ssatf3Lep5t9qaRthPZjom7q33O5+UVvZjl+8PXl+lb34u1rcQlhJfkadn4hNTW5nWJHY7+3/Fi8fj9sMK55ohe/g6jaG9SRNdwblT09bDGsmjso/qh8P3s+7i2sjFkd74PrFysPaMrO6jYZp+sb5i+fvrtXL1YQlLoTXjSutNVFjNQWxorDEifWfefdqTW35TixzpRWENfIU91tklm43r7SKsGKtCXdbTeb5CqsIa//2n1jJXJXuKsKaVi2422pjnlK4irBEKTyec5/W1myu472CsLppf959WluT9Ic51lpBWIe3sXNjiudrJ64grHH6ar5dWl+ifp9ntVpY9z+evPhGX9AUVtR8VKKjk5MPg/pSsan6YnGcxXK78+T8hJXZTHe8v3t2eq1eWmHFv+fDUT9fV4vMsB6eng/MD0saq6ynk2JE0Fj4+Hc1UFht/PRl9t9NvvwnfeUH43LV5HSe2mVBw0BN4u1I99QIXr9cwQwrrndsuoGjkvtDjQi+1jZUDatWi5N8l9Xqv1RrP1Sr7gzE5v4W3twyDgOlxxdWlB3A/mU+kl6WAyOsUbo9sD5s2HDV3cu+5eVl9m+Zc6yPqqb/kkuTbF+y1fv5MSv3MRssSy9Oz/JBxVbCGgWqXV9YMzlWeCCOe7lYD8vV3ZyF976XFamBOBA32vfPFm6//bDb2T0SpVG1B7OwRDB9sQvx99oeiN26mx27+2LhD62ENQ30oj1h9aqxwlGVihaWOPPq185RuIkivumvxStxyVEFtpduf6dW+KPcVBbWLO1fq/ddl7t1t1x3u5WwJoFmtSesWVX4tFi0sJ6kaX2Ibxxsv/e0wrdXnlq9HwflGmJTcgMirLhMTpxir4pXh9puTdOzNsIKXdDdYUVV7ZEXOPn+Kqyec3RhEmw5DPVKbuq86OyrXRBhaZelsq2rDwhk90VWH1bkOgkUd1hdY/BgrHaxCstRu3eyoxIaUB7r+XadwxM91fYQYWnJb8m6TOSjvWnaUliO/Sq3eFztklaP6pe1fVXBlGF1nR3m4Iayk1GLMpo4K1L1CYlxD019sNkG2mwjrDjUgHeHZdZyPfUVVFjim7oKkbahsd4eKN68aV4RZs72zFieTklqHA65eGZc1ntthNVbOKyedYqo7FRYWj2ri6sGvCMsK51NZ090JLeUpMaoklxsXUAmaxGW3RJXR1SGlejVv7GhUFhjs9z1nF2jmVxJbOKOsThvk0zMYzhtJaxAj80Zlt0S35A/y7Cmnl6NtqGPJyUZVu0y47waaGHp0Q7zoxVZR72hDbyUxcOaWU3+rvxNEdaebzjUvSEZVu2XzkaZPIWs657YcBZLZH3E4VqEZTf5e7ICycMSTURPDzAY1pZ9Os5czf0qLOOjirBia3R8uBZ11thqXKrLXB7WzHsDJxhW176AOs+LKiwj2s38lLbDauPMWrzpUKtO5BfOwhIFxNcBjENhbdjnoz2SuPtIGIXC+jOKYbxoo7TeuJSt6ez7uTrQ1YYcS8sGpdWu2tRPtaMrNXwWCKtTq+Bf+XZlaQu34OtfelyGtR/oaLo3JBfWTgOtXOrjf86wukVYE/OMD42mLG3RvmG9OMkr10Z6bxKa9+HcUBnWK3N5tzxFHxQxXQqTYFgj8wLaynydRUcd6hX1VIWVOjvQinPUQYZVKzPa5rIx9eLOiKeCl2GZQ75JqMQsbbzg4J8rrPwTsrBCA8fOcuEPa0e9Kx8/7RRrhcIyexbDphH/pUwDA5gLhtUPjsI4R0qbwuqm6ctyYTisSG8Oi978Ao8wzC3ULViwGN4Zh+45O++MNBVDYxgwHJY4GtWlOHSp+QyHgbKzaFhboakfG64kG8Iyh7kawkqqs1Abxl8p92hIYd6mQ75W1s4aBfax65qt42865JszB/QawopTVb89TUNH7TNsBTqHnkaptZbWKO15xmcy9jhYrmyUWmHJRqlZzzWEtZ/f9T1/dzVO25q76vwOkqe7Y60vi0reQzkMTO5zHW2tq2SQ/R+zoenp7qiwxumL8lGX1512BKbfOsOy20uR/oWjQLt06uiAyPdu2vXZ0NXfmwbD6oml2T3XrLn3m28fPtfUf5H1DNEcGyupGr84O/b9zYdDR+1YDtFYvypq/J6ZSrgF3y3GAD99/PTIswMrMPTX8M6w7PaSahLJouRvPnQdBV4uSuzKv2i7JcauReG+4UYbnUGb6ztInmFl80xURUiG5W8+RI4CXw0rm/tQlHUzrCQc1vDPmLEa+8egnGHZbQ3V2Nwo24a+5sOoftKpkKxJBHLgyAxrcw3OLM/N8uI3x+plFZY9KU1Vuyosf/Nhs16fqbCsuTzyLrNZZ43CYW220sGx+etkZ1jWdMfyxkx5+fc2HxxPWKiwrCl18g6S0VuIGsazkuCYx6rE3tEC9x3pqfGVy4Z5GVbsbT7UR+hVWFvmb8ZFLEZV1k3H4Y70RD1g2qqR79Ryh7VvFQ6ZdNWw9PZik9phUWmYsxsStUN6VTZOD8ON0sOshfXu5NOnD8bE4BVLfM8qu8Pq6de76ocqLOdcttzIviCWp87MnFl4V+1AWQ9103vDcFhRdae7mgK3elOzTj6qlh+rl3qzUb/pPCpbSFqXxftQnjgscsJeoSpn+luqe0TDstISZftNQ1hqCrWagtuSbFrKr+qH+PuygegJq1v1U/eqOlvv3418zwOJotKvKpZsJvZAvh6X80nEGaIqsER9fDQVn9gUVqdz8PzsUqbV/Lzpsp6IT/8xL+lHz7QpKr4JuOVY74027K6H5W0+5EWl2FL88ayaGFI8Pp3H2NPPc7F61s/LZvq+mSOsQj5bt71HG6P8dtPlaT5buzmsJB8LOXmXffOy8BgjB97mQzGDvn9xJgcIqjn/oj5LL97mf1miyiIbdtmWk7XnDquTj2i192xjpN2cq0a9vQ8N7NXXtR4a8M950P9iiPanXLT6WX9AX+1XVgctEFaWcnsN+uiZ2tXzalf9f6rgofzK2liIOSblHwSXwyj1a1Yk6+cdvR0TFxG+HnQWC6sz9h2tlbj//PTy9Lz25JBHfCPWfjvnyvUtnZ2ev6+3ho6uzi7Orat+dHN6cb5EY3Pf20VFTXB6EEzh2dEwhR9SgMGedIeAKWHNbxx8/AWGCRX83NxzWOHU+Eg2Ku5npeASt9mRvvVic36D/+kFZKfSS+2nb/8Cf9esRaLc7ZSDE/9rc+zvLyD/exk/v3i0u3v/JhsD806qQ8f+o82/NL/hq6bfCfupefWv3UHxRFR/mZHVr9Huo0ffDL70TgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAsDb+D/+SvUKZgCEUAAAAAElFTkSuQmCC', 1, '2026-07-14 08:26:16', '2026-07-14 08:26:25'),
(11, 3, 'Dimsum Ayam Jamur (Isi 5)', 'dimsum-ayam-jamur-isi-5', 'Dimsum kukus lembut dengan isian daging ayam premium dan jamur kuping, disajikan dengan saus dimsum asam manis pedas.', 18000.00, 66, 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAlgAAAJYBAMAAABMSIXvAAAAG1BMVEX+16rCQQzvsYLnnm72xJbYeUfJUx/RZjPgjFv1nEAeAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAJ/klEQVR4nO3czXfbxBrHcdWWX5YMEPsu48ChWdYNhSztcDl0ie8F0mV1X+hd1kBilnGhL3/21evMM6ORbQk7ck+/n3M4pLYzGv8kjWYeywkCAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADgGC3XXdheOSucicXb2d9+TRxRW9+Jx210Igp7KjW7KvTmisKZKnbbdBxNW7L9fOk8eUVhLdQR9kWEp9Q/7yeMJK4w797ztTsRhjc/Ozj67uLyOkrR+sZ48nrCGaqw+brsTcVgn+U/heXyoq9/kk8cTVl/9S3e0PT3Rh/BNnNYj8eTxhDVRd5FquxNWWEHwlbL++frHR+7rW7JQs7VqvTN2WMkV+mVbXdkkGgfz9nvmhBUu1bitrmzQVZ/Ew9anbXfDCSuZSnzfUlc26MVBDdXf2u+Gc5FZxDvx6CSnYNj+MV8Ka6DUrJWebDJNBvdl6x0rhRVG7Q+kJWlO09YnMqWw4ilN+1NlR5h2ct76gqcc1qD9scE1TMfRQet7sRxWeAzFEFtffRQk84e2FzzlsOLrYdXkIbx8p4te4cW7xzPn+c8u3118vuOGt7UlTdIexXtxt6avLt75+lFni36esCbpfky8XRUrjIer03jXJivtk9P0gW5SpBjfyd97GmVVxN9Pi7ZX1qXi7ep057Zsi+xYX5gFT7hazZw3ssoqJp3XUV6dM6uj+lv084TV12ODWUgnC7NO1osTvbU4GLFc+86UxX6d5Q1Zc+5l/l53aMsRjdL/TcUhv3QvjZNs+H9iejHSr6i/RT9PWOYhGdZd/J8aJVt5mf47+9lMYIfp5n/O+pn1ojKsbW05OnmHHoj2pu6lMevrRJYyx7Ode78bT1hdfTm0worT+DMIztOdEy+Kfg2Cb5aiorNQ6vdknLi6XG4Pa0tbpT5+nP/fvLu++06zufQ0juDmj89n4dWTyNQEam+xsiOlsMxAaoU1zQqD3yYXy3XW1a7ScfRElfU82hbW5rZcD/KjqCMmNUNngpPv4anSI2Z8rhVvrfYWK3jCCqJiXSHDelW8cKFedtQoe8VE//ZEthNmz1aGtaUtl566R2bBEzqrskEWwNd/moe+0y+pvcUKvrCKd2WF9aYYXePxv6/+k/081Afh0jPfqAxrS1vl/py6/Slt0DO9jxdudzv2fke+sBa+sPRhH88N13raWpz27o7OO1YR1ua2XKEa5T9NRCJmguN01dAXgbpbrOILa11s2Aor3x3pp1J6cC0msN7ZdXVYG9tymUJWXyx4nBE+8uwsffWsu8UqvrD0fMYKS++EpSg9FzvPW5mrDmtjW66BbmYoOmuP8F3fgnZQxFJ3i1V2Dst0Zi0Wj/P8ZOj55iyVYW1uy2WK7x19QrpL2IFv+3oP1t1iFX9Yee9kWJ+Ip02X+54pkHiyIqzNbbnWZjiKREDWOeQt3+ixoe4Wq/jCmvjC+lQ8bU65gQ6rzmm4uS2XGI7WIqCJbH3tG31EWPW2WGXnI8usiediE8Xh3xX7S6sMa3NbDjkVlefNQO4f3/huBrKaW6y085hl9txcZFCcfqHvKlwZ1ua2Sj00D8t3J/dPx1uwFGHV2mKlBmE9ELtXn35LfXE2dgjL25ZNLp+tS6AYwPzv2hvWDlus5J9n1Q9rrka664X9hDUV55A19xXtlC5r4dXZ2dn5fYS18E1Kt2wuXjqczJx29hPWUp7gsowlTih7fO88uS2KNDv2fkc7L3e2bS5ZUjh3Du4lLLuYLA8z8XprfBf1v3sISw8GdcJKq483Vlx7CcteSMnh2UxR5fgerrMq6M+x+whL+Uo0Wzf3NKt8n5p29hKWfXl35gunxW/KSWfcicfpG7iPAd7ssVphZZ8IyPtS9xLWXNnEfE6fk6KVnhgN7iMsc+DXCysIv84+rij+vZew1k5YYsGjJxXik4ylGusX3EdY5sCvGVYcV1L51vel7iWsyA3r+/IvmFtGenJyfB9hmVlg7bDic/iN2fn7CKuj1I/SQvxCURUUNyNN5WrvPsIyVZ4GYaX3peYd3kdYbv+sml/e4lA/Zq+67iMsM/FrFFb82vwDgX2E5VZRenLBk4/wfd1IRUXwcGGJJUWzsIbFN0f2EdbEKVR15IIn34AZ3+1oh4cPa2AeaRZWUIwr+wirVCaPxImWl5n1pz9ODbB3+LBEUa1hWEXJyAkrahJW6f6ntbWuHgXO+C6j7R8+rMi03DCs4kG7EKkH3zptlYuKVoE0XcWa8V1WoINkpx06rF4xPAeNwypmtXZY3SZhDUqP9eUjaQHcjO9OWOuDhyWL+w3DKta1dkmu3ySsuX0mB8lxJI61dHdMTHt2WNGhw+rKKXLjIyvr5NBqe9okrHXpUxvrI7D0GF6YB6wxa3jwEo38iO2vnobyY77kzoMGYUXWoZKybnKIlPVlAutT0/mhw/rW+qJTw7D0QCPnRAPVICzfLRTWwbZWj8T4bp+1y/Fhw+pG5na54C9PHawi8GLUYJ7l3oVltZ7947kY363RPx7PDhpWUu2UE5WGYS2LfT81Ozoe7Bf1wyrd3xdYk+Y0ETG+J0WHmenFl4cM6zzO6t/yyd3D6oibyEyZ5IE+MML4IGsQ1qR0MUwvQeYfHXUixvfktH2e//iFOgkPFlZ4/pNyP6GpEZYpkIqvLA71rT7TeDMNwlp4vkdkVxYiZZ2pehGfDL4HCGuUlImub+37e4u+3ulObAtLnWR35HcX5mao5P6eH5L391VyejcIy3u3mZXgWjk1+vRW9/BJcqftAcIS/jdzu3Wn+7Q1rOSPjjx7/ZMVeXIJfPHs9TJ9R/XD6nrvY5zKczOeH3wknksmKGq1itJL7yHDGr9yn6wxwD815V95L/4ifyw5veuHNXCXF/nviNe537zV7+eH4GBhjV488/xhnDpXw87bInN55oQLnVWwrh3W3HsLQ0/OdTtuWeJh9n6SC87ew9qjzuX17YubVzP70fPr25vSIbvHjZZmYt9c367+OfO99oNX966hD1r7X299j6zLK21U8d4fCa+hd3IBr3IlFZV8X9mBX8d3Rzn8fPUuVFge4Z+COVbyM05ssWj9D668P76o/fX5D9fD+n+Y4QN1dXmrOLB2001LfL9tfyHysH7Z/joEaVilvzGOCuHZrO0uAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADwnvo/8sQpLvI27rcAAAAASUVORK5CYII=', 1, '2026-07-14 08:26:16', '2026-07-14 08:26:24'),
(12, 3, 'Batagor Bandung Kuah Kacang', 'batagor-bandung-kuah-kacang', 'Bakso tahu goreng renyah disiram dengan saus kacang gurih kental khas Bandung, kecap manis, dan perasan jeruk limau.', 15000.00, 38, 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAlgAAAJYBAMAAABMSIXvAAAAG1BMVEX+16rCQQznnm7gjFvvsYL2xJbYeUfJUx/RZjOeM7NiAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAKHUlEQVR4nO3cTVfbRh+GcWNbxstnAsVe1pC3JQ5JmiUCWroMCSRZ1oeUsqxO05JllLSEj/1I86bRaIQhFrV6zvXbBIxn9J/bsjQaqe10AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAmfv68rC13d3JP7r/8V7e6Jbe6+eM3NZ5sNFzNjQ2EMvryb8Y101v9+OwbGi8/LCHGu3XviRrPcWa3+vftGy8zrGcnJyfHey+EqK1hdq/prc7Wso2eHGylQvxy68bLDOt79UM3FZ9q3nMHYZkeH4vxrRu3IKxOT6zVvOcOw+pMxfZtG7chrKzummPTXYbVE9/dtnErwhrWfch3GVYnrdufa7UirH7dQetOw4pvfdBqRVgd8Xv4PXca1sroto3bEVbyv/B77jSsVXHbxi0Jaxl71up/dM8qjlnHBwfOdZsXVnRwcOCeN48PvGu84/vzLvrcr6E9Zvn9ylfcF6K9g/yfa8OK5tS2kNIB/he1vYdJfiHy1675QymsV7/JS8n3tlX++/hBJ7rS59LXad7Y9Prui3zTw/NP7lbdA/xGqN/oKuvgTVbHuLh6fCzUryqs7pWtTy1DBJpUaluQE9ZAyM2/Tsy1df5rviqRjuUiwdO8oh/MRd0HXU+qft2OdNRvdGPdrTzZ5UMoTaecsGbrnUC/+QenezL1HeoN6bB6ReGTtXCTSm2LcsLSJ/FYiMsn9w+y3SsfxtBe8op7siIxPt082Ms+sl1VqNh40Dl5KEYnqqB+Iv64f7KXmivNvFM5hNLxsAhLz1f8frORZz29P9mbmeuKrhBffjzONvSyPiyviV/bwoqw+uJPNbw/dtXvSX7o9cMaPVXvPlSj74oNeYh4LT6ogmK9a8z0ATALKxvCF+/IUYQVj2R7v99s5LH4NfshSu2n8o/eUH1Y5SaV2hZmw4qmquzOsfnTW/Mn50sT7ZofEvnikZn1x2r9IEr0HtXXu1YW1qS6DmN7fK0/Ib/fvngvd+y8wE/ydbOrHo6mdWF5TfzaFmfC6s/UJ+fomrNjcOowkV/a1JyZ+qqgoT2jxurjjcd9UW1uevxJjP3rUdVvX3yVh8w8JXm0G5rxRomoC8tr4te2uIE4zY7dz7+GluGEnqQGw1oRsgx7KJrKgiYjM/ie+lM8PtJDcM028jPGeRJYcZT95uNbN++VUcS246PasMpNKrUtzq6U/lr9W6rPYMGwhvkaRa+49j6SBaXFWxNZejyeBZYVzErpRnWdQ/abj/x7/YKaW8zs9XavPqxSk0ptiyuWlT9XCp/pTyoYlpxoDItVHfk9iZyTnvo+xcUQ3J7tWvaDYL/ZyO1c9UhO8Z2pR1IXVrmJX1sD9LLy5nngY57qkIJhyWKdC7teXlDPqepIFhsHl0LVsvLew7S6R6sQ+vYrpbbhrojM6sIqN/Fra4A9G2ZHeD+T+WE5SwayoKE+z+fUz3Fwcc/2+FNlxzNh2V1UDtr5TnVqz4blJn5tDSjmWdHMX/y7wZ7lFbTiLLYOZHdxcJGs6PGNv5htwrLN5NfJ/RRq51nlJn5tDXBm8N1i1+pvnV9dXCQ1Ye09v/p6ceF9DWU2R84SQldWGAeXX50eJ0UBRb/VkTufwk3D8mprgLvqMDFDfezM2Tt+WF19xZU3HBQf+Gr+e+yEpYqPgwv7To9d8+1x+62MfMVZ9bphWH5tDXDDMovw0/xCLb+ADoXVy4Zzmf3xRd6wW+zfR/lw3DVidQyJg2t7bo96Eb7UbxNh+bU1wA1LT9nfmkWO0DErm0CrG/2q2MSegeR8eeKEpaYRcXBtz+1RtfH6bSAsv7YGuGGpKXuUmGl1KKy3ZqavirUz9oE8631LWCoHr98mwvJqa0AprOQ7WbY5GgbCihJz8lLFDvQiQ3YqzX8NfA3nhiWP3X6/TYTl1daAUlhpvuPO7D47q4Y1sAcC1TBSM38zSSuHlRc/Pyw5K/D7bSIsr7YGlPes9dIVSyCsYm6gGg5FIkYfs8twtXpQnjrkxd9kz9qt9tvA1MGvrQGVr6FzEgmcDYubBUPZcLqmzvh6wd7dAdSk+4ZfQ7/fBialfm0NcMOK8gO880JgnlX8uKLOhlmBrzbtI3zly538DfPDkud1v19/5O7lTiWsac3ZsFxbA8pTh9/d8dpVu2kxtNSejuO8YeRNjd2psvrm3GDqMKr2G5g02d+r14ZpMCy/tgZUJqVFWAMbVnH5VgxqFgqr7y7RyJjmhyWH6vUbGLm/RFMcLiKxjLAm5auEOBCWWeIyS23+4xHFRFAf8eaG1ZUx+P1WvlPu/aCNTukdg3BYtY9ufDsnLHWzoTg6JCYs5xawzW1VDWo2Kq/eTe3coa8WpeeG9VbuIX6/lZEX/azqWxdm0Tv7jMNh+bUtzgnrUN5psd+koTDHKmf2ZGtO1/TUQfy1s7lpb5mv2qj13HZeWP1kVMpC9xuYB5iOzS1Jc67ui/Axq1Lb4oqw3uj7m3ouHaX3Jrqco2KSY8J4JzZVQ3MnWS9K25NClOpbtteHlc2u10P9BmaYet97J/SObtZIJuOaqYNf2+LsrbAXQt/C0095PhLbJixnCVs/eNpN1rq64f7XxL33MNXrxIfmlu21Ye2nYvQy1G915BNzx3tdPx2xqu7d9cSfcU1Yfm0LG4jLs7Oz82yeaz66YX4X4fiH7FcTVlfesXolM0yzzynaT8R2t/j+dk6ObdQ9+WxH9FiHUBfWONvo2VUin13oBPqtjjzr+GlWRCp2dVh9MXqWP5kxflkbllfbwpy7O+YltQg32rVh5TdjLhJVy9A8vuGGpcaiCsyf37gQ9rZmTVj27o7pxOs3MPJHWU1Zuv/Y525i9cJ259qw3NoWpcIafTzdtS91Ez0KG5Z8RQ//kQ7WC0uf1TpmmdXctLkurIvLp8VL5X4DI1cP2nwuHlKKZnpD88IqarsD/Z3Tp+WtRVtnO+Y8vP98J3QF0bfTxlc7Z092b7/Vmn4de89Py5OBrMmNNtRvakGrMc7N6NZpXW3OPL91Wlfb8p6Lna91tU3a9uk5WlfbtG3HBUfrakvadsZxtK22Xu1/rrh87agtKn6cOCvKrdC62lbs01WVp2GWrnW1reh77p190fwi7oJaV9tAPs2xlT+/+2HZtfjaV9tr85zQ0v4vHvXaV1u09VsiRpdNr3Y3os21AQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIv7P86Q7DHesMaaAAAAAElFTkSuQmCC', 1, '2026-07-14 08:26:17', '2026-07-14 08:26:25'),
(13, 3, 'Risol Mayo Lumer (Isi 3)', 'risol-mayo-lumer-isi-3', 'Risol renyah dengan isian potongan telur rebus, daging asap, dan saus mayones spesial gurih lumer di mulut.', 12000.00, 104, 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAlgAAAJYBAMAAABMSIXvAAAAG1BMVEX+16rCQQz2xJbJUx/RZjPYeUfnnm7vsYLgjFspQWMrAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAMxUlEQVR4nO3cS3/bxhXGYQokQS4zldx4KVqxvA0rJ+lSrOUky7J2LksxTX/xMowd18swsdN87AIgZuacuVipCEiM+382osALwBfAYHAG4GAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAdGFkDnd498J82NmS7IfiXus48WRfYRWJ2WUWYa8MjXV48eUPwZN9hbU25k/xq83fd5jZjfBh1T76Xj3ZV1grY/4cTqvmfr7DzG6EDsuYr+STfYW1MeZOMGlSzXvvm7gqrIva2Vmb1mfiyb7CWprog6fVrN/bYWY3YmiO7MMHzx7VaYmWo6+wqvbJ6B2+mlWiHds3IqzKq7kxR8fu377CquZiftKTZtWk93eY2Y3QYQ0m1Ur/i/uvr7CM2YSt+co8iRv9fROENSiNmFD+9usOH50NqzBmFjZQS/OtubvDzG5EGNbgebSHXFc2rOrINwr3ubm5Hx0h904U1qSzhjYbVmkOp8FmVNSTjtIv3x9RWFUnqKPdIRtWFcsk2vvvljs1kDciDmvY1UJnwxpXO5wxx3rS+9Um3c18+xOHNQ6+x7VlwxpV2+7CXMpJB+a9oqv59icOq4w6jNeUDWtYdRI2+rR5XXUluppvf+KwqjV82clHZ8M6qA6Fa/3kpjoEdzXf/sRhDbrqO2TDmlXH26E+5i6qrWreVZ+lN7cR1rrqkY51f71u3Bd7X9C6jd1wVT1Rqi7opP5vufcFrf8prOLZFxePv/g1aoeLZ08vHn8ZTs6GVZ8YFqqDMq23s41+ffHyzdOLi6+/e+viS6dvLi6++P0vv4Y4rIk/Ko3PHspnfpzbguo36h2v2umfHqvJ2bCW9f42l8e+pgVbyfPF09e2HHn0czvpydl5+EknZx+7xf6lffk34Yu6E4c19Z1DXXV4IQqqfz1OTb8rpr4lrEXdKC5lyzirX7r2bX7xWszLvnAVlyU27i11uaT1c/iqzsRhjfwUFdZYlZ99W3xfTP1YflA2rHm9n69kC7WqP2/mT66Xal6Hx5lFrT6pXY5CvOPw8i3fdyfxEsx806vCqlbd0X+OB4N7L1/LsCbzdvrpE11mzYfV7OeqSLOs4zvwW069mRx+/d2/7z14WX/qtsI2jXqtvv/8vHrV5z9Uof1rHtf3O5M6kXYrWIY1qhbiuH08ee1TWfvpL4z6sFxY2/MaVaSZ11OG/gx+UeVvH9+3n1pEg2Vu+erhjn+0Dxf9DRNFYRVzPy8Z1sbuDY3Ty/bBRNahV2o5c2Ftz5hlkaZoFmLkN4nFp+L1a3t4XoQVw5ndFquX/M1OLE1vtZ4orLHoOYiwClluFk7k6q6CFrtALqxtLWYiVkTZBDf2i6JGeyd2kGwdtvC2fdfzPeltuDYKayPmK8KKG4ythap+ncg+Wi6stsonigzbXXKaqw0t2z02Kh7Z9n2kTjqq6Hqq5odhTTMDFqP0tl3qBkJtf7mwxtvVIYo0B83+VeYKWrN2hYQrzPUIV3rhZqrF6FAQVrGQCyTCOkjXT4fBcq3EdpkLa7T9qI08SJwPmu9+nHlDuoUf28Wb6yai7Gs/1GEVG2M+kUvpwpqlN+1NMHkkvnAurOH2PTP/9KbZi4pcQcvtn0tdqrDLNA1P0BY9jdeqsE4XaoxVh5UcAp0HgUxE65EL62D7UaJIs9imlDspLe0aWOvN27bvUVu27mlUzYf14Fnd/1PLe2VYk6icI9LLhTXbfkdRpGlnkytouf0zGPS17XuUTWfDCIGhMWeN9lRBnVhd2WbF9XrRpc2F1Z4D+iLNpH2UK2i5/VNXvF37vgz3utyhe1fB9VmX6kkRVuLELDl1Jrvh6bDa6kLhDn52G8sVtHxjNpdxivb9PHrDT8lP2pEKK2zDRVjj5MqaRdubiC8Xlq1buSKNbb02+fOj7+1bxTZkN/ZENFF83dBbVjBTEdYkea3ZKmrJxr6zlAvLbkCuSGOPi6vMFVq+HKlWzqpNLjEcteznWi+3Jdx79SQ6X5cN6kIdJ1ub6Bg99a1YLqyFa5fPtxNWbkL6iO/DGsuW237ONO6fxcvVCdnqPA87czKsmeqBteI8xGrOhWUPegd29S/bLKIj7umbp+3BZ/uCevu+tE+6nTNxYVS8xXdChlV138Mupl+Mugry6SCwiNoG8XVyYdlXuCLNvN0yDvTsf/TFT/eZojFyXdXEmVh0yt0NdTybBetIrbN1tcx3ggJ33JCK1jYTltsipq6BPrLLIlqkiaqWXrZTV37/cq9OHKjjA08n1JzKoIlXYRXNitZjFYmTsCvDcl1MW6RxlS1R0Gpr6oePv/6t4sMS3T2X20FcGs2cye5qGBQ3VcOoW4N2TEBeK58My07KhOWLC21qbneU+9OyrRPXxOCcaOFdFzYZVi+lZR3WTM8kaDqLdrTJXyt/nbB82aot0riGXiRxUm1VbhsWYfmHvvN1W2EFpy/RcebVduNy18pfJyxfEG2LNK4L4Qfhirkco5HDvgv/YrtstxVWUDFKHJS3cbWDA9cKy7dMbWd0Y1s5V10IKsMyLNdS+aPBbYUVnJMmL+2ux6UP2z3gOmH5b9me5izs/uTHwpfq0C/DGtoYfA/21sLS1Y70dfDl3Pge0nnw5NVdB9+bak+g3UxcKEHlR4bldtWlWym31HUI48ncNFC6QeJkWJftw0xYvp9eNvOe+K3AZhQeWHS//bL9a4/KybD675Q2OVz6/3J3WLgmJc5jcuXpjt9/tkUaUQT01Tz1XeVJjj0NF0NBiaVc93+6U1N14lxYhb1WPj67v/pEWtQWmiKNKi+fN3+DWo1ag2tblHY72jgeFbqBE+ntbMQ6yd67s2oX9TolGpFEU6SZyf8/bN8ZjOKIsNqDqahQ3EKJpqW6pdmw7LvikYGri3+iHtr0sFY+mU37HaOzLhFW27/w7XtiIKC/4p8OS3VLs2HZ7ec6ZWWx2TR992XUiQqvPZyp/7cVHrk13WBZWX9dtZqyYdnuY9xcrK4csBBjOM1Z4dyvnbY9CsPaqP+b3VjduxLtdJ1dyh+Itg3ZwmfDspWDMvhaKqFMWKrTdMcXaAbuiB+GNVf/N12Pka4vBx2F3e6TzIvCknO+MqxBeC3U1YOscty5LtLIS49sZUXvRVMT9GfuuLFH+7bgO/Q/yOrmLC9gu2I3vMbwvbqioXosL2qz5zJqxKu5I/gy+AB1N8vtDN+3c3Zr/i0NfPtEWFtdX3lhiLpWZmEuD0SDYwta+p2LQx1G3eipa52LYORpcjMXhmznfG4fZ8NyG/5UL1cxF+s0HdZUhlV1G9ZiR7brQHX2qh7+XIVVtfDBvYkbfd580tf9ZfHBX2zD2bB8VUBfOKauKkuHpUazqg7pRrzDBrmWC1X1y3RYVQs/0o3SUG96i56arERYonWUg6zyJaXf7tdqORfy09JhqbGY6lRnIXao0hWafYIfVCftOqyxOZrpRmmiBtNHvV2Bm7qTNXXTwEjeJrDyCZVyZPa5uvA0HdZQ7jJjc1duaPYsvPprV1g5r3ZJHVb17DJolFb6WvOeLvxL32FhF01dJumHwV7IgFb+VoH7Ri1mOiw18FIaNQruOlhLW4wtmysRdViJHxwp/a0C9e0DyUuFO5C80cl+SRWWMZ83dxE9+EXdHFDa8bHiWyMusB7kwlKlpiK4GsUXtIz58nh7C8AngzCsVfxTNvWk6g3x9XidSlTOlu5YpK9Wrp09ai7kkg3oB80A30U0PROWLjXN9Q8j2A5W4Qej6zsSgrCGJmrBt294+GieuLylO8kyo50kj4alGEzXq+6ffrraOdJhrVQ6G91FcmM3Y/WRQVjTxE9PlHO3FJ+Fz3UmEZbvhesR6W/t0si2vmafCH6qLB3WRp31rnU/bene8kJ+ZBBWfF/KwK/Mw6+ip25F8ezpo7OHn8c39E3ePDo7e9ztfZGnT7Mfmbms+VX1jofRLaL/77K3YiA27KuH/i7KXU6JhP3/AYj9UfZVVHgXDXVBBm/T0wjqO6mvca530phe1u+X+C0MZBS91UHfQSe91UHfPcV8/39VeG9swgFVZL2Ii6RIa8r/l7e9FH8IT5ufq4/v40OCiYZEkJUq/yMj+q1B5N277QUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB/MP8FNXbQ4uamuQoAAAAASUVORK5CYII=', 1, '2026-07-14 08:26:20', '2026-07-14 08:26:25');
INSERT INTO `products` (`id`, `category_id`, `name`, `slug`, `description`, `price`, `stock`, `image`, `is_active`, `created_at`, `updated_at`) VALUES
(14, 4, 'Es Teh Manis Jumbo', 'es-teh-manis-jumbo', 'Es teh manis segar ukuran jumbo dari seduhan teh melati pilihan yang harum.', 5000.00, 294, 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAlgAAAJYBAMAAABMSIXvAAAAG1BMVEW/2/4dTtiWt/SqyflZguZFceGCpu9ulOsxX9ylu/HhAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAJmElEQVR4nO3cz3vbth3HcUukfhyLxnZ8tLzN6bHq8mQ5mmvc7hhtVp8dpTRxe4y2bN4xarOuf/ZIAsQPCRBAcbayJ+/XJTYtUtDHJAh+AefoCAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD+P4zmf3mQ93kzP3+Q9ylduH4T3aF/scW/Uy4eRQ+1sefFxXlaq20rsWi/0176wnUc3WMqtpx5XxgPayLEZmM+S2248YmEtRTu58xFdBePTySsQogr+/uxEJ+nNtx4yLCOf2/7MrpH1ry0EN83X3pfGA9rJsR7+/vy93Ca2nDjQcPad9dCnO/8eTys9cZlV16Wj9u34xMJSxy7Z1JxvD5p345PI6xMnM6cd1+fzvzd305fXbTfZz+HDKsvPl/Z4WTiUSGCr/4IHDKsoXg0EdYdZSTer0T8DnM4hwxrJD4bi7fm+4G4WkaOeViHDCsX73Px0nzfE4vJg3XW+zhkWAPxcmg/35TX5NQ+0z46hwxrLF5m9pB9dVKeXFf7NucBHDKsKpm1NQqdPa7y27c5D+CQYVXXXGGNQsuzbOA+/3xkgmH1X1/P59++2rHrVljPqj3MNhVWufXmb94DVL350owV+mX/lVt9WHb5bl4e8PvN3Z5cz19sbUxvdgehsJ6uZUHhxP85KxthZf+SFYi/NxtkWG/qrY99w6dqnDA1t7/qzjjSZ2P2WrVA/KfZt1f1/tmf6o2/mMPYjzsJze4gEFZu6i/BOsBGWKtmh+Z+Vof1xY6jVCPQgenRqzHXsOnwhzPTgqZbq8Nq3uZn6zCLNs3uwB9WVv6Cbm4vbt/NdtQB3LDKVE7+eXH5j/IftaUKa1Seat/eXQvhGz9VzzYj00lNy+P1mw85rk7Sm7u7u+pEupLbqhvCcyE+vLot3+VMv7kJK6nZHfjDKpukrqbLIi2sYXNl/EE0N7QqrEIcVxfRaO37TVdPzX1zF1ieVY+H6u3G5ZUkL79net8yrP5a/KTeRZ9aJqykZnfgD6sQZmIm2Fk6YU30cZ43X5Vh5c0JMPBVU+t6jEmxqPZrdh5/p3u58tqSX5dhTZswn5t2m7CSmt2BN6x+oFDsssPKTFdVXguL+osyrJUeNs08Q/P6rU2RZl3F1lzEmfW6Zt+e+HrdXH2Z0LdRHVZaszvwhpUnlcLtsAbWYaaqG8rFqdk63R5AyUtOF2my+oJcez7vVEXeE9f2xfdWf7Vo0+wONmvw9cZx0tDQDmti7TFSV1YurPmIwfYIVXbmk+YosqufeQpaAzX46pXdur44Tfo6rLRmd7A5u6NadZWwqx3WzO6/VG04NzfG6gaw1cPLYYIu0shBROEpaI3UGdOzJ39M+jqse3+w9IY1bRtW5vQW6gPn9mAo277c5QBUF2l69WdeeZ6hmvFET1gd30gHp8NKa3YH/5uwRs55o4pSuTO4EltTEfLRRhdpZNF06RmQ9dUtsGf/Svp6JPWQYXn6rF7bPsvtkdTlkDun23ZnJB+adZFmVac58dw1Mx3WY3tjc6pal2FKszvw3g0Hbe+GbjNV6SB3RtHbUxGqHNMUaWb1v76zo8ml5/xKtsNKa3YH3rCG29eMhxWW+xFH8spy7+TbPbc6AVWRRp1hPU9By4T13tqqpxh1WGnN7sA/gl9bQ+EgKyy3pxnKM8CtZ23P26gSsirSqL7Ld/s3YdlBboeV1uwO/GFNxNnCs9llhbXaCKs+SWJhqfvAtLkd1EkM7KJ89sP1r/VtJzGspGZ34A9raNelQpywzq0fqFt9LCw17aWKNGq8Ze+kK1qpYSU1u4NAPasqQ30IliMlK6xCvLIWAl76wzrf2F/Fp4o0U/lzM3xSxcRfS/6wzvRxFm2a3UGoUlq39MPC+zPFCcuVFJa6P6oizVJ+djPS/7E8Tb6pl1EG+ixPWCnN7iBYg5fl4D/u2LVrWM0iEPnq4li1R40kclNPbhFWQrM7CM/uDOti95/DuzphzR3fVRtjYTWdjizSrOUZpceahRmltQkr3uwOdk2FfVW979fBHztheSYkYmE1o6K6SKMrpmrryCowtAor2uwOds8bPrWLIps6hqXPobpIo2vxKoOJ5yE8MaxIszuITLI+FeEp4uDQQYmE1Tfl9rdHZpZHPUPaNZ/WYe1sdgexGelJ0uyOr1YQC0vf9+rhaK85gjxJnYpOv3VYu5rdQSysoQiuxbPC8tUKYmHpEVX9oKNXtcnXjeznymH7sHY0u4PoWoeZ7wqrBR+klUhY+sf1I/SqGY/Lk9R56snbh7Wj2R1Ew5oEK2pWWN7qdyQsk0dVpJk1l408SZ0DjvcIK9zsDqJhhQvbVljeeZVIWCaP4sSUANVJ6iw9mu4R1r3U46NhhVdMWWENfUeJhGU++lJ8aVYAys3OmVXsEda9LPRKOLMSwjoSnoFWJCzTz03FwqwtlRU+e51WFqg6RM6sQ4QVngWww1p5XhUJy9xByzGWWbU8rs8xu6g/2Cese5m8iIa1DC6JtcOaejqtSFhmbFaO3qf6pzKmkTVOKo73CCvc7A6iYa2Dy/jtsEae54tIWGZD+Vy41BNB8l5hLVsYiUd7hBVudgfesKxVGXl4EsBZRTOznuX0rjvDsp4nxWmhW6GmIGf6MirEIjGstGZ34J8KM4sQi/AqWies59aMaiavgEhY1kTi7GStJ2mH8gLUzytflF8khpXW7A764uTWVtdkB+JE1mar0u4itKsTVrYWZ6qe+2QmhwGRsKz1Mivr7w7Vby9XNak31ZR9alhJze7A+2e/5f1H/Pvutl5uGF6b6S6TrNbM3Ly6uHz91+avwiNhWRfK1PqL1kxtL9/6w13VgF+O0sNKaXYH3rCyH/X3J+F+cmMB7u/MQeRn2h2WXVcY238rrbr2Zi1ttcwytc9KanYHgT8ofzJT356Hd91cB/9bNXPVTK/sDqtvDQ6cJSRr1ZfJ8Os6fPLdMKXZ9+Hy3fX8RbuFmdkP1/Obb+L/jUaiZy/aNuBor2YDAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAaPwXX3ezpr9i8uIAAAAASUVORK5CYII=', 1, '2026-07-14 08:26:21', '2026-07-14 08:26:24'),
(15, 4, 'Es Jeruk Peras Murni', 'es-jeruk-peras-murni', 'Perasan jeruk peras manis segar alami tanpa tambahan pemanis buatan, disajikan dingin.', 8000.00, 146, 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAlgAAAJYBAMAAABMSIXvAAAAG1BMVEW/2/4dTtiWt/SqyflFceFZguZulOuCpu8xX9ztbaejAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAIoklEQVR4nO3by3vTxh7GcUXybdlpHeqlA21gGRMKLNHTUFjitgkskzSELo/TlrBEHC75s480o8uMZkbWseLgc57vZ0F808+jl5E0M0qCAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADciPP/X125CJ+FtXcuN7t9Z7csG4onvLfn1+/ur1b0pO0K3126jhVjty/xhhUULPr5s2YavYdPCEmLyx2rFb8COeHpYabnROsIaZ99/8DyL67fVqq/fTtvepFtHWN+pB9FuIsR0tfJrt2lhpQ9j8e1q5ddu88IKhq3PnTdtA8NKy/s+9pVtYlh9/ckm2cSwInFrtfrrtolhBfPxavXXbSPDWrX+um1kWCs16gZsZFiz/6WwHr5KJh+P/vJuVIUVnl2Jj6fls0tVLLw9Tf8dXpQbRJfZC3pY0WX1buANa/d5Mvll6qweBPdfP0/Ex6NpudmyZnfmCuuHfEr7aWp/XirDGibyg5/zpyORrVcNXwnxTVZ6Um4QivfZDy2shfhZr+gO652aWR+7qod/FhPvYo1sabM7c4TVTxtw8Hs2pf3Gs1ERVhQLcXCYfvLf6rncnYdCLA9rILaNivVzlvzxQIjx098TMdlzVI+zB1dp3yoqLW92Z46wYvEsey36J1kW1kJsT9MfP+q7k3W2p0fHQXNYsTg2KtauhnLLdNrza/bWPP+/MKvH4tNF9q0/JuJFy2Z3Zoc1EN8Xe3Ds2SgPayjGauN7Kgu5O3MVYNAY1uP6XNkMKx6rb1FHaphMHNUPinPTA1WrRbM7s8OaiaUL5XlYs2Lfo0QdCunu9MR2UdAfVlh0Re0DelhyvyNRDE0fq75jVq8KqC9v0ezO7LBOlg+f87DiMo28Sro788m0fNEb1ok1hDDCGsgnvby7lm+a1eutadHsznbE0XlJ/t/EyydmqnlhdSz1i//7y+JcHzSE1bfnfkZYM1ltp1oDnG/b1Stb8oMtmt2ZsQb/JHsl/n7JJkVYvap/hOoKNBJ/aseXL6z0GmodMXpYUSL7aVx1FXV1NKtXerJci2Z31iGsmbb8m8hONhKJduL2hXVPfLAq6mG9y09ZVamR/CazeqUvr6w3E9ZFddswa1IQby/ZpAhLn/ScyINgJPQRgSes8hqq08JKx5Zy8KkNlwayrFm9os4BLZrdmeMEP3F+UKdi0hdSFvJxujt6aXdYJ/m4yFCEFe2mA/Qv2aO+dhEYysdm9cpAFmzR7M5cQwfHzphUWPopdSabOjLO3O6wes6VvXQwcZWSsyc1Ouhp3SiSm488a4IqrBbN7swOqy+WdmgVVqKdJbbyU7B+UnGGFSWuq79+k/UXbXJTkIfkyL7rE92+fHt+JmNq0ezOnNOdz0tWSFRYetu3ZJlROTSSpV1h3XNe/YuedXVQLiJs6XcP5UFqVs82OsvzfdGu2Z25J9LjU9dnSzKs9HK1X3qch/VEL+0I65lwjx1D6x7FTNypyiffWdWD4KeyM75o1+zOfEs0jd+bh2WYBtnu6OcNV1ieC5ozLN23VvWs2OTlnb3inNWi2Z05F/+yW+hNndof1rFe2hWWc1jZNiy9ejq0/aJqFWEtbXZn7mXl6J/0e/3zhzysW+cadRge66UdYR14bs27wtKr/2FVH5WrDGVYy5rdmW8NPluItAfauTws61bo8rCezN2LA66w6g0zq8/LPjrQDs/GZnfmv2Hxg/9XDtQA0O4kLcJyTKLVB+phGVdDu7o9i1/e7M4a7u4s6pfqUoew3AP4/z4sbcxqhtXQ7M4awhoK39xUTXQSq4+YYc2q2cmwCmvoHDzYYY2s66bxinaU9syw/M3urOm+YexbT1OT1rk1ZPaGNdDmhs5hqR1W3+qBI88sfav2SW+zO2sKy3svVZ13FtbU1RtWXwsrnfA0rjrkhtbRZFRf6KtdZljru/nfFNbM862h6uiz5rNKPgXKH77Pfqj1rAeO4YMdVmR9yqiurSLPa2H5mt1dc1ju9wbFmnjjgaJPhU+MZWXH8MEOK78P4ate9axIWGGt63K4Ss/KJ2nDJSfl6oKV7s/77GfLNXhlUW+ZGVZ5DujZYbmb3V1TWL71tJO8ZyT1M6kZ1qA86/TMsBzDB0dY9Xlz/Wo4LVozrlVb3zJgU1j22EAKRd6aRf3qboZVjRvjW2ZY9sqyI6xhvf8Z1csos5UMMyxPs6+BHVb5Bzw9cwem1SZ5CNZ6W21sFOeXvcfitHZH2ho+OMKyTtxG9fIG9HzySH7O1+zr5FiDf6ZeCc3fR4gm+erHT9UyS6yWy9M3/85vsupbpLVlJAOxXb99b62XusLqlb8g8+hnu3qinr0TH4ZqDd7d7Gu1I6402SsnYvxmP4h2Y/MwSE/S46OL23fPRDVC7gvx+U761ttYuMIaCPFyL/uTieOo/osh9eGDK6y0a01O07qPzoqrr159lr65f/eVmOzlYbmbfa3sP3QqFyAnxgU+SsrXp+WL97LnSbGlNUU5URt8CKywgtqNVmdYYVZ5klVwhBXm7TkOVFieZl8rx1+FZb8uJuy/zipWvMdT7cW/1WufVAPrYUXz7M0vgSOs2vDBGVYwjFVLXrqqPywaqcLyNXvt7p8fHp3aV8no7evDowvztfDt4eEb/99q7r7u9muLd7Nv9Fyvw9eHb4y3PM0GAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD/d/4Dx66G/P6Q+REAAAAASUVORK5CYII=', 1, '2026-07-14 08:26:22', '2026-07-14 08:26:25'),
(16, 4, 'Thai Tea Signature Cup', 'thai-tea-signature-cup', 'Teh hitam khas Thailand diseduh wangi dicampur dengan susu kental manis dan susu evaporasi gurih.', 10000.00, 192, 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAlgAAAJYBAMAAABMSIXvAAAAG1BMVEW/2/4dTtiWt/SqyfkxX9xZguaCpu9ulOtFceH90JhwAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAHxklEQVR4nO3by5vT1hkHYGPPxcsomSEsGUpol6GlQ5ZMC0mW+EkoLIFwW2ZoBrLEfULqP7uyrat1NOiM5WLa992MfNHn45+lo6MjzWAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADAp+3X2ddd3/pqdnWDDdkiw2sNf1i8MEk6h3WaPF59qln1WudyTceP7iZ3v3/408Ur9ONm0nCweGGtsEbNqsmdC7fxVV7i3urn/Jd9AmH9Uiny80WL9GL7w7qervv9mxcvzn5LF+5fsEg/Rn/JTJKf8sXFC+v1WXmpvyaX88UL9ln76a/3erl4/ONHDqswSa6uPF4nrNxu8vmFW5S3o7Lv3f64u2FhS8NKN6y/r1dhE9YI68/XWl9aO6zT5Mp6BTZijbDOsW5Yw4/dp4dtZ1g7W7lhbWlYp8kXPbSid1sZVjpee9xDK3q3lWHtb+deuJ1hXVp7mLYZWxnWk+RdD43o31aGNd3OLqslrNHz2exh7YXRjbNZ+lzHuaVmWMePuldM+/duH1Mv/6aPn/lcwbD2posJg38Wz46en2STCN+VLYo43Rkt51sOPlAxsxfu3/dqRSdZoMmXg3w650pre3oSCmuYf4/8w7PwFr4s3hoR1unqxFS4YrH25VDR9rCeZZWubHjbCoWVfrV7b8/Sr5O3eWe+Vbx/+/btj9W5pe5hXU+/x5trN35Nik0mXLF4MdjjtYY1XpR/WWnwhgTC2k2SH+aLvxSbVnr28Xr5ox2flA3qHNZekny7WLid5Ie5cMXMpeSzUNG2sEYnWflnmx7LBsKaJH9bLk/zac6d34vtO00yX+4c1lFymC3dypfCFTM3wyOHtrDGxY482fD4rBnW7WJfKVoxqrxhWvQ7XcMalV1VuhE8Pqdi5ig85dAW1qRox35ysNFeqxnWk6Kpo2xevqb82buGNS42rPnad86pmHkSvkDREtZB5enJZmd2mmFVvto0MEIdFx1K17COKgHtB/rg8WoXdRoVVrWj2tnsbEUgrHfFgyeBOPaLJncNa1r9iJPmEGp/taeZhAu3hXVYfcvhYIOaYVV2+5uBrXpYbBsdw6rvzIHTqeHq1rbapkxbWNWN6SR67B+jGVal5ZcCh6VhcezpGFZ9zztqrjRcHZZGhlX9Qc9pUw+aYd0pHzR6k8F8Q4kMa1z76S81N9bRmmFV3xzaF/rTDKvSue4Gw8q7hY5hXaodAMfNw+FotaOJDKv6np017q34sGZYlce7gYNLdFj1H3u/mf+aYdWGN6Gftz/nzmft9xFW/ZC61yy5Zli1w2vjyNqr7mGNXj66uzi3jwzrdCWsynFyteL5hbuEtbfRc+nOYRXzT/FhVT+hMk5oVizWiBmU1sJqDEN69YGw8uZls3d3U7FhTZKnlRsBb+TfJlQx8yTq3HAlrMbsWI86hvUsSQ7+sbiRMrrPmqzcsHW5vWLmKGrWoRZWYxjSq25h7Zazvz2FFayYCZ1tD7qGtcnznW5hTcof7AJhzWp+b6+YaTkd/kS2rOo80QXCCswxhStmxlHTytsW1lHlzrJ+wgpXLD42+I0/kQ6+OskSHdZpaIgZrpgZhiYdP5WhQ+3bDNcbwS+1VMydBIfw3QalH3EE/3nlT96cyLCOAkPMloplI0IDrXoQ05bTnU1OlXYJqzZTs7veifRSS8XcUfArt4RV22VDk0r96RJWbd5jJzas0KxJS8XcONhN1/ujJDhFE5qu7E+3sCotuBkbVuiOmpaKub3GpcS5WljDJDj5F9rn+xO9ZU1iwwpdRGipWJiGNpDaGGpchlWNp2V2pyfd+qw7xVOj6FmHQWAzaalYOAqOAKp9+VESvGARHnT0pVtYZXvG8WGdNnv4loqV9cODs3L5JAldCmsZzval29ChbMLkMDqsm81Oq6ViaRoaL1WGt2maoYusLafgfekSVmVEnY5josMK3IHQUrF0K7RpVaZuJgeVK9LlZ234/sqOpzv3i5cfR4eVrt74p6VwxdLoJLBD7RQ92TfJF+UIvryAvbvhW8I7nkhnLb+eLsSHdauyp4x+PqdifZ1viwdfLUeae3mdYXo+dFqEVdx4Mgr8Kr3qFFbaQ/xr/vfV/DgdH1a6mRxk99n+cfrZORWr60yT5Lur2Tr5sHyaHM5bN5xfNi/DSssv5hFHpxu+46jj5N80v3Ey/bXjw1p0x++fXrvx/Lek/N6BilV781nVew8fPJpf1shW+mY+Ff3iLM3+aiWs5W2SL+a3SW74fxQ7TysvL8N8faGwBn8qZ5XfnVOx5na5zkHZwS3dH1TDKm7A3egtNIPOFyyW33axtV8krMFX2WWve8Vt76GKdcUdzf8umjhcPHXww6AeVnZr9+Fmd8Lujh/MHjxdY/3Ry0ez98urOd0r3ngwmz2o/S/AvEz9fw+WB8Djs9n712s07//Elv4D2XYSVgRhRRBWBGFFEFYEYUUQVgRhRRBWBGFFEFYEYUUQVgRhRdj49CgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPxv+w++i42UBzOH7wAAAABJRU5ErkJggg==', 1, '2026-07-14 08:26:22', '2026-07-14 08:26:25'),
(17, 4, 'Es Susu Kurma Segar', 'es-susu-kurma-segar', 'Minuman sehat perpaduan susu segar berkualitas dan buah kurma premium pilihan yang dihaluskan.', 12000.00, 92, 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAlgAAAJYBAMAAABMSIXvAAAAG1BMVEW/2/4dTthZguYxX9xulOtFceGWt/SqyfmCpu8kaNKiAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAI3ElEQVR4nO3bz3vaRgLGcQIGccxYdZJjwDxtjyVOszlarpv6WNput0fIk5Ic6zrr5Gg2Xjd/diXND400IwnVEnH7fD+XGBjE8DIzmhkpvR4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP80769Pz/741JX4JPpHOce1bxgtRCL88re2qnD4xD780dGyrQO3bihyHteVH8910YOrlqqwOLAerMSjlg7bgaZhTeJG9cPpNGle4VU7VbDDGgmxbOeoXRiKZ2tLXd+Ks32elnl/uEWy27HDWokH7Ry0E0PxfZPiUdZLXnYQ1vhON6yGYQUiXJoHbx+3UwUrrI141s4xu9EsrH4XvSQLayzC1s6xXWgW1r1mnXY7WVgb8a/2D9+iZmGtxFX7VTBh3fWG1TCsjejg25iwojvesBqGFXUZ1t5db1iNw+qgCjqsO9+w7lA33BMHd7xhNQ5r2X4VVFiTLs607SoJK3h1Mj29cX7pc3G85XEvT6ezs9dbFZVh9cVBXUHX6GSmNotG17MXuc+/PpnObpofsZI/rLdz/z7MQHzlHMDa1gmO1AQ8+Eauy5+or/Lj0+wNF8U9GBlWrmF5yo+P0o8Orv99lBb88HVczeQzfk5fTSq8b2r76seWd0Ykb1hjswtR+LX3xGfFsgOrsY30BH9jDiCPPrfetip25TSsvti3nvKU3xP3k5ol2x1palHYG8mfNP78QP6l1q3Bofl4a3XWAm9YExHO1us3J3EVCq/MnUHLF1Y/blMv1uvruNL35dtqw5rkluVlYcndNB3WRjxdXy+S328lDm7exJ92lb4j+a0PZmcfT+P21eryzBdWX29VBS/nhZfcBYkvrIl4Lp+4PNwyrGGuYZWFFcTt6qebd2lvi8JR2szj5rUM5mkLisTD9B1j0/1/bXfq5gtrkz03KrzUdxq2J6yx1Xtl6dqwFvn9npKwLkT4nX46Cs/lCxfie/Ul9OeOPzdvnmx9RtqGL6x5WF5+km8C3rDc00BdWMPCWOgPaySsz4rChWzGY/EwUj/OwpkGDt0z0i14wgqqtsHj4eizXI08YZ07y+26sBaFBuAP68IeAyI9QvXm+/p5d50/bnXQGoon08wX8gPuV7zhQ3yKXlqPPWFtnEVRTVj/LZ5k/WEt7Cl+ZJp4ZLZXB+4v756+byF/weKhrFZV0w2SSxbZoOALK3K6cXVY4aLYIrxhPcqdXPRonp4K1V99t+aL/eIzt+ANq6plpWnps13PH1bDliWcfu8NK8yNSJE5JZybruap+eQvrAtKDcXzj5mr5Kmx+c380um5ScvbDYvjbCth5UtFpjXeMxF5aj6pOFk15hngR7X9/GWclr6y4Alr5Zyva7rhfKtumO9j2dZaNlKN3OHcHRJuwT91qJvJJTPpY/mnd+pQnLnWDPAXxS/pD+vKLpL19YHpkJ8irC2uG8RpqcHAOyktpl0TVlBcRfnDyhXxhRUUwgreveu6GyaD/nHd+/b0Gtm33FlsMRXIxPOsYtPyhpUfqrOwht6wLk/kzkPXYSVD7ufus3krFYgvrGFhLlYbVrFpecPK/wDVYek9oh2ElS7bX7jP2/QtHKVbND8ts8K1a8NC0/LPs3LvqgwrWXGLr6ez09NF52HJzb+D6jvW1HLbG5b8YX8xI1dtWIWm5Q0r31Mrw4on9b/I43U+wMdGh2YTsvyd6aTGG1Y8u0jjXqpH9ftZ+ablDSs/h6oKq5/tTuwiLHlPkfhPxTvVdKwkrF7wvzguvZirDyt/Y9Ytw7J2EncTluyLy4q3ytNTWViyL6rH9WHl78y6XVhj61ywq7CSyVTVBoccO8vDSncolukfW4SVa1q3CyubeHW/3Mn0K0+8k7S6VWHFReQSZYuwck3rdmHZa9PdhVW9KyurO6wKq686xGKLsEbWjrWnfIOw7G2ZHUwdNM9uWsYNy92XnMsg7C/vXNXW9zqsslWWp3yDsOwZWfeTUqNya2uiwnpsFS+Gpb6S/VtHZWGNsiWlp/z2YdmLntEOwxpVbW3JFt63DjBwwlrJ4cPegnMuPZr7s7IFvKf89mHZla4edZuqDqu4jM+RUwd7E9q9MVtdrrJO4O6d7p47/zzl/1rLOr8jLWskhwb78oY71VAty7qEMSgPK2tanvJNwsrGrMkOw6q60KOWO9YZcM+9Wq6+tXUGjCrCMk3LU77JAG9GvPEOdh1KX7UvUOvr1nNTtU3ohKWCyKaJY1E+ZmVNy1O+ydTBBLQSO5vBJ5U/zj0eZItFM/ZM9BRwLJ4Vw9ILj775ppuwbJ4ly8um5SnfaFJ6rOv4aNNxWIHZ+BsXG/FAfKH/jPQC7FwPNBPxWlb296UutFGjf6D7V188OK8IS99X6infaLnzSJd53HlY4qmsaTAptpSB2aT6YP6fk77n5oN4oCp7rjdIfjfjk7qvJl5tLivD0ncsu+UbLaTFd7JG+72Ww3L+C10Qj4qzm9eX1wtnLE7+Z2Y4+/jxJP7XDFULEb54vf4mXq3osIR4crZ+9+bbbMCPP+bp+vLVXDzrVYalm5ZbvskWTXxS+PImqf5x52H1/m8eOvtZ6v+x5u6p66tn4h6qfllTKLs5YSKf2P+td68yrKxpFco3CWtPffzPve7D6r1V39Zz1SJQSZpN0F5yy5jKSoXVC75VXzUrJFNO7vqsDks3Lad8k7CS/q+q32pYJd6fTKdnS+9LwfW0eB9wXHq2rCmUPFNzDcQ5QpPyee9PfijUCAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACAv4k/AV4woBWQ+FAeAAAAAElFTkSuQmCC', 1, '2026-07-14 08:26:23', '2026-07-14 08:26:25');

-- --------------------------------------------------------

--
-- Struktur dari tabel `reviews`
--

CREATE TABLE `reviews` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `rating` tinyint(3) UNSIGNED NOT NULL,
  `comment` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('3mJU6T1ChHKFOHZ8EPAjTQjjTztR7qHl9THjE5Ac', NULL, '108.177.18.207', 'okhttp/4.12.0', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZ2o1Yk1vRFQ4b2x5TU5RTW1hNUdBU3Q3N1RPRG1LbUNwNkNZN3VYbCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDc6Imh0dHBzOi8vY3liZXJzaG9wLmNvLWlkLmlkL2FwaS9wYXltZW50LXNldHRpbmdzIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1784207938),
('B8l3KwhssgYjqBUidVkPGVP98tv89YwCB8WvzCI9', 1, '114.124.247.15', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Mobile Safari/537.36', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiSVhmd1FlT1VCU0xEcWxuRlFtdG5rVk9Sam1KTlpRUDBtNFFkd084eiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDI6Imh0dHBzOi8vY3liZXJzaG9wLmNvLWlkLmlkL2FkbWluL2Rhc2hib2FyZCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjE7fQ==', 1784209521),
('bmcAsxyEB18CNcLJnBxqp3qwEMhICUSltLbRrsHd', NULL, '34.181.144.140', 'Mozilla/5.0 (compatible; CMS-Checker/1.0; +https://example.com)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiWUljeDY0VUtyeXZPbW5DSURMdWlRUDNmODBUbnpoWTl2VlFJTk5yRCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vY3liZXJzaG9wLmNvLWlkLmlkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1784204706),
('Jh1rcCDXt0ggr23BJkqQHbIBeuQzpW8CxLarCwED', NULL, '114.10.77.130', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Mobile Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVnBpUnVFbnhrRDc4a3ZYVUNleTdwb3Q0MnJQV1h5MzdUZHhBZTg4NSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vY3liZXJzaG9wLmNvLWlkLmlkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1784207008),
('NfZ0WMg9sc8GJbA3pPCMw3BQaH9MzfHI6VpkVuZM', NULL, '108.177.18.206', 'okhttp/4.12.0', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiV2xYQ2twaEdjRDlSR2xoNmRWMXlqc0hMaFZweGczWXJvUnkyM05DcCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDc6Imh0dHBzOi8vY3liZXJzaG9wLmNvLWlkLmlkL2FwaS9wYXltZW50LXNldHRpbmdzIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1784209096),
('oSiV0OwkJYNgGwtSYvdMfps7VlBYJv1qUub73VfY', NULL, '114.10.78.130', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Mobile Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiN0dFWHdKVzJONDZ0MzFrRWJXbmpFWHoyaVhrQXp0eDh4dWtMNldRUyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDc6Imh0dHBzOi8vY3liZXJzaG9wLmNvLWlkLmlkL2FwaS9wYXltZW50LXNldHRpbmdzIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1784207177),
('pTDucl3s0SsJcApSRpFM1ebmQEg3kewtwHNAy3kP', NULL, '34.78.5.76', 'Mozilla/5.0 (compatible; CMS-Checker/1.0; +https://example.com)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiQWFzQjFUckw2YnFLbU12eGNNaE9xQTc3dEl1NWQ1WEpHdzBpYkFiWiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vY3liZXJzaG9wLmNvLWlkLmlkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1784202626);

-- --------------------------------------------------------

--
-- Struktur dari tabel `settings`
--

CREATE TABLE `settings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `key` varchar(255) NOT NULL,
  `value` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `phone` varchar(255) NOT NULL,
  `role` enum('admin','user') NOT NULL DEFAULT 'user',
  `api_token` varchar(60) DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `address`, `phone`, `role`, `api_token`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Admin', 'admin@example.com', NULL, '$2y$12$agg1kJdeF7NTomRxMj6gse1mKDZ45fVNCisprrGpxaJ3nuUo9tNim', 'Jl. Admin No. 1, Jakarta', '08123456789', 'admin', '2YOZ0A6LuK3jWAhlbRNcTYEAZkVbP2osraBjxdKXJObIR2BGT2ZWLHcqyPGF', NULL, '2026-07-14 08:26:07', '2026-07-16 06:20:26'),
(2, 'Violet Astuti', 'csuryono@gmail.co.id', NULL, '$2y$12$XXquBWOQTYoxGxYfMLlUp.ZUe9bvjWsLpw1jZmLsnXXmiDdlF.nZ2', 'Ki. Teuku Umar No. 903, Banjar 76841, Kaltara', '(+62) 212 9467 2676', 'user', NULL, NULL, '2026-07-14 08:26:07', '2026-07-14 08:26:07'),
(3, 'Sari Farida', 'lmarbun@halim.co.id', NULL, '$2y$12$UdgVzCh6fFv0bwXw6zRcleb5NseHxGixcailCl7Xy7sAfG1dfvYmC', 'Kpg. Dahlia No. 930, Palu 52882, Malut', '0658 3201 260', 'user', NULL, NULL, '2026-07-14 08:26:07', '2026-07-14 08:26:07'),
(4, 'Tri Sihombing', 'laksmiwati.fathonah@astuti.ac.id', NULL, '$2y$12$Z4usl2T4BumsftJq2mPgkunOLPU9Pk8EhJIb2vX0cnmvqybH9tXX.', 'Psr. Flores No. 880, Padang 49763, Malut', '(+62) 802 381 205', 'user', NULL, NULL, '2026-07-14 08:26:08', '2026-07-14 08:26:08'),
(5, 'Gina Wulandari', 'mardhiyah.mursita@gmail.co.id', NULL, '$2y$12$SBNaBAl8IESy2cNpYlf/OOYdq7569f98w71argsI67hyu6hWJW1Eq', 'Ds. Jaksa No. 278, Padangpanjang 18121, Jatim', '0406 9621 7415', 'user', NULL, NULL, '2026-07-14 08:26:08', '2026-07-14 08:26:08'),
(6, 'Reza Kenzie Irawan', 'panji.rahayu@gmail.co.id', NULL, '$2y$12$JH2Qe9e7qZDarCfrKHBUBubGTWjrOLApEloPDiE14usDVaS9097dW', 'Jln. Jakarta No. 80, Dumai 17171, Jabar', '0811 093 139', 'user', NULL, NULL, '2026-07-14 08:26:09', '2026-07-14 08:26:09'),
(7, 'Padma Zulfa Purnawati S.Ked', 'tami08@gmail.co.id', NULL, '$2y$12$JzWTDCLF//9MbK6Q7jjP0OqxA26erp/gCi06dGZczMZfjHKVpfp5u', 'Jln. Basmol Raya No. 219, Sabang 84524, Sulut', '026 9236 7403', 'user', NULL, NULL, '2026-07-14 08:26:09', '2026-07-14 08:26:09'),
(8, 'Chandra Hutapea', 'onasyidah@yahoo.co.id', NULL, '$2y$12$HTdyaR0Ad4iHVzV0TSOHVuPfgpbHs.3rNaBnmTax/ndpCBXUF.fXe', 'Jln. Imam No. 431, Batam 14831, Lampung', '(+62) 507 7548 763', 'user', NULL, NULL, '2026-07-14 08:26:09', '2026-07-14 08:26:09'),
(9, 'Icha Shakila Zulaika M.TI.', 'budiman.azalea@halimah.com', NULL, '$2y$12$SzDZccVst5CspaBQYcFbWuTsYLYigQ5ivgLNz5KDLLn5Ds1uOPdWy', 'Ki. Siliwangi No. 594, Cilegon 66550, Sumbar', '0738 3896 0804', 'user', NULL, NULL, '2026-07-14 08:26:10', '2026-07-14 08:26:10'),
(10, 'Farah Vanesa Aryani S.Kom', 'tantri.hariyah@utami.biz', NULL, '$2y$12$nnZdLFKRzzqKgQjlSIqc8O8/Yef0kRuA0f9pfRxgTpoa3kQ1INkDa', 'Ki. Moch. Toha No. 321, Palembang 29169, Jambi', '(+62) 713 6547 0900', 'user', NULL, NULL, '2026-07-14 08:26:10', '2026-07-14 08:26:10'),
(11, 'Kacung Thamrin', 'tami37@yahoo.co.id', NULL, '$2y$12$xzsM2MfNPP3Y4baVxbPqwu7th3jnWidol1YeYviHV/JCL7dVHP1U.', 'Jln. Casablanca No. 812, Lubuklinggau 94020, Sumut', '(+62) 701 2302 6919', 'user', NULL, NULL, '2026-07-14 08:26:11', '2026-07-14 08:26:11');

-- --------------------------------------------------------

--
-- Struktur dari tabel `wishlists`
--

CREATE TABLE `wishlists` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `cache`
--
ALTER TABLE `cache`
  ADD PRIMARY KEY (`key`);

--
-- Indeks untuk tabel `cache_locks`
--
ALTER TABLE `cache_locks`
  ADD PRIMARY KEY (`key`);

--
-- Indeks untuk tabel `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `categories_slug_unique` (`slug`);

--
-- Indeks untuk tabel `coupons`
--
ALTER TABLE `coupons`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `coupons_code_unique` (`code`);

--
-- Indeks untuk tabel `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indeks untuk tabel `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_index` (`queue`);

--
-- Indeks untuk tabel `job_batches`
--
ALTER TABLE `job_batches`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `orders_order_code_unique` (`order_code`),
  ADD KEY `orders_user_id_foreign` (`user_id`),
  ADD KEY `orders_status_index` (`status`),
  ADD KEY `orders_midtrans_transaction_id_index` (`midtrans_transaction_id`);

--
-- Indeks untuk tabel `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_items_product_id_foreign` (`product_id`),
  ADD KEY `order_items_order_id_product_id_index` (`order_id`,`product_id`);

--
-- Indeks untuk tabel `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indeks untuk tabel `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `products_slug_unique` (`slug`),
  ADD KEY `products_category_id_foreign` (`category_id`);

--
-- Indeks untuk tabel `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `reviews_user_id_product_id_unique` (`user_id`,`product_id`),
  ADD KEY `reviews_product_id_foreign` (`product_id`);

--
-- Indeks untuk tabel `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Indeks untuk tabel `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `settings_key_unique` (`key`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD UNIQUE KEY `users_api_token_unique` (`api_token`);

--
-- Indeks untuk tabel `wishlists`
--
ALTER TABLE `wishlists`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `wishlists_user_id_product_id_unique` (`user_id`,`product_id`),
  ADD KEY `wishlists_product_id_foreign` (`product_id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `coupons`
--
ALTER TABLE `coupons`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT untuk tabel `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT untuk tabel `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT untuk tabel `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT untuk tabel `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `settings`
--
ALTER TABLE `settings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT untuk tabel `wishlists`
--
ALTER TABLE `wishlists`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `order_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `reviews`
--
ALTER TABLE `reviews`
  ADD CONSTRAINT `reviews_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `reviews_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `wishlists`
--
ALTER TABLE `wishlists`
  ADD CONSTRAINT `wishlists_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `wishlists_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
