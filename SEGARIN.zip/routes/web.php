<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\CouponController;
use App\Http\Controllers\ManualPaymentController;
use App\Http\Controllers\OrderHistoryController;
use App\Http\Controllers\OrdersController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\ReviewController;
use App\Http\Controllers\User\UserCheckoutController;
use App\Http\Controllers\User\UserLandingController;
use App\Http\Controllers\User\UserOrderController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\SettingController;
use App\Http\Controllers\WebSettingController;
use App\Http\Controllers\WishlistController;

use Illuminate\Support\Facades\Route;

//Landing Page Routes
Route::get('/',[UserLandingController::class , 'index'])->name('home');

Route::get('/cart', function () {
    return view('landing.shopping-cart');
})->name('cart');
Route::get('/search', function () {
    return view('search');
});





//Auth Routes
Route::get('/auth/login', [AuthController::class, "showLoginForm"])->name('login');
Route::post('/auth/login', [AuthController::class, "login"])->name('auth.login');
Route::get('/auth/register', [AuthController::class, "showRegisterForm"])->name('register');
Route::post('/auth/register', [AuthController::class, "register"])->name('auth.register');
Route::post ('/logout', [AuthController::class, "logout"])->name('logout');


Route::middleware('isAdmin')->group(function () {
    Route::get('/admin/dashboard', function () {
        return view('admin.dashboard');
    })->name('admin.dashboard');
    //category
    Route::get('/admin/categories',[CategoryController::class, "index"])->name('admin.categories.index');
    Route::delete('/admin/categories/{category}', [CategoryController::class, "destroy"])->name('admin.categories.destroy');
    Route::post('/admin/categories', [CategoryController::class, "store"])->name('admin.categories.store');
    Route::put('/admin/categories/{category}', [CategoryController::class, "update"])->name('admin.categories.update');

    //product
    Route::get('/admin/products', [ProductController::class, "index"])->name('admin.products');
    Route::delete('/admin/products/{product}', [ProductController::class, "destroy"])->name('admin.products.destroy');
    Route::post('/admin/products', [ProductController::class, "store"])->name('admin.products.store');
    Route::put('/admin/products/{product}', [ProductController::class, "update"])->name('admin.products.update');

    //users managament
    Route::prefix('users')->group(function () {
        Route::get('/', [UserController::class, "index"])->name('admin.users.index');
        Route::post('/', [UserController::class, "store"])->name('admin.users.store');
        Route::delete('/{user}', [UserController::class, "destroy"])->name('admin.users.destroy');
        Route::put('/{user}', [UserController::class, "update"])->name('admin.users.update');
    });

    //order route
    Route::get('/admin/orders', [OrdersController::class, "index"])->name('admin.orders.index');
    Route::patch('/admin/orders/{order}/status', [OrdersController::class, "updateStatus"])->name('admin.orders.updateStatus');
    Route::post('/admin/orders/{order}/confirm-payment', [OrdersController::class, "confirmManualPayment"])->name('admin.orders.confirmPayment');

    //coupon route
    Route::get('/admin/coupons', [CouponController::class, "index"])->name('admin.coupons.index');
    Route::post('/admin/coupons', [CouponController::class, "store"])->name('admin.coupons.store');
    Route::put('/admin/coupons/{coupon}', [CouponController::class, "update"])->name('admin.coupons.update');
    Route::delete('/admin/coupons/{coupon}', [CouponController::class, "destroy"])->name('admin.coupons.destroy');

    //settings route
    Route::get('/admin/settings/gateway', [SettingController::class, "gateway"])->name('admin.settings.gateway');
    Route::post('/admin/settings/gateway', [SettingController::class, "storeGateway"])->name('admin.settings.gateway.store');
    Route::get('/admin/settings/midtrans', [SettingController::class, "midtransSettings"])->name('admin.settings.midtrans');
    Route::post('/admin/settings/midtrans', [SettingController::class, "storeMidtrans"])->name('admin.settings.midtrans.store');
    Route::get('/admin/settings/manual-payment', [ManualPaymentController::class, "index"])->name('admin.settings.manual-payment');
    Route::post('/admin/settings/manual-payment', [ManualPaymentController::class, "store"])->name('admin.settings.manual-payment.store');
    Route::get('/admin/settings/web', [WebSettingController::class, "index"])->name('admin.settings.web');
    Route::post('/admin/settings/web', [WebSettingController::class, "store"])->name('admin.settings.web.store');
});

Route::post('/checkout/process', [UserCheckoutController::class, "process"])->name('checkout.process');
Route::post('/payments/update-status', [UserCheckoutController::class, "updateStatus"])->name('payments.update-status');
Route::get('/api/payment-settings', [ManualPaymentController::class, "getSettings"])->name('api.payment-settings');
Route::post('/checkout/manual', [UserCheckoutController::class, "processManual"])->name('checkout.manual');
Route::post('/payments/upload-proof', [UserCheckoutController::class, "uploadProof"])->name('payments.upload-proof');

// User Routes
Route::middleware('auth')->group(function () {
    Route::get('/orders', [UserOrderController::class, "index"])->name('user.orders');
    Route::get('/orders/{order}', [UserOrderController::class, "show"])->name('user.orders.show');
    Route::get('/user/profile', [UserOrderController::class, "profile"])->name('user.profile.show');
    Route::post('/user/profile/update', [UserOrderController::class, "updateProfile"])->name('user.profile.update');
    Route::post('/reviews', [ReviewController::class, "store"])->name('reviews.store');
    Route::delete('/reviews/{review}', [ReviewController::class, "destroy"])->name('reviews.destroy');
    Route::post('/wishlist/toggle', [WishlistController::class, "toggle"])->name('wishlist.toggle');
    Route::get('/wishlist', [WishlistController::class, "index"])->name('wishlist.index');
    Route::post('/coupons/apply', [CouponController::class, "apply"])->name('coupons.apply');
});

